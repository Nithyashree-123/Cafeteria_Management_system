const ORDER_API =
    "http://localhost:8080/api/orders";

const QUEUE_API =
    "http://localhost:8080/api/order-queue";

const STACK_API =
    "http://localhost:8080/api/expression-stack";


let orders = [];

let editingOrderId = null;


// ==========================================================
// LOAD ORDERS
// ==========================================================

async function loadOrders() {

    try {

        const response =
            await fetch(ORDER_API);


        if (!response.ok) {

            throw new Error(
                "Failed to load orders"
            );
        }


        orders =
            await response.json();


        displayOrders(orders);


    } catch (error) {

        console.error(
            "Error loading orders:",
            error
        );


        alert(
            "Unable to load orders.\n" +
            "Make sure CafeteriaServer is running."
        );
    }
}


// ==========================================================
// DISPLAY ORDERS
// ==========================================================

function displayOrders(orderList) {

    const tableBody =
        document.getElementById(
            "orderTableBody"
        );


    tableBody.innerHTML = "";


    if (orderList.length === 0) {

        tableBody.innerHTML = `
            <tr>
                <td colspan="6">
                    No orders found.
                </td>
            </tr>
        `;

        return;
    }


    orderList.forEach(order => {

        const row =
            document.createElement("tr");


        let statusClass =
            "";


        if (
            order.status &&
            order.status.toLowerCase() ===
            "pending"
        ) {

            statusClass =
                "status status-pending";

        } else if (
            order.status &&
            order.status.toLowerCase() ===
            "processing"
        ) {

            statusClass =
                "status status-processing";

        } else if (
            order.status &&
            order.status.toLowerCase() ===
            "completed"
        ) {

            statusClass =
                "status status-completed";

        } else if (
            order.status &&
            order.status.toLowerCase() ===
            "cancelled"
        ) {

            statusClass =
                "status status-cancelled";
        }


        row.innerHTML = `

            <td>
                ${order.order_id}
            </td>

            <td>
                ${order.customer_id}
            </td>

            <td>
                ${order.order_date}
            </td>

            <td>
                ₹${parseFloat(
                    order.total_amount
                ).toFixed(2)}
            </td>

            <td>

                <span class="${statusClass}">
                    ${order.status}
                </span>

            </td>

            <td>

                <button
                    type="button"
                    class="action-btn edit-btn"
                    onclick="editOrder(${order.order_id})"
                >
                    Edit
                </button>


                <button
                    type="button"
                    class="action-btn delete-btn"
                    onclick="deleteOrder(${order.order_id})"
                >
                    Delete
                </button>

            </td>
        `;


        tableBody.appendChild(row);
    });
}


// ==========================================================
// EDIT ORDER
// ==========================================================

async function editOrder(orderId) {

    try {

        const response =
            await fetch(
                `${ORDER_API}?id=${orderId}`
            );


        if (!response.ok) {

            throw new Error(
                "Failed to get order"
            );
        }


        const order =
            await response.json();


        document.getElementById(
            "orderId"
        ).value =
            order.order_id;


        document.getElementById(
            "customerId"
        ).value =
            order.customer_id;


        document.getElementById(
            "orderDate"
        ).value =
            order.order_date;


        document.getElementById(
            "totalAmount"
        ).value =
            order.total_amount;


        document.getElementById(
            "status"
        ).value =
            order.status;


        editingOrderId =
            order.order_id;


        document.querySelector(
            "#orderForm button[type='submit']"
        ).textContent =
            "Update Order";


        window.scrollTo({

            top: 0,

            behavior: "smooth"

        });


    } catch (error) {

        console.error(
            "Error editing order:",
            error
        );


        alert(
            "Unable to load order details."
        );
    }
}


// ==========================================================
// ADD / UPDATE ORDER
// ==========================================================

document
    .getElementById("orderForm")
    .addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();


            const orderId =
                parseInt(
                    document.getElementById(
                        "orderId"
                    ).value
                );


            const customerId =
                parseInt(
                    document.getElementById(
                        "customerId"
                    ).value
                );


            const orderDate =
                document.getElementById(
                    "orderDate"
                ).value;


            const totalAmount =
                parseFloat(
                    document.getElementById(
                        "totalAmount"
                    ).value
                );


            const status =
                document.getElementById(
                    "status"
                ).value;


            if (
                isNaN(orderId) ||
                isNaN(customerId) ||
                !orderDate ||
                isNaN(totalAmount) ||
                !status
            ) {

                alert(
                    "Please fill all order details."
                );

                return;
            }


            const order = {

                order_id:
                    orderId,

                customer_id:
                    customerId,

                order_date:
                    orderDate,

                total_amount:
                    totalAmount,

                status:
                    status
            };


            try {

                const action =
                    editingOrderId !== null
                        ? "update"
                        : "add";


                const response =
                    await fetch(
                        ORDER_API,
                        {

                            method: "POST",

                            headers: {

                                "Content-Type":
                                    "application/x-www-form-urlencoded"

                            },

                            body:
                                `action=${encodeURIComponent(action)}` +
                                `&order_id=${encodeURIComponent(order.order_id)}` +
                                `&customer_id=${encodeURIComponent(order.customer_id)}` +
                                `&order_date=${encodeURIComponent(order.order_date)}` +
                                `&total_amount=${encodeURIComponent(order.total_amount)}` +
                                `&status=${encodeURIComponent(order.status)}`
                        }
                    );


                const result =
                    await response.text();


                if (!response.ok) {

                    throw new Error(
                        result ||
                        "Operation failed"
                    );
                }


                alert(

                    editingOrderId !== null

                        ? "Order updated successfully!"

                        : "Order added successfully and added to Queue!"
                );


                clearForm();


                await loadOrders();


                /*
                 * Refresh the queue display after adding
                 * a new order.
                 */

                loadQueue();


            } catch (error) {

                console.error(
                    "Error saving order:",
                    error
                );


                alert(
                    "Unable to save order.\n\n" +
                    error.message
                );
            }

        }
    );


// ==========================================================
// DELETE ORDER
// ==========================================================

async function deleteOrder(orderId) {

    const confirmation =
        confirm(
            "Are you sure you want to delete Order ID " +
            orderId +
            "?"
        );


    if (!confirmation) {

        return;
    }


    try {

        const response =
            await fetch(
                ORDER_API,
                {

                    method: "POST",

                    headers: {

                        "Content-Type":
                            "application/x-www-form-urlencoded"

                    },

                    body:
                        `action=delete` +
                        `&order_id=${encodeURIComponent(orderId)}`
                }
            );


        const result =
            await response.text();


        if (!response.ok) {

            throw new Error(
                result ||
                "Delete failed"
            );
        }


        alert(
            "Order deleted successfully!"
        );


        await loadOrders();


        loadQueue();


    } catch (error) {

        console.error(
            "Error deleting order:",
            error
        );


        alert(
            "Unable to delete order.\n\n" +
            error.message
        );
    }
}


// ==========================================================
// CLEAR FORM
// ==========================================================

function clearForm() {

    document
        .getElementById("orderForm")
        .reset();


    editingOrderId =
        null;


    document.querySelector(
        "#orderForm button[type='submit']"
    ).textContent =
        "Save Order";
}


// ==========================================================
// CLEAR BUTTON
// ==========================================================

document
    .getElementById("clearButton")
    .addEventListener(
        "click",
        function () {

            clearForm();

        }
    );


// ==========================================================
// SEARCH ORDERS
// ==========================================================

document
    .getElementById("searchInput")
    .addEventListener(
        "input",
        function () {

            const searchValue =
                this.value
                    .trim()
                    .toLowerCase();


            if (
                searchValue === ""
            ) {

                displayOrders(
                    orders
                );

                return;
            }


            const filteredOrders =
                orders.filter(
                    order =>

                        String(
                            order.order_id
                        )
                            .toLowerCase()
                            .includes(
                                searchValue
                            )

                        ||

                        String(
                            order.customer_id
                        )
                            .toLowerCase()
                            .includes(
                                searchValue
                            )

                        ||

                        String(
                            order.order_date
                        )
                            .toLowerCase()
                            .includes(
                                searchValue
                            )

                        ||

                        String(
                            order.total_amount
                        )
                            .toLowerCase()
                            .includes(
                                searchValue
                            )

                        ||

                        String(
                            order.status
                        )
                            .toLowerCase()
                            .includes(
                                searchValue
                            )
                );


            displayOrders(
                filteredOrders
            );

        }
    );


// ==========================================================
// MODULE 2 - LOAD QUEUE
// ==========================================================

async function loadQueue() {

    try {

        const response =
            await fetch(
                QUEUE_API
            );


        const resultBox =
            document.getElementById(
                "queueResult"
            );


        if (!response.ok) {

            resultBox.textContent =
                "Unable to load queue.";

            return;
        }


        const queue =
            await response.json();


        if (
            !Array.isArray(queue) ||
            queue.length === 0
        ) {

            resultBox.textContent =
                "Queue is empty.";

            return;
        }


        let output =
            "Queue Order (FIFO):\n\n";


        queue.forEach(
            (order, index) => {

                output +=

                    (index + 1) +
                    ". Order ID: " +
                    order.order_id +
                    " | Customer ID: " +
                    order.customer_id +
                    " | Total: ₹" +
                    parseFloat(
                        order.total_amount
                    ).toFixed(2) +
                    " | Status: " +
                    order.status +
                    "\n";
            }
        );


        resultBox.textContent =
            output;


    } catch (error) {

        console.error(
            "Error loading queue:",
            error
        );


        document.getElementById(
            "queueResult"
        ).textContent =
            "Unable to connect to the Java server.";
    }
}


// ==========================================================
// VIEW QUEUE
// ==========================================================

document
    .getElementById(
        "viewQueueButton"
    )
    .addEventListener(
        "click",
        function () {

            loadQueue();

        }
    );


// ==========================================================
// PEEK NEXT ORDER
// ==========================================================

document
    .getElementById(
        "peekQueueButton"
    )
    .addEventListener(
        "click",
        async function () {

            const resultBox =
                document.getElementById(
                    "queueResult"
                );


            try {

                const response =
                    await fetch(
                        QUEUE_API,
                        {

                            method: "POST",

                            headers: {

                                "Content-Type":
                                    "application/x-www-form-urlencoded"

                            },

                            body:
                                "action=peek"
                        }
                    );


                const result =
                    await response.json();


                if (!response.ok) {

                    resultBox.textContent =
                        result.error ||
                        "Queue is empty.";

                    return;
                }


                resultBox.textContent =

                    "Next Order to Process:\n\n" +

                    "Order ID: " +
                    result.order_id +

                    "\nCustomer ID: " +
                    result.customer_id +

                    "\nOrder Date: " +
                    result.order_date +

                    "\nTotal Amount: ₹" +
                    parseFloat(
                        result.total_amount
                    ).toFixed(2) +

                    "\nStatus: " +
                    result.status;


            } catch (error) {

                console.error(
                    "Queue peek error:",
                    error
                );


                resultBox.textContent =
                    "Unable to connect to the Java server.";
            }
        }
    );


// ==========================================================
// PROCESS NEXT ORDER
// ==========================================================

document
    .getElementById(
        "processQueueButton"
    )
    .addEventListener(
        "click",
        async function () {

            const resultBox =
                document.getElementById(
                    "queueResult"
                );


            try {

                const response =
                    await fetch(
                        QUEUE_API,
                        {

                            method: "POST",

                            headers: {

                                "Content-Type":
                                    "application/x-www-form-urlencoded"

                            },

                            body:
                                "action=process"
                        }
                    );


                const result =
                    await response.json();


                if (!response.ok) {

                    resultBox.textContent =
                        result.error ||
                        "Queue is empty.";

                    return;
                }


                resultBox.textContent =

                    "Order Processed from Queue:\n\n" +

                    "Order ID: " +
                    result.order_id +

                    "\nCustomer ID: " +
                    result.customer_id +

                    "\nOrder Date: " +
                    result.order_date +

                    "\nTotal Amount: ₹" +
                    parseFloat(
                        result.total_amount
                    ).toFixed(2) +

                    "\nStatus: " +
                    result.status;


                /*
                 * Refresh queue after processing.
                 */

                setTimeout(
                    loadQueue,
                    300
                );


            } catch (error) {

                console.error(
                    "Queue process error:",
                    error
                );


                resultBox.textContent =
                    "Unable to process the order.";
            }
        }
    );


// ==========================================================
// MODULE 2 - EXPRESSION STACK
// ==========================================================

document
    .getElementById(
        "evaluateExpressionButton"
    )
    .addEventListener(
        "click",
        async function () {

            const expressionInput =
                document.getElementById(
                    "expressionInput"
                );


            const resultBox =
                document.getElementById(
                    "expressionResult"
                );


            const expression =
                expressionInput.value.trim();


            if (!expression) {

                resultBox.textContent =
                    "Please enter an expression.";

                return;
            }


            try {

                const response =
                    await fetch(
                        STACK_API,
                        {

                            method: "POST",

                            headers: {

                                "Content-Type":
                                    "application/x-www-form-urlencoded"

                            },

                            body:
                                "expression=" +
                                encodeURIComponent(
                                    expression
                                )
                        }
                    );


                const result =
                    await response.json();


                if (!response.ok) {

                    resultBox.textContent =
                        result.error ||
                        "Unable to evaluate expression.";

                    return;
                }


                resultBox.textContent =

                    "Expression: " +
                    result.expression +

                    "\nResult: " +
                    result.result;


            } catch (error) {

                console.error(
                    "Expression Stack error:",
                    error
                );


                resultBox.textContent =
                    "Unable to connect to the Java server.";
            }
        }
    );


// ==========================================================
// LOAD ORDERS WHEN PAGE OPENS
// ==========================================================

loadOrders();


// ==========================================================
// LOAD QUEUE WHEN PAGE OPENS
// ==========================================================

loadQueue();