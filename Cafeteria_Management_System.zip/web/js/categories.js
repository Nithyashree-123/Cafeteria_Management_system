const CATEGORY_API =
    "http://localhost:8080/api/categories";


const categoryForm =
    document.getElementById("categoryForm");

const categoryId =
    document.getElementById("categoryId");

const categoryName =
    document.getElementById("categoryName");

const clearButton =
    document.getElementById("clearButton");

const searchInput =
    document.getElementById("searchInput");

const categoryTableBody =
    document.getElementById("categoryTableBody");


let categories = [];


// ==========================================================
// LOAD CATEGORIES
// ==========================================================

async function loadCategories() {

    try {

        const response =
            await fetch(CATEGORY_API);

        if (!response.ok) {

            throw new Error(
                "Unable to load categories."
            );
        }

        categories =
            await response.json();

        displayCategories(categories);

    } catch (error) {

        console.error(
            "Error loading categories:",
            error
        );

        alert(
            "Unable to load categories.\n\n" +
            "Make sure the Java server is running."
        );
    }
}


// ==========================================================
// DISPLAY CATEGORIES
// ==========================================================

function displayCategories(data) {

    categoryTableBody.innerHTML = "";


    if (data.length === 0) {

        categoryTableBody.innerHTML = `
            <tr>
                <td colspan="3">
                    No categories found.
                </td>
            </tr>
        `;

        return;
    }


    data.forEach(category => {

        const row =
            document.createElement("tr");


        row.innerHTML = `
            <td>
                ${category.categoryId}
            </td>

            <td>
                ${escapeHtml(
                    category.categoryName
                )}
            </td>

            <td>

                <button
                    type="button"
                    onclick="editCategory(
                        ${category.categoryId}
                    )"
                >
                    Edit
                </button>

                <button
                    type="button"
                    onclick="deleteCategory(
                        ${category.categoryId}
                    )"
                >
                    Delete
                </button>

            </td>
        `;


        categoryTableBody.appendChild(row);

    });
}


// ==========================================================
// ADD / UPDATE CATEGORY
// ==========================================================

categoryForm.addEventListener(
    "submit",
    async function (event) {

        event.preventDefault();


        const id =
            Number(
                categoryId.value.trim()
            );

        const name =
            categoryName.value.trim();


        if (!id || !name) {

            alert(
                "Please enter Category ID " +
                "and Category Name."
            );

            return;
        }


        /*
         * The Java server reads URL-encoded
         * form parameters.
         */

        const formData =
            new URLSearchParams();


        formData.append(
            "categoryId",
            id
        );

        formData.append(
            "categoryName",
            name
        );


        try {

            const response =
                await fetch(
                    CATEGORY_API,
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/x-www-form-urlencoded"
                        },

                        body:
                            formData.toString()
                    }
                );


            const result =
                await response.json();


            if (!response.ok) {

                alert(
                    result.message ||
                    "Unable to save category."
                );

                return;
            }


            alert(
                result.message ||
                "Category saved successfully!"
            );


            clearForm();


            /*
             * Load again from MySQL
             * through the Java server.
             */

            await loadCategories();

        } catch (error) {

            console.error(
                "Error saving category:",
                error
            );

            alert(
                "Unable to save category.\n\n" +
                "Make sure the Java server is running."
            );
        }
    }
);


// ==========================================================
// EDIT CATEGORY
// ==========================================================

async function editCategory(id) {

    try {

        const response =
            await fetch(
                `${CATEGORY_API}?id=${id}`
            );


        if (!response.ok) {

            throw new Error(
                "Unable to get category."
            );
        }


        const category =
            await response.json();


        categoryId.value =
            category.categoryId;


        categoryName.value =
            category.categoryName;


        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });


    } catch (error) {

        console.error(
            "Error loading category:",
            error
        );


        alert(
            "Unable to load category for editing."
        );
    }
}


// ==========================================================
// DELETE CATEGORY
// ==========================================================

async function deleteCategory(id) {


    const confirmDelete =
        confirm(
            "Are you sure you want to delete " +
            "this category?"
        );


    if (!confirmDelete) {

        return;
    }


    const formData =
        new URLSearchParams();


    formData.append(
        "action",
        "delete"
    );


    formData.append(
        "categoryId",
        id
    );


    try {

        const response =
            await fetch(
                CATEGORY_API,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/x-www-form-urlencoded"
                    },

                    body:
                        formData.toString()
                }
            );


        const result =
            await response.json();


        if (!response.ok) {

            alert(
                result.message ||
                "Unable to delete category."
            );

            return;
        }


        alert(
            result.message ||
            "Category deleted successfully!"
        );


        /*
         * Reload from MySQL.
         */

        await loadCategories();


    } catch (error) {

        console.error(
            "Error deleting category:",
            error
        );


        alert(
            "Unable to delete category.\n\n" +
            "Make sure the Java server is running."
        );
    }
}


// ==========================================================
// SEARCH CATEGORIES
// ==========================================================

searchInput.addEventListener(
    "input",
    function () {


        const searchText =
            searchInput.value
                .trim()
                .toLowerCase();


        if (searchText === "") {

            displayCategories(
                categories
            );

            return;
        }


        const filteredCategories =
            categories.filter(
                category => {

                    return (

                        String(
                            category.categoryId
                        )
                            .toLowerCase()
                            .includes(
                                searchText
                            )

                        ||

                        String(
                            category.categoryName
                        )
                            .toLowerCase()
                            .includes(
                                searchText
                            )

                    );
                }
            );


        displayCategories(
            filteredCategories
        );
    }
);


// ==========================================================
// CLEAR BUTTON
// ==========================================================

clearButton.addEventListener(
    "click",
    function () {

        clearForm();

    }
);


// ==========================================================
// CLEAR FORM
// ==========================================================

function clearForm() {

    categoryForm.reset();

    categoryId.value = "";

    categoryName.value = "";
}


// ==========================================================
// HTML ESCAPE
// ==========================================================

function escapeHtml(value) {

    return String(value)
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );
}


// ==========================================================
// LOAD DATA WHEN PAGE OPENS
// ==========================================================

loadCategories();