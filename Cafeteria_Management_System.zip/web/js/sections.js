const SECTION_API = "http://localhost:8080/api/sections";

const sectionForm = document.getElementById("sectionForm");
const sectionId = document.getElementById("sectionId");
const sectionName = document.getElementById("sectionName");
const description = document.getElementById("description");
const clearButton = document.getElementById("clearButton");
const searchInput = document.getElementById("searchInput");
const sectionTableBody = document.getElementById("sectionTableBody");

let sections = [];

// ==========================================================
// LOAD SECTIONS FROM MYSQL THROUGH JAVA SERVER
// ==========================================================

async function loadSections() {
    try {
        const response = await fetch(SECTION_API);

        if (!response.ok) {
            throw new Error("Unable to load sections.");
        }

        sections = await response.json();
        displaySections(sections);

    } catch (error) {
        console.error("Error loading sections:", error);

        alert(
            "Unable to load sections.\n\n" +
            "Make sure the Java server is running."
        );
    }
}

// ==========================================================
// DISPLAY SECTIONS
// ==========================================================

function displaySections(data) {
    sectionTableBody.innerHTML = "";

    if (data.length === 0) {
        sectionTableBody.innerHTML = `
            <tr>
                <td colspan="4">No sections found.</td>
            </tr>
        `;
        return;
    }

    data.forEach(section => {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${section.sectionId}</td>

            <td>
                ${escapeHtml(section.sectionName)}
            </td>

            <td>
                ${escapeHtml(section.description || "")}
            </td>

            <td>
                <button
                    type="button"
                    onclick="editSection(${section.sectionId})"
                >
                    Edit
                </button>

                <button
                    type="button"
                    onclick="deleteSection(${section.sectionId})"
                >
                    Delete
                </button>
            </td>
        `;

        sectionTableBody.appendChild(row);
    });
}

// ==========================================================
// ADD / UPDATE SECTION
// ==========================================================

sectionForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    const id = Number(sectionId.value.trim());
    const name = sectionName.value.trim();
    const desc = description.value.trim();

    if (!id || !name) {
        alert("Please enter Section ID and Section Name.");
        return;
    }

    const formData = new URLSearchParams();

    formData.append("sectionId", id);
    formData.append("sectionName", name);
    formData.append("description", desc);

    try {
        const response = await fetch(SECTION_API, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: formData.toString()
        });

        const result = await response.json();

        if (!response.ok) {
            alert(result.message || "Unable to save section.");
            return;
        }

        alert(result.message || "Section saved successfully!");

        clearForm();
        await loadSections();

    } catch (error) {
        console.error("Error saving section:", error);

        alert(
            "Unable to save section.\n\n" +
            "Make sure the Java server is running."
        );
    }
});

// ==========================================================
// EDIT SECTION
// ==========================================================

async function editSection(id) {
    try {
        const response = await fetch(`${SECTION_API}?id=${id}`);

        if (!response.ok) {
            throw new Error("Unable to get section.");
        }

        const section = await response.json();

        sectionId.value = section.sectionId;
        sectionName.value = section.sectionName;
        description.value = section.description || "";

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    } catch (error) {
        console.error("Error loading section:", error);
        alert("Unable to load section for editing.");
    }
}

// ==========================================================
// DELETE SECTION
// ==========================================================

async function deleteSection(id) {
    const confirmDelete = confirm(
        "Are you sure you want to delete this section?"
    );

    if (!confirmDelete) {
        return;
    }

    const formData = new URLSearchParams();

    formData.append("action", "delete");
    formData.append("sectionId", id);

    try {
        const response = await fetch(SECTION_API, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: formData.toString()
        });

        const result = await response.json();

        if (!response.ok) {
            alert(result.message || "Unable to delete section.");
            return;
        }

        alert(result.message || "Section deleted successfully!");

        await loadSections();

    } catch (error) {
        console.error("Error deleting section:", error);

        alert(
            "Unable to delete section.\n\n" +
            "Make sure the Java server is running."
        );
    }
}

// ==========================================================
// SEARCH SECTIONS
// ==========================================================

searchInput.addEventListener("input", function () {
    const searchText = searchInput.value.trim().toLowerCase();

    if (searchText === "") {
        displaySections(sections);
        return;
    }

    const filteredSections = sections.filter(section => {
        return (
            String(section.sectionId)
                .toLowerCase()
                .includes(searchText) ||

            String(section.sectionName)
                .toLowerCase()
                .includes(searchText) ||

            String(section.description || "")
                .toLowerCase()
                .includes(searchText)
        );
    });

    displaySections(filteredSections);
});

// ==========================================================
// CLEAR BUTTON
// ==========================================================

clearButton.addEventListener("click", function () {
    clearForm();
});

// ==========================================================
// CLEAR FORM
// ==========================================================

function clearForm() {
    sectionForm.reset();

    sectionId.value = "";
    sectionName.value = "";
    description.value = "";
}

// ==========================================================
// HTML ESCAPE
// Prevent HTML injection when displaying database data
// ==========================================================

function escapeHtml(value) {
    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// ==========================================================
// LOAD DATA WHEN PAGE OPENS
// ==========================================================

loadSections();