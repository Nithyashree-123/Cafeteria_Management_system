// ==========================================
// CAFETERIA MANAGEMENT SYSTEM
// MODULE 1: LINKED LIST - MENU MANAGEMENT
// MODULE 5: SEARCHING AND SORTING
// ==========================================

const MENU_API = "http://localhost:8080/api/menu-items";

let allMenuItems = [];
let currentMenuItems = [];
let currentView = "all";


// ==========================================
// DISPLAY MENU ITEMS
// ==========================================

function displayMenuItems(items) {
    const tableBody = document.getElementById("menuTableBody");

    tableBody.innerHTML = "";

    if (!items || items.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="6">No menu items found.</td>
            </tr>
        `;
        return;
    }

    items.forEach(function (item) {
        const row = document.createElement("tr");

        const availability = item.available === true
            ? `<span class="available">Available</span>`
            : `<span class="not-available">Not Available</span>`;

        row.innerHTML = `
            <td>${escapeHtml(item.itemId)}</td>
            <td>${escapeHtml(item.itemName)}</td>
            <td>${escapeHtml(item.categoryId)}</td>
            <td>₹${Number(item.price).toFixed(2)}</td>
            <td>${availability}</td>
            <td>
                <button
                    type="button"
                    class="edit-btn"
                    onclick="editMenuItem(${Number(item.itemId)})">
                    Edit
                </button>

                <button
                    type="button"
                    class="delete-btn"
                    onclick="deleteMenuItem(${Number(item.itemId)})">
                    Delete
                </button>
            </td>
        `;

        tableBody.appendChild(row);
    });
}


// ==========================================
// ESCAPE HTML
// ==========================================

function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, function (character) {
        const entities = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#39;"
        };

        return entities[character];
    });
}


// ==========================================
// LOAD MENU ITEMS FROM JAVA SERVER
// ==========================================

async function loadMenuItems() {
    const tableBody = document.getElementById("menuTableBody");

    tableBody.innerHTML = `
        <tr>
            <td colspan="6">Loading menu items...</td>
        </tr>
    `;

    try {
        const response = await fetch(MENU_API);

        if (!response.ok) {
            throw new Error("Server returned status " + response.status);
        }

        const menuItems = await response.json();

        allMenuItems = Array.isArray(menuItems) ? menuItems : [];
        currentMenuItems = [...allMenuItems];
        currentView = "all";

        displayMenuItems(currentMenuItems);
        setAlgorithmStatus("Menu items loaded successfully.");
    } catch (error) {
        console.error("Error loading menu items:", error);

        tableBody.innerHTML = `
            <tr>
                <td colspan="6">
                    Unable to load menu items.
                    Make sure the Java server is running.
                </td>
            </tr>
        `;

        setAlgorithmStatus("Unable to load menu items.");
    }
}


// ==========================================
// ALGORITHM STATUS
// ==========================================

function setAlgorithmStatus(message) {
    const status = document.getElementById("algorithmStatus");

    if (status) {
        status.textContent = message;
    }
}


// ==========================================
// GET LATEST MENU ITEMS
// ==========================================

async function getLatestMenuItems() {
    const response = await fetch(MENU_API);

    if (!response.ok) {
        throw new Error("Unable to retrieve menu items.");
    }

    const items = await response.json();

    allMenuItems = Array.isArray(items) ? items : [];

    return [...allMenuItems];
}


// ==========================================
// EXISTING SEARCH
// Search by ID, name, or category ID
// ==========================================

const searchInput = document.getElementById("searchInput");

searchInput.addEventListener("input", function () {
    const searchValue = this.value.toLowerCase().trim();

    currentView = "filter";

    if (searchValue === "") {
        currentMenuItems = [...allMenuItems];
        displayMenuItems(currentMenuItems);
        setAlgorithmStatus("Showing all menu items.");
        return;
    }

    const filteredItems = allMenuItems.filter(function (item) {
        return (
            String(item.itemId).includes(searchValue) ||
            String(item.itemName).toLowerCase().includes(searchValue) ||
            String(item.categoryId).includes(searchValue)
        );
    });

    currentMenuItems = filteredItems;

    displayMenuItems(filteredItems);

    setAlgorithmStatus(
        filteredItems.length + " matching menu item(s) found."
    );
});


// ==========================================
// MODULE 5: LINEAR SEARCH
// Search by Item ID
// ==========================================

async function linearSearch() {
    const input = searchInput.value.trim();

    if (input === "" || !/^\d+$/.test(input)) {
        alert("Please enter a valid Item ID in the search box.");
        searchInput.focus();
        return;
    }

    try {
        const items = await getLatestMenuItems();
        const targetId = Number(input);

        let foundItem = null;
        let comparisons = 0;

        // Check items one by one
        for (let i = 0; i < items.length; i++) {
            comparisons++;

            if (Number(items[i].itemId) === targetId) {
                foundItem = items[i];
                break;
            }
        }

        currentView = "linear";
        currentMenuItems = foundItem ? [foundItem] : [];

        displayMenuItems(currentMenuItems);

        if (foundItem) {
            setAlgorithmStatus(
                "Linear Search: Item found after " +
                comparisons + " comparison(s)."
            );
        } else {
            setAlgorithmStatus(
                "Linear Search: Item ID " + targetId + " not found."
            );
        }
    } catch (error) {
        console.error("Linear Search error:", error);
        setAlgorithmStatus("Linear Search failed. Check the server.");
    }
}


// ==========================================
// MODULE 5: BINARY SEARCH
// Search by Item ID in sorted data
// ==========================================

async function binarySearch() {
    const input = searchInput.value.trim();

    if (input === "" || !/^\d+$/.test(input)) {
        alert("Please enter a valid Item ID in the search box.");
        searchInput.focus();
        return;
    }

    try {
        const items = await getLatestMenuItems();

        // Binary Search requires data sorted by Item ID
        const sortedItems = [...items].sort(function (a, b) {
            return Number(a.itemId) - Number(b.itemId);
        });

        const targetId = Number(input);

        let left = 0;
        let right = sortedItems.length - 1;
        let foundItem = null;
        let comparisons = 0;

        while (left <= right) {
            const middle = Math.floor((left + right) / 2);

            comparisons++;

            const middleId = Number(sortedItems[middle].itemId);

            if (middleId === targetId) {
                foundItem = sortedItems[middle];
                break;
            }

            if (middleId < targetId) {
                left = middle + 1;
            } else {
                right = middle - 1;
            }
        }

        currentView = "binary";
        currentMenuItems = foundItem ? [foundItem] : [];

        displayMenuItems(currentMenuItems);

        if (foundItem) {
            setAlgorithmStatus(
                "Binary Search: Item found after " +
                comparisons + " comparison(s)."
            );
        } else {
            setAlgorithmStatus(
                "Binary Search: Item ID " + targetId + " not found."
            );
        }
    } catch (error) {
        console.error("Binary Search error:", error);
        setAlgorithmStatus("Binary Search failed. Check the server.");
    }
}


// ==========================================
// MODULE 5: BUBBLE SORT
// Sort by price: lowest to highest
// ==========================================

async function bubbleSort() {
    try {
        const items = await getLatestMenuItems();

        const sortedItems = [...items];

        let comparisons = 0;
        let swaps = 0;

        // Bubble Sort
        for (let i = 0; i < sortedItems.length - 1; i++) {
            let swapped = false;

            for (let j = 0; j < sortedItems.length - i - 1; j++) {
                comparisons++;

                if (
                    Number(sortedItems[j].price) >
                    Number(sortedItems[j + 1].price)
                ) {
                    const temporary = sortedItems[j];

                    sortedItems[j] = sortedItems[j + 1];
                    sortedItems[j + 1] = temporary;

                    swapped = true;
                    swaps++;
                }
            }

            // Stop early if no swaps occurred
            if (!swapped) {
                break;
            }
        }

        currentView = "sorted";
        currentMenuItems = sortedItems;

        displayMenuItems(sortedItems);

        setAlgorithmStatus(
            "Bubble Sort completed! Sorted by price (lowest to highest). " +
            "Comparisons: " + comparisons +
            ", swaps: " + swaps + "."
        );
    } catch (error) {
        console.error("Bubble Sort error:", error);
        setAlgorithmStatus("Bubble Sort failed. Check the server.");
    }
}


// ==========================================
// MODULE 5: SHOW ALL MENU ITEMS
// ==========================================

function showAllMenuItems() {
    searchInput.value = "";

    currentView = "all";
    currentMenuItems = [...allMenuItems];

    displayMenuItems(currentMenuItems);

    setAlgorithmStatus("Showing all menu items.");
}


// ==========================================
// CONNECT MODULE 5 BUTTONS
// ==========================================

document
    .getElementById("linearSearchButton")
    .addEventListener("click", linearSearch);

document
    .getElementById("binarySearchButton")
    .addEventListener("click", binarySearch);

document
    .getElementById("bubbleSortButton")
    .addEventListener("click", bubbleSort);

document
    .getElementById("resetMenuButton")
    .addEventListener("click", showAllMenuItems);


// ==========================================
// CLEAR BUTTON
// ==========================================

document
    .getElementById("clearButton")
    .addEventListener("click", function () {
        document.getElementById("menuForm").reset();
    });


// ==========================================
// ADD MENU ITEM
// ==========================================

document
    .getElementById("menuForm")
    .addEventListener("submit", async function (event) {
        event.preventDefault();

        const itemId = document.getElementById("itemId").value.trim();
        const itemName = document.getElementById("itemName").value.trim();
        const categoryId = document.getElementById("categoryId").value.trim();
        const price = document.getElementById("price").value.trim();

        const availabilityValue =
            document.getElementById("available").value;

        if (
            itemId === "" ||
            itemName === "" ||
            categoryId === "" ||
            price === ""
        ) {
            alert("Please fill all menu item fields.");
            return;
        }

        if (availabilityValue === "") {
            alert("Please select availability.");
            return;
        }

        if (
            Number(itemId) <= 0 ||
            Number(categoryId) <= 0 ||
            Number(price) < 0 ||
            !Number.isFinite(Number(price))
        ) {
            alert("Enter valid IDs and a valid price.");
            return;
        }

        const formData = new URLSearchParams();

        formData.append("action", "add");
        formData.append("itemId", itemId);
        formData.append("itemName", itemName);
        formData.append("categoryId", categoryId);
        formData.append("price", price);
        formData.append("available", availabilityValue === "1");

        try {
            const response = await fetch(MENU_API, {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: formData.toString()
            });

            const result = await response.json();

            if (!response.ok) {
                alert(result.error || "Failed to add menu item.");
                return;
            }

            alert("Menu item added successfully!");

            document.getElementById("menuForm").reset();

            await loadMenuItems();
        } catch (error) {
            console.error("Error adding menu item:", error);
            alert("Unable to connect to the Java server.");
        }
    });


// ==========================================
// EDIT MENU ITEM
// ==========================================

async function editMenuItem(itemId) {
    const existingItem = allMenuItems.find(function (item) {
        return Number(item.itemId) === Number(itemId);
    });

    if (!existingItem) {
        alert("Menu item not found.");
        return;
    }

    const itemName = prompt("Enter new item name:", existingItem.itemName);

    if (itemName === null || itemName.trim() === "") {
        return;
    }

    const categoryId = prompt(
        "Enter category ID:",
        existingItem.categoryId
    );

    if (
        categoryId === null ||
        categoryId.trim() === "" ||
        !Number.isFinite(Number(categoryId))
    ) {
        return;
    }

    const price = prompt("Enter price:", existingItem.price);

    if (
        price === null ||
        price.trim() === "" ||
        !Number.isFinite(Number(price)) ||
        Number(price) < 0
    ) {
        return;
    }

    const available = confirm("Is this item available?");

    const formData = new URLSearchParams();

    formData.append("action", "update");
    formData.append("itemId", itemId);
    formData.append("itemName", itemName.trim());
    formData.append("categoryId", categoryId.trim());
    formData.append("price", price.trim());
    formData.append("available", available);

    try {
        const response = await fetch(MENU_API, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: formData.toString()
        });

        const result = await response.json();

        if (!response.ok) {
            alert(result.error || "Failed to update menu item.");
            return;
        }

        alert("Menu item updated successfully!");

        await loadMenuItems();
    } catch (error) {
        console.error("Update error:", error);
        alert("Unable to connect to the Java server.");
    }
}


// ==========================================
// DELETE MENU ITEM
// ==========================================

async function deleteMenuItem(itemId) {
    const confirmDelete = confirm(
        "Are you sure you want to delete Item ID " + itemId + "?"
    );

    if (!confirmDelete) {
        return;
    }

    const formData = new URLSearchParams();

    formData.append("action", "delete");
    formData.append("itemId", itemId);

    try {
        const response = await fetch(MENU_API, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: formData.toString()
        });

        const result = await response.json();

        if (!response.ok) {
            alert(result.error || "Failed to delete menu item.");
            return;
        }

        alert("Menu item deleted successfully!");

        await loadMenuItems();
    } catch (error) {
        console.error("Delete error:", error);
        alert("Unable to connect to the Java server.");
    }
}


// ==========================================
// START APPLICATION
// ==========================================

loadMenuItems();