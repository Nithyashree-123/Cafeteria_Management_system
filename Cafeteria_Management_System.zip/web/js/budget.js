// =====================================================
// CAFETERIA MANAGEMENT SYSTEM
// MODULE 6 - GREEDY ALGORITHM
// BUDGET-BASED FOOD SELECTION
// =====================================================

document.addEventListener("DOMContentLoaded", function () {

    const budgetForm = document.getElementById("budgetForm");
    const budgetInput = document.getElementById("budget");
    const selectButton = document.getElementById("selectButton");

    const message = document.getElementById("message");
    const resultsSection = document.getElementById("resultsSection");

    const budgetAmount = document.getElementById("budgetAmount");
    const totalAmount = document.getElementById("totalAmount");
    const remainingAmount = document.getElementById("remainingAmount");

    const itemsTableBody = document.getElementById("itemsTableBody");
    const emptyMessage = document.getElementById("emptyMessage");

    const API_URL = "http://localhost:8080/api/budget-selection";

    // Format amounts as Indian Rupees.
    function formatCurrency(amount) {
        return new Intl.NumberFormat("en-IN", {
            style: "currency",
            currency: "INR",
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(amount);
    }

    // Display status messages.
    function showMessage(text, type) {
        message.textContent = text;
        message.className = type;
    }

    // Clear previous results.
    function clearResults() {
        resultsSection.hidden = true;
        itemsTableBody.replaceChildren();
        emptyMessage.hidden = true;
    }

    // Display the selected food items.
    function displayResults(data) {

        itemsTableBody.replaceChildren();

        budgetAmount.textContent = formatCurrency(data.budget);
        totalAmount.textContent = formatCurrency(data.total);
        remainingAmount.textContent =
            formatCurrency(data.remainingBudget);

        const items = Array.isArray(data.selectedItems)
            ? data.selectedItems
            : [];

        if (items.length === 0) {
            emptyMessage.hidden = false;
        } else {
            emptyMessage.hidden = true;

            items.forEach(function (item) {

                const row = document.createElement("tr");

                const idCell = document.createElement("td");
                idCell.textContent = item.itemId;

                const nameCell = document.createElement("td");
                nameCell.textContent = item.itemName;

                const priceCell = document.createElement("td");
                priceCell.textContent = formatCurrency(item.price);

                row.appendChild(idCell);
                row.appendChild(nameCell);
                row.appendChild(priceCell);

                itemsTableBody.appendChild(row);
            });
        }

        resultsSection.hidden = false;
    }

    // Submit the budget and request the Greedy Algorithm results.
    budgetForm.addEventListener("submit", async function (event) {

        event.preventDefault();

        const budget = Number(budgetInput.value);

        if (
            budgetInput.value.trim() === "" ||
            !Number.isFinite(budget) ||
            budget < 0
        ) {
            clearResults();
            showMessage(
                "Please enter a valid, non-negative budget.",
                "error"
            );
            return;
        }

        selectButton.disabled = true;
        selectButton.textContent = "Calculating...";
        clearResults();

        showMessage(
            "Finding affordable food items...",
            "success"
        );

        try {

            // The Java handler expects URL-encoded form data.
            const formData = new URLSearchParams();
            formData.append("budget", String(budget));

            const response = await fetch(API_URL, {
                method: "POST",
                headers: {
                    "Content-Type":
                        "application/x-www-form-urlencoded;charset=UTF-8"
                },
                body: formData.toString()
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(
                    data.error || "Unable to calculate food selection."
                );
            }

            displayResults(data);

            showMessage(
                "Affordable food items selected successfully!",
                "success"
            );

        } catch (error) {

            console.error("Budget selection error:", error);

            showMessage(
                error.message.includes("Failed to fetch")
                    ? "Cannot connect to the Java server. Start the server and try again."
                    : error.message,
                "error"
            );

        } finally {

            selectButton.disabled = false;
            selectButton.textContent = "Find Affordable Food";

        }
    });

});