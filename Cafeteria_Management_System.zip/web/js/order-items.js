const ORDER_ITEM_API =
    "http://localhost:8080/api/order-items";

const MENU_API =
    "http://localhost:8080/api/menu-items";


const orderItemForm =
    document.getElementById("orderItemForm");

const orderItemId =
    document.getElementById("orderItemId");

const orderId =
    document.getElementById("orderId");

const itemId =
    document.getElementById("itemId");

const quantity =
    document.getElementById("quantity");

const subtotal =
    document.getElementById("subtotal");

const clearButton =
    document.getElementById("clearButton");

const searchInput =
    document.getElementById("searchInput");

const orderItemTableBody =
    document.getElementById("orderItemTableBody");


let orderItems = [];


// ==========================================================
// LOAD ORDER ITEMS
// ==========================================================

async function loadOrderItems() {

    try {

        const response =
            await fetch(ORDER_ITEM_API);

        if (!response.ok) {

            throw new Error(
                "Unable to load order items."
            );
        }

        orderItems =
            await response.json();

        displayOrderItems(orderItems);

    } catch (error) {

        console.error(
            "Error loading order items:",
            error
        );

        alert(
            "Unable to load order items.\n\n" +
            "Make sure the Java server is running."
        );
    }
}


// ==========================================================
// GET PRICE FROM MENU ITEMS
// ==========================================================

async function getMenuItemPrice(selectedItemId) {

    try {

        /*
         * The Menu API currently returns ALL menu items.
         * So we fetch the list and find the required Item ID.
         */

        const response =
            await fetch(MENU_API);

        if (!response.ok) {

            throw new Error(
                "Unable to load menu items."
            );
        }


        const menuItems =
            await response.json();


        const menuItem =
            menuItems.find(
                item =>
                    Number(item.itemId) ===
                    Number(selectedItemId)
            );


        if (!menuItem) {

            throw new Error(
                "Menu item not found."
            );
        }


        const price =
            Number(menuItem.price);


        if (
            Number.isNaN(price) ||
            price < 0
        ) {

            throw new Error(
                "Invalid menu item price."
            );
        }


        return price;


    } catch (error) {

        console.error(
            "Error fetching menu item price:",
            error
        );

        return null;
    }
}


// ==========================================================
// CALCULATE SUBTOTAL
// ==========================================================

async function calculateSubtotal() {

    const selectedItemId =
        Number(
            itemId.value.trim()
        );


    const selectedQuantity =
        Number(
            quantity.value.trim()
        );


    if (
        !selectedItemId ||
        !selectedQuantity ||
        selectedQuantity <= 0
    ) {

        subtotal.value = "";

        return;
    }


    const price =
        await getMenuItemPrice(
            selectedItemId
        );


    if (price === null) {

        subtotal.value = "";

        return;
    }


    const calculatedSubtotal =
        price * selectedQuantity;


    subtotal.value =
        calculatedSubtotal.toFixed(2);
}


// ==========================================================
// ITEM ID CHANGE
// ==========================================================

itemId.addEventListener(
    "change",
    async function () {

        await calculateSubtotal();

    }
);


// ==========================================================
// ITEM ID INPUT
// ==========================================================

itemId.addEventListener(
    "input",
    async function () {

        await calculateSubtotal();

    }
);


// ==========================================================
// QUANTITY CHANGE
// ==========================================================

quantity.addEventListener(
    "change",
    async function () {

        await calculateSubtotal();

    }
);


// ==========================================================
// QUANTITY INPUT
// ==========================================================

quantity.addEventListener(
    "input",
    async function () {

        await calculateSubtotal();

    }
);


// ==========================================================
// DISPLAY ORDER ITEMS
// ==========================================================

function displayOrderItems(data) {

    orderItemTableBody.innerHTML = "";


    if (data.length === 0) {

        orderItemTableBody.innerHTML = `
            <tr>
                <td colspan="6">
                    No order items found.
                </td>
            </tr>
        `;

        return;
    }


    data.forEach(orderItem => {

        const row =
            document.createElement("tr");


        row.innerHTML = `
            <td>
                ${orderItem.orderItemId}
            </td>

            <td>
                ${orderItem.orderId}
            </td>

            <td>
                ${orderItem.itemId}
            </td>

            <td>
                ${orderItem.quantity}
            </td>

            <td>
                ${Number(
                    orderItem.subtotal
                ).toFixed(2)}
            </td>

            <td>

                <button
                    type="button"
                    onclick="editOrderItem(
                        ${orderItem.orderItemId}
                    )"
                >
                    Edit
                </button>

                <button
                    type="button"
                    onclick="deleteOrderItem(
                        ${orderItem.orderItemId}
                    )"
                >
                    Delete
                </button>

            </td>
        `;


        orderItemTableBody.appendChild(row);

    });
}


// ==========================================================
// ADD / UPDATE ORDER ITEM
// ==========================================================

orderItemForm.addEventListener(
    "submit",
    async function (event) {

        event.preventDefault();


        const id =
            Number(
                orderItemId.value.trim()
            );


        const selectedOrderId =
            Number(
                orderId.value.trim()
            );


        const selectedItemId =
            Number(
                itemId.value.trim()
            );


        const selectedQuantity =
            Number(
                quantity.value.trim()
            );


        // --------------------------------------------------
        // VALIDATION
        // --------------------------------------------------

        if (!id) {

            alert(
                "Please enter Order Item ID."
            );

            return;
        }


        if (!selectedOrderId) {

            alert(
                "Please enter Order ID."
            );

            return;
        }


        if (!selectedItemId) {

            alert(
                "Please enter Item ID."
            );

            return;
        }


        if (
            !selectedQuantity ||
            selectedQuantity <= 0
        ) {

            alert(
                "Please enter a valid quantity."
            );

            return;
        }


        // --------------------------------------------------
        // GET PRICE FROM MENU
        // --------------------------------------------------

        const price =
            await getMenuItemPrice(
                selectedItemId
            );


        if (price === null) {

            alert(
                "Item ID not found in Menu Items.\n\n" +
                "Please enter a valid Item ID."
            );

            subtotal.value = "";

            return;
        }


        // --------------------------------------------------
        // CALCULATE SUBTOTAL
        // --------------------------------------------------

        const selectedSubtotal =
            price * selectedQuantity;


        subtotal.value =
            selectedSubtotal.toFixed(2);


        // --------------------------------------------------
        // CREATE FORM DATA
        // --------------------------------------------------

        const formData =
            new URLSearchParams();


        formData.append(
            "orderItemId",
            id
        );


        formData.append(
            "orderId",
            selectedOrderId
        );


        formData.append(
            "itemId",
            selectedItemId
        );


        formData.append(
            "quantity",
            selectedQuantity
        );


        formData.append(
            "subtotal",
            selectedSubtotal.toFixed(2)
        );


        try {

            const response =
                await fetch(
                    ORDER_ITEM_API,
                    {
                        method: "POST",

                        headers: {
                            "Content-Type":
                                "application/x-www-form-urlencoded"
                        },

                        body:
                            formData.toString()
                    }
                );


            const result =
                await response.json();


            if (!response.ok) {

                alert(
                    result.message ||
                    result.error ||
                    "Unable to save order item."
                );

                return;
            }


            alert(
                result.message ||
                "Order item saved successfully!"
            );


            clearForm();


            // Reload directly from MySQL
            await loadOrderItems();


        } catch (error) {

            console.error(
                "Error saving order item:",
                error
            );


            alert(
                "Unable to save order item.\n\n" +
                "Make sure the Java server is running."
            );
        }
    }
);


// ==========================================================
// EDIT ORDER ITEM
// ==========================================================

async function editOrderItem(id) {

    try {

        const response =
            await fetch(
                `${ORDER_ITEM_API}?id=${id}`
            );


        if (!response.ok) {

            throw new Error(
                "Unable to get order item."
            );
        }


        const orderItem =
            await response.json();


        orderItemId.value =
            orderItem.orderItemId;


        orderId.value =
            orderItem.orderId;


        itemId.value =
            orderItem.itemId;


        quantity.value =
            orderItem.quantity;


        subtotal.value =
            Number(
                orderItem.subtotal
            ).toFixed(2);


        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });


    } catch (error) {

        console.error(
            "Error loading order item:",
            error
        );


        alert(
            "Unable to load order item for editing."
        );
    }
}


// ==========================================================
// DELETE ORDER ITEM
// ==========================================================

async function deleteOrderItem(id) {


    const confirmDelete =
        confirm(
            "Are you sure you want to delete " +
            "this order item?"
        );


    if (!confirmDelete) {

        return;
    }


    const formData =
        new URLSearchParams();


    formData.append(
        "action",
        "delete"
    );


    formData.append(
        "orderItemId",
        id
    );


    try {

        const response =
            await fetch(
                ORDER_ITEM_API,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/x-www-form-urlencoded"
                    },

                    body:
                        formData.toString()
                }
            );


        const result =
            await response.json();


        if (!response.ok) {

            alert(
                result.message ||
                result.error ||
                "Unable to delete order item."
            );

            return;
        }


        alert(
            result.message ||
            "Order item deleted successfully!"
        );


        // Reload from MySQL
        await loadOrderItems();


    } catch (error) {

        console.error(
            "Error deleting order item:",
            error
        );


        alert(
            "Unable to delete order item.\n\n" +
            "Make sure the Java server is running."
        );
    }
}


// ==========================================================
// SEARCH ORDER ITEMS
// ==========================================================

searchInput.addEventListener(
    "input",
    function () {


        const searchText =
            searchInput.value
                .trim()
                .toLowerCase();


        if (searchText === "") {

            displayOrderItems(
                orderItems
            );

            return;
        }


        const filteredOrderItems =
            orderItems.filter(
                orderItem => {

                    return (

                        String(
                            orderItem.orderItemId
                        )
                            .toLowerCase()
                            .includes(
                                searchText
                            )

                        ||

                        String(
                            orderItem.orderId
                        )
                            .toLowerCase()
                            .includes(
                                searchText
                            )

                        ||

                        String(
                            orderItem.itemId
                        )
                            .toLowerCase()
                            .includes(
                                searchText
                            )

                        ||

                        String(
                            orderItem.quantity
                        )
                            .toLowerCase()
                            .includes(
                                searchText
                            )

                        ||

                        String(
                            orderItem.subtotal
                        )
                            .toLowerCase()
                            .includes(
                                searchText
                            )

                    );
                }
            );


        displayOrderItems(
            filteredOrderItems
        );
    }
);


// ==========================================================
// CLEAR BUTTON
// ==========================================================

clearButton.addEventListener(
    "click",
    function () {

        clearForm();

    }
);


// ==========================================================
// CLEAR FORM
// ==========================================================

function clearForm() {

    orderItemForm.reset();

    orderItemId.value = "";

    orderId.value = "";

    itemId.value = "";

    quantity.value = "";

    subtotal.value = "";
}


// ==========================================================
// LOAD DATA WHEN PAGE OPENS
// ==========================================================

loadOrderItems();