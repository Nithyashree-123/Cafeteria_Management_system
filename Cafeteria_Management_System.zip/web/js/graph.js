/* =====================================================
   CAFETERIA MANAGEMENT SYSTEM
   MODULE 4: GRAPH AND BREADTH-FIRST SEARCH (BFS)
===================================================== */

const GRAPH_API = "http://localhost:8080/api/graph";

const cafeteriaAreas = {
    0: "Order Counter",
    1: "Kitchen",
    2: "Billing Area",
    3: "Pickup Area",
    4: "Dining Area",
    5: "Storage Area"
};

document.addEventListener("DOMContentLoaded", function () {

    const graphSource = document.getElementById("graphSource");
    const graphDestination = document.getElementById("graphDestination");
    const bfsStartVertex = document.getElementById("bfsStartVertex");

    const addEdgeButton = document.getElementById("addEdgeButton");
    const displayGraphButton = document.getElementById("displayGraphButton");
    const runBfsButton = document.getElementById("runBfsButton");

    const addConnectionMessage =
        document.getElementById("addConnectionMessage");

    const graphVisual = document.getElementById("graphVisual");
    const graphOutput = document.getElementById("graphOutput");
    const bfsOutput = document.getElementById("bfsOutput");

    if (
        !graphSource ||
        !graphDestination ||
        !bfsStartVertex ||
        !addEdgeButton ||
        !displayGraphButton ||
        !runBfsButton ||
        !addConnectionMessage ||
        !graphVisual ||
        !graphOutput ||
        !bfsOutput
    ) {
        console.error(
            "Graph initialization failed. Check the element IDs in graph.html."
        );
        return;
    }

    // Display success or error messages.
    function showConnectionMessage(message, success) {
        addConnectionMessage.textContent = message;
        addConnectionMessage.style.display = "block";

        if (success) {
            addConnectionMessage.style.backgroundColor = "#e5f5e8";
            addConnectionMessage.style.color = "#245c32";
            addConnectionMessage.style.borderLeftColor = "#2e8b45";
        } else {
            addConnectionMessage.style.backgroundColor = "#fde9e7";
            addConnectionMessage.style.color = "#8b1e16";
            addConnectionMessage.style.borderLeftColor = "#c0392b";
        }
    }

    // Convert vertex number to cafeteria area name.
    function getAreaName(vertex) {
        return cafeteriaAreas[Number(vertex)] ?? `Vertex ${vertex}`;
    }

    // Convert BFS results to area names.
    function convertVerticesToNames(vertexList) {
        const vertices = String(vertexList ?? "").trim();

        if (!vertices) {
            return "No connected areas found.";
        }

        return vertices
            .split(/\s+/)
            .filter(Boolean)
            .map(getAreaName)
            .join(" → ");
    }

    // Communicate with the Java backend.
    async function sendGraphRequest(parameters) {
        let response;

        try {
            response = await fetch(GRAPH_API, {
                method: "POST",
                headers: {
                    "Content-Type":
                        "application/x-www-form-urlencoded;charset=UTF-8"
                },
                body: new URLSearchParams(parameters)
            });
        } catch (error) {
            throw new Error(
                "Cannot connect to the backend. Check whether Tomcat is running."
            );
        }

        const responseText = await response.text();

        let data;

        try {
            data = JSON.parse(responseText);
        } catch (error) {
            console.error("Backend response:", responseText);

            throw new Error(
                "The backend did not return valid JSON. Check the Java API."
            );
        }

        if (!response.ok || data.error) {
            throw new Error(
                data.error || `Server error: ${response.status}`
            );
        }

        return data;
    }

    // Draw the cafeteria graph using SVG.
    function drawVisualGraph(graphText) {

        const width = 800;
        const height = 440;
        const radius = 48;

        const positions = {
    0: { x: 400, y: 60 },   // Order Counter
    1: { x: 250, y: 160 },  // Kitchen
    2: { x: 550, y: 160 },  // Billing Area
    3: { x: 550, y: 280 },  // Pickup Area
    4: { x: 400, y: 350 },  // Dining Area
    5: { x: 250, y: 280 }   // Storage Area
};

        const svgNS = "http://www.w3.org/2000/svg";
        const edges = [];

        // Read the adjacency list returned by Java.
        graphText.split(/\r?\n/).forEach(function (line) {

            const match = line.match(/^\s*(\d+)\s*->\s*(.*)$/);

            if (!match) {
                return;
            }

            const source = Number(match[1]);
            const neighbours = match[2].trim();

            if (!positions[source] || !neighbours) {
                return;
            }

            neighbours.split(/\s+/).forEach(function (value) {

                if (!/^\d+$/.test(value)) {
                    return;
                }

                const destination = Number(value);

                if (
                    !positions[destination] ||
                    source === destination
                ) {
                    return;
                }

                // Avoid drawing the same undirected edge twice.
                const alreadyExists = edges.some(function (edge) {
                    return (
                        (edge.source === source &&
                            edge.destination === destination) ||
                        (edge.source === destination &&
                            edge.destination === source)
                    );
                });

                if (!alreadyExists) {
                    edges.push({
                        source: source,
                        destination: destination
                    });
                }
            });
        });

        const svg = document.createElementNS(svgNS, "svg");

        svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
        svg.setAttribute("role", "img");
        svg.setAttribute(
            "aria-label",
            "Visual graph of cafeteria areas and their connections"
        );

        // Draw connection lines.
        edges.forEach(function (edge) {

            const start = positions[edge.source];
            const end = positions[edge.destination];

            const line = document.createElementNS(svgNS, "line");

            line.setAttribute("x1", start.x);
            line.setAttribute("y1", start.y);
            line.setAttribute("x2", end.x);
            line.setAttribute("y2", end.y);
            line.setAttribute("class", "graph-edge");

            svg.appendChild(line);
        });

        // Draw cafeteria area circles and labels.
        Object.keys(positions).forEach(function (key) {

            const point = positions[key];

            const circle = document.createElementNS(svgNS, "circle");

            circle.setAttribute("cx", point.x);
            circle.setAttribute("cy", point.y);
            circle.setAttribute("r", radius);
            circle.setAttribute("class", "graph-node");

            svg.appendChild(circle);

            // Vertex number.
            const number = document.createElementNS(svgNS, "text");

            number.setAttribute("x", point.x);
            number.setAttribute("y", point.y - 15);
            number.setAttribute("class", "graph-node-number");
            number.textContent = key;

            svg.appendChild(number);

            // Area name.
            const label = document.createElementNS(svgNS, "text");

            label.setAttribute("x", point.x);
            label.setAttribute("y", point.y + 8);
            label.setAttribute("class", "graph-node-label");

            const words = cafeteriaAreas[key].split(" ");

            if (words.length <= 2) {
                label.textContent = cafeteriaAreas[key];
            } else {
                const firstLine = document.createElementNS(
                    svgNS,
                    "tspan"
                );

                firstLine.setAttribute("x", point.x);
                firstLine.setAttribute("dy", "0");
                firstLine.textContent = words.slice(0, 2).join(" ");

                label.appendChild(firstLine);

                const secondLine = document.createElementNS(
                    svgNS,
                    "tspan"
                );

                secondLine.setAttribute("x", point.x);
                secondLine.setAttribute("dy", "14");
                secondLine.textContent = words.slice(2).join(" ");

                label.appendChild(secondLine);
            }

            svg.appendChild(label);
        });

        // Show a message when there are no connections.
        if (edges.length === 0) {

            const message = document.createElementNS(svgNS, "text");

            message.setAttribute("x", width / 2);
            message.setAttribute("y", height / 2);
            message.setAttribute("text-anchor", "middle");
            message.setAttribute("class", "graph-empty-message");

            message.textContent = "No connections available";

            svg.appendChild(message);
        }

        graphVisual.replaceChildren(svg);
    }

    // Convert adjacency-list text into readable cafeteria names.
    function formatGraphText(graphText) {

        return graphText.split(/\r?\n/).map(function (line) {

            const match = line.match(/^\s*(\d+)\s*->\s*(.*)$/);

            if (!match) {
                return line;
            }

            const source = Number(match[1]);
            const neighbours = match[2].trim();

            if (!neighbours) {
                return getAreaName(source) + " -> No connections";
            }

            const neighbourNames = neighbours
                .split(/\s+/)
                .filter(Boolean)
                .map(getAreaName)
                .join(", ");

            return getAreaName(source) + " -> " + neighbourNames;

        }).join("\n");
    }

    // STEP 1: Add a connection.
    addEdgeButton.addEventListener("click", async function () {

        const source = graphSource.value;
        const destination = graphDestination.value;

        if (source === destination) {
            showConnectionMessage(
                "Please select two different cafeteria areas.",
                false
            );
            return;
        }

        addEdgeButton.disabled = true;

        showConnectionMessage("Adding connection...", true);

        try {
            const data = await sendGraphRequest({
                action: "addEdge",
                source: source,
                destination: destination
            });

            showConnectionMessage(
                data.message || "Connection added successfully!",
                true
            );

            graphOutput.textContent =
                "Connection added successfully.\n" +
                "Click Display Graph to view the updated connections.";

        } catch (error) {

            showConnectionMessage(
                "Unable to add connection: " + error.message,
                false
            );

            console.error("Add connection error:", error);

        } finally {
            addEdgeButton.disabled = false;
        }
    });

    // STEP 2: Display the graph.
    displayGraphButton.addEventListener("click", async function () {

        displayGraphButton.disabled = true;
        graphOutput.textContent = "Loading graph...";

        try {
            const data = await sendGraphRequest({
                action: "display"
            });

            if (typeof data.graph !== "string") {
                throw new Error(
                    "The server did not return graph information."
                );
            }

            drawVisualGraph(data.graph);

            graphOutput.textContent =
                "CAFETERIA GRAPH CONNECTIONS\n\n" +
                formatGraphText(data.graph);

        } catch (error) {

            graphOutput.textContent =
                "Unable to display graph.\n\n" + error.message;

            console.error("Display graph error:", error);

        } finally {
            displayGraphButton.disabled = false;
        }
    });

    // STEP 3: Run Breadth-First Search.
    runBfsButton.addEventListener("click", async function () {

        const startVertex = bfsStartVertex.value;

        runBfsButton.disabled = true;
        bfsOutput.textContent = "Running Breadth-First Search...";

        try {
            const data = await sendGraphRequest({
                action: "bfs",
                startVertex: startVertex
            });

            if (typeof data.traversal !== "string") {
                throw new Error(
                    "The server did not return the BFS traversal."
                );
            }

            bfsOutput.textContent =
                "BREADTH-FIRST SEARCH (BFS)\n\n" +
                "Starting Area: " + getAreaName(startVertex) + "\n\n" +
                "Traversal Order:\n" +
                convertVerticesToNames(data.traversal);

        } catch (error) {

            bfsOutput.textContent =
                "Unable to run BFS.\n\n" + error.message;

            console.error("BFS error:", error);

        } finally {
            runBfsButton.disabled = false;
        }
    });

    console.log("Graph module initialized successfully.");
});