const CUSTOMER_API =
    "http://localhost:8080/api/customers";


// ==================================================
// DISPLAY CUSTOMERS
// ==================================================

function displayCustomers(customers) {

    const tableBody =
        document.getElementById("customerTableBody");

    tableBody.innerHTML = "";


    if (!customers || customers.length === 0) {

        tableBody.innerHTML = `
            <tr>
                <td colspan="4">
                    No customers found.
                </td>
            </tr>
        `;

        return;
    }


    customers.forEach(function(customer) {

        const row =
            document.createElement("tr");


        row.innerHTML = `
            <td>
                ${customer.customerId}
            </td>

            <td>
                ${customer.customerName}
            </td>

            <td>
                ${customer.contact}
            </td>

            <td>

                <button
                    type="button"
                    class="edit-btn"
                    onclick="editCustomer(${customer.customerId})">
                    Edit
                </button>

                <button
                    type="button"
                    class="delete-btn"
                    onclick="deleteCustomer(${customer.customerId})">
                    Delete
                </button>

            </td>
        `;


        tableBody.appendChild(row);

    });
}


// ==================================================
// LOAD CUSTOMERS
// ==================================================

async function loadCustomers() {

    const tableBody =
        document.getElementById("customerTableBody");


    tableBody.innerHTML = `
        <tr>
            <td colspan="4">
                Loading customers...
            </td>
        </tr>
    `;


    try {

        const response =
            await fetch(CUSTOMER_API);


        const responseText =
            await response.text();


        if (!response.ok) {

            throw new Error(
                "Server returned status " +
                response.status +
                ": " +
                responseText
            );
        }


        const customers =
            JSON.parse(responseText);


        displayCustomers(customers);


    } catch (error) {

        console.error(
            "Error loading customers:",
            error
        );


        tableBody.innerHTML = `
            <tr>
                <td colspan="4">
                    Unable to load customers.
                    Make sure the Java server is running.
                </td>
            </tr>
        `;
    }
}


// ==================================================
// SEARCH CUSTOMERS
// ==================================================

document
    .getElementById("searchInput")
    .addEventListener(
        "input",
        async function() {

            const searchValue =
                this.value
                    .toLowerCase()
                    .trim();


            try {

                const response =
                    await fetch(CUSTOMER_API);


                const responseText =
                    await response.text();


                if (!response.ok) {

                    throw new Error(
                        "Server returned status " +
                        response.status
                    );
                }


                const customers =
                    JSON.parse(responseText);


                const filteredCustomers =
                    customers.filter(
                        function(customer) {

                            return (

                                String(
                                    customer.customerId
                                )
                                .includes(searchValue)


                                ||


                                customer.customerName
                                    .toLowerCase()
                                    .includes(searchValue)


                                ||


                                customer.contact
                                    .toLowerCase()
                                    .includes(searchValue)

                            );
                        }
                    );


                displayCustomers(
                    filteredCustomers
                );


            } catch (error) {

                console.error(
                    "Search error:",
                    error
                );
            }
        }
    );


// ==================================================
// CLEAR FORM
// ==================================================

document
    .getElementById("clearButton")
    .addEventListener(
        "click",
        function() {

            const form =
                document.getElementById(
                    "customerForm"
                );


            form.reset();


            form.dataset.editingId = "";


            document
                .getElementById("customerId")
                .disabled = false;


            const submitButton =
                document.querySelector(
                    "#customerForm button[type='submit']"
                );


            if (submitButton) {

                submitButton.textContent =
                    "Save Customer";
            }
        }
    );


// ==================================================
// FORM SUBMIT
// ADD OR UPDATE
// ==================================================

document
    .getElementById("customerForm")
    .addEventListener(
        "submit",
        async function(event) {

            event.preventDefault();


            const form = this;


            const editingId =
                form.dataset.editingId;


            const customerId =
                document
                    .getElementById("customerId")
                    .value
                    .trim();


            const customerName =
                document
                    .getElementById("customerName")
                    .value
                    .trim();


            // IMPORTANT:
            // HTML uses id="contactNumber"

            const contact =
                document
                    .getElementById("contactNumber")
                    .value
                    .trim();


            // ------------------------------------------
            // VALIDATION
            // ------------------------------------------

            if (
                customerId === "" ||
                customerName === "" ||
                contact === ""
            ) {

                alert(
                    "Please fill all customer fields."
                );

                return;
            }


            // ------------------------------------------
            // DECIDE ADD OR UPDATE
            // ------------------------------------------

            let action;


            if (editingId) {

                action = "update";

            } else {

                action = "add";
            }


            // ------------------------------------------
            // FORM DATA
            // ------------------------------------------

            const formData =
                new URLSearchParams();


            formData.append(
                "action",
                action
            );


            formData.append(
                "customerId",
                customerId
            );


            formData.append(
                "customerName",
                customerName
            );


            formData.append(
                "contact",
                contact
            );


            try {

                const response =
                    await fetch(
                        CUSTOMER_API,
                        {
                            method: "POST",

                            headers: {
                                "Content-Type":
                                    "application/x-www-form-urlencoded"
                            },

                            body:
                                formData.toString()
                        }
                    );


                const responseText =
                    await response.text();


                let result;


                try {

                    result =
                        JSON.parse(
                            responseText
                        );

                } catch (jsonError) {

                    result = {
                        error:
                            responseText ||
                            "Invalid response from server."
                    };
                }


                // --------------------------------------
                // SERVER ERROR
                // --------------------------------------

                if (!response.ok) {

                    alert(
                        result.error ||
                        "Operation failed."
                    );

                    console.error(
                        "Server error:",
                        result
                    );

                    return;
                }


                // --------------------------------------
                // SUCCESS MESSAGE
                // --------------------------------------

                if (action === "add") {

                    alert(
                        "Customer added successfully!"
                    );

                } else {

                    alert(
                        "Customer updated successfully!"
                    );
                }


                // --------------------------------------
                // RESET FORM
                // --------------------------------------

                form.reset();


                form.dataset.editingId = "";


                document
                    .getElementById("customerId")
                    .disabled = false;


                const submitButton =
                    document.querySelector(
                        "#customerForm button[type='submit']"
                    );


                if (submitButton) {

                    submitButton.textContent =
                        "Save Customer";
                }


                // --------------------------------------
                // RELOAD CUSTOMER LIST
                // --------------------------------------

                await loadCustomers();


            } catch (error) {

                console.error(
                    "Customer operation error:",
                    error
                );


                alert(
                    "Unable to connect to the Java server."
                );
            }
        }
    );


// ==================================================
// EDIT CUSTOMER
// ==================================================

async function editCustomer(customerId) {

    try {

        const response =
            await fetch(CUSTOMER_API);


        const responseText =
            await response.text();


        if (!response.ok) {

            throw new Error(
                "Server returned status " +
                response.status +
                ": " +
                responseText
            );
        }


        const customers =
            JSON.parse(responseText);


        const customer =
            customers.find(
                function(item) {

                    return (
                        Number(
                            item.customerId
                        )
                        ===
                        Number(customerId)
                    );
                }
            );


        if (!customer) {

            alert(
                "Customer not found."
            );

            return;
        }


        // ------------------------------------------
        // PUT DATA INTO FORM
        // ------------------------------------------

        document
            .getElementById("customerId")
            .value =
                customer.customerId;


        document
            .getElementById("customerName")
            .value =
                customer.customerName;


        document
            .getElementById("contactNumber")
            .value =
                customer.contact;


        // ------------------------------------------
        // DISABLE ID WHILE EDITING
        // ------------------------------------------

        document
            .getElementById("customerId")
            .disabled = true;


        // ------------------------------------------
        // STORE EDITING ID
        // ------------------------------------------

        document
            .getElementById("customerForm")
            .dataset.editingId =
                customer.customerId;


        // ------------------------------------------
        // CHANGE BUTTON TEXT
        // ------------------------------------------

        const submitButton =
            document.querySelector(
                "#customerForm button[type='submit']"
            );


        if (submitButton) {

            submitButton.textContent =
                "Update Customer";
        }


        // ------------------------------------------
        // SCROLL TO FORM
        // ------------------------------------------

        document
            .getElementById("customerForm")
            .scrollIntoView({
                behavior: "smooth"
            });


    } catch (error) {

        console.error(
            "Edit error:",
            error
        );


        alert(
            "Unable to load customer details."
        );
    }
}


// ==================================================
// DELETE CUSTOMER
// ==================================================

async function deleteCustomer(customerId) {

    const confirmDelete =
        confirm(
            "Are you sure you want to delete Customer ID "
            + customerId
            + "?"
        );


    if (!confirmDelete) {

        return;
    }


    const formData =
        new URLSearchParams();


    formData.append(
        "action",
        "delete"
    );


    formData.append(
        "customerId",
        customerId
    );


    try {

        const response =
            await fetch(
                CUSTOMER_API,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/x-www-form-urlencoded"
                    },

                    body:
                        formData.toString()
                }
            );


        const responseText =
            await response.text();


        let result;


        try {

            result =
                JSON.parse(
                    responseText
                );

        } catch (jsonError) {

            result = {
                error:
                    responseText ||
                    "Invalid response from server."
            };
        }


        if (!response.ok) {

            alert(
                result.error ||
                "Failed to delete customer."
            );

            return;
        }


        alert(
            "Customer deleted successfully!"
        );


        await loadCustomers();


    } catch (error) {

        console.error(
            "Delete error:",
            error
        );


        alert(
            "Unable to connect to the Java server."
        );
    }
}


// ==================================================
// LOAD CUSTOMERS WHEN PAGE OPENS
// ==================================================

window.addEventListener(
    "load",
    function() {

        loadCustomers();
    }
);