// ========================================
// CAFETERIA MANAGEMENT SYSTEM
// MODULE 3: BINARY TREE AND BINARY SEARCH TREE
// ========================================

const BINARY_TREE_API = "http://localhost:8080/api/binary-tree";
const BST_API = "http://localhost:8080/api/bst";

// Display messages in the Binary Tree section
function showTreeMessage(message, isError = false) {
    const result = document.getElementById("treeResult");

    if (result) {
        result.textContent = message;
        result.style.color = isError ? "red" : "green";
    } else {
        alert(message);
    }
}

// Display messages in the Binary Search Tree section
function showBSTMessage(message, isError = false) {
    const result = document.getElementById("bstResult");

    if (result) {
        result.textContent = message;
        result.style.color = isError ? "red" : "green";
    } else {
        alert(message);
    }
}

// Send requests to the Binary Tree API
async function sendTreeRequest(action, values = {}) {
    try {
        const formData = new URLSearchParams();

        formData.append("action", action);

        for (const key in values) {
            formData.append(key, values[key]);
        }

        const response = await fetch(BINARY_TREE_API, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: formData.toString()
        });

        const responseText = await response.text();

        let data;

        try {
            data = JSON.parse(responseText);
        } catch {
            throw new Error(
                "The server returned an invalid response: " +
                responseText
            );
        }

        if (!response.ok) {
            throw new Error(
                data.message || data.error || "Request failed."
            );
        }

        if (data.success === false) {
            throw new Error(
                data.message || data.error || "Operation failed."
            );
        }

        return data;

    } catch (error) {
        console.error("Binary Tree Error:", error);

        throw error;
    }
}

// Send requests to the Binary Search Tree API
async function sendBSTRequest(action, values = {}) {
    try {
        const formData = new URLSearchParams();

        formData.append("action", action);

        for (const key in values) {
            formData.append(key, values[key]);
        }

        const response = await fetch(BST_API, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: formData.toString()
        });

        const responseText = await response.text();

        let data;

        try {
            data = JSON.parse(responseText);
        } catch {
            throw new Error(
                "The server returned an invalid response: " +
                responseText
            );
        }

        if (!response.ok) {
            throw new Error(
                data.message || data.error || "Request failed."
            );
        }

        if (data.success === false) {
            throw new Error(
                data.message || data.error || "Operation failed."
            );
        }

        return data;

    } catch (error) {
        console.error("BST Error:", error);

        throw error;
    }
}

// ========================================
// BINARY TREE OPERATIONS
// ========================================

// Create Root
async function createRoot() {
    const rootInput = document.getElementById("rootData");

    if (!rootInput) {
        showTreeMessage("Root input field not found.", true);
        return;
    }

    const rootData = rootInput.value.trim();

    if (rootData === "") {
        showTreeMessage("Please enter the root value.", true);
        return;
    }

    try {
        const data = await sendTreeRequest("createRoot", {
            rootData: rootData
        });

        showTreeMessage(
            data.message || data.result || "Root created successfully."
        );

    } catch (error) {
        showTreeMessage(error.message, true);
    }
}

// Add Left Child
async function addLeftChild() {
    const parentInput = document.getElementById("parentData");
    const childInput = document.getElementById("childData");

    if (!parentInput || !childInput) {
        showTreeMessage("Parent or child input field not found.", true);
        return;
    }

    const parentData = parentInput.value.trim();
    const childData = childInput.value.trim();

    if (parentData === "" || childData === "") {
        showTreeMessage(
            "Please enter both parent and child values.",
            true
        );
        return;
    }

    try {
        const data = await sendTreeRequest("addLeft", {
            parentData: parentData,
            childData: childData
        });

        showTreeMessage(
            data.message || data.result || "Left child added successfully."
        );

    } catch (error) {
        showTreeMessage(error.message, true);
    }
}

// Add Right Child
async function addRightChild() {
    const parentInput = document.getElementById("parentData");
    const childInput = document.getElementById("childData");

    if (!parentInput || !childInput) {
        showTreeMessage("Parent or child input field not found.", true);
        return;
    }

    const parentData = parentInput.value.trim();
    const childData = childInput.value.trim();

    if (parentData === "" || childData === "") {
        showTreeMessage(
            "Please enter both parent and child values.",
            true
        );
        return;
    }

    try {
        const data = await sendTreeRequest("addRight", {
            parentData: parentData,
            childData: childData
        });

        showTreeMessage(
            data.message || data.result || "Right child added successfully."
        );

    } catch (error) {
        showTreeMessage(error.message, true);
    }
}

// Preorder Traversal
async function preorderTraversal() {
    try {
        const data = await sendTreeRequest("preorder");

        showTreeMessage(
            "Preorder Traversal: " +
            (data.result ?? data.traversal ?? data.message ?? "Completed")
        );

    } catch (error) {
        showTreeMessage(error.message, true);
    }
}

// Inorder Traversal
async function inorderTraversal() {
    try {
        const data = await sendTreeRequest("inorder");

        showTreeMessage(
            "Inorder Traversal: " +
            (data.result ?? data.traversal ?? data.message ?? "Completed")
        );

    } catch (error) {
        showTreeMessage(error.message, true);
    }
}

// Postorder Traversal
async function postorderTraversal() {
    try {
        const data = await sendTreeRequest("postorder");

        showTreeMessage(
            "Postorder Traversal: " +
            (data.result ?? data.traversal ?? data.message ?? "Completed")
        );

    } catch (error) {
        showTreeMessage(error.message, true);
    }
}

// ========================================
// BINARY SEARCH TREE OPERATIONS
// ========================================

// Insert Item into BST
async function insertBSTItem() {
    const idInput = document.getElementById("itemId");
    const nameInput = document.getElementById("itemName");

    if (!idInput || !nameInput) {
        showBSTMessage("Item ID or item name field not found.", true);
        return;
    }

    const itemId = idInput.value.trim();
    const itemName = nameInput.value.trim();

    if (itemId === "" || itemName === "") {
        showBSTMessage(
            "Please enter both item ID and item name.",
            true
        );
        return;
    }

    if (!Number.isInteger(Number(itemId))) {
        showBSTMessage("Item ID must be an integer.", true);
        return;
    }

    try {
        const data = await sendBSTRequest("insert", {
            itemId: itemId,
            itemName: itemName
        });

        showBSTMessage(
            data.message || data.result || "Item inserted successfully."
        );

        nameInput.value = "";
        idInput.value = "";

    } catch (error) {
        showBSTMessage(error.message, true);
    }
}

// Search Item in BST
async function searchBSTItem() {
    const idInput = document.getElementById("searchItemId");

    if (!idInput) {
        showBSTMessage("Search Item ID field not found.", true);
        return;
    }

    const itemId = idInput.value.trim();

    if (itemId === "") {
        showBSTMessage("Please enter an Item ID to search.", true);
        return;
    }

    try {
        const data = await sendBSTRequest("search", {
            itemId: itemId
        });

        showBSTMessage(
            data.message ||
            data.result ||
            data.itemName ||
            "Search completed."
        );

    } catch (error) {
        showBSTMessage(error.message, true);
    }
}

// Display BST in sorted order
async function displayBST() {
    try {
        const data = await sendBSTRequest("display");

        showBSTMessage(
            "BST Items (Inorder): " +
            (data.result ?? data.traversal ?? data.message ?? "Completed")
        );

    } catch (error) {
        showBSTMessage(error.message, true);
    }
}

// ========================================
// CONNECT BUTTONS TO FUNCTIONS
// ========================================

document.addEventListener("DOMContentLoaded", function () {

    // Binary Tree buttons
    const createRootButton =
        document.getElementById("createRootButton");

    const addLeftButton =
        document.getElementById("addLeftButton");

    const addRightButton =
        document.getElementById("addRightButton");

    const preorderButton =
        document.getElementById("preorderButton");

    const inorderButton =
        document.getElementById("inorderButton");

    const postorderButton =
        document.getElementById("postorderButton");

    if (createRootButton) {
        createRootButton.addEventListener("click", createRoot);
    }

    if (addLeftButton) {
        addLeftButton.addEventListener("click", addLeftChild);
    }

    if (addRightButton) {
        addRightButton.addEventListener("click", addRightChild);
    }

    if (preorderButton) {
        preorderButton.addEventListener("click", preorderTraversal);
    }

    if (inorderButton) {
        inorderButton.addEventListener("click", inorderTraversal);
    }

    if (postorderButton) {
        postorderButton.addEventListener("click", postorderTraversal);
    }

    // Binary Search Tree buttons
    const insertBstButton =
        document.getElementById("insertBstButton");

    const searchBstButton =
        document.getElementById("searchBstButton");

    const displayBstButton =
        document.getElementById("displayBstButton");

    if (insertBstButton) {
        insertBstButton.addEventListener("click", insertBSTItem);
    }

    if (searchBstButton) {
        searchBstButton.addEventListener("click", searchBSTItem);
    }

    if (displayBstButton) {
        displayBstButton.addEventListener("click", displayBST);
    }

    console.log("Trees.js loaded successfully.");
});