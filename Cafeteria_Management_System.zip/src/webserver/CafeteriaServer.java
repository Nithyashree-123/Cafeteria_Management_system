package webserver;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import algorithms.GreedySelection;

import database.MenuItemDAO;
import database.CustomerDAO;
import database.OrderDAO;
import database.CafeteriaSectionDAO;
import database.CategoryDAO;
import database.OrderItemDAO;

import datastructures.MenuLinkedList;
import datastructures.CustomerLinkedList;
import datastructures.OrderQueue;
import datastructures.ExpressionStack;
import datastructures.BinaryTree;
import datastructures.BinarySearchTree;
import datastructures.CafeteriaGraph;

import models.MenuItem;
import models.Customer;
import models.Order;
import models.CafeteriaSection;
import models.Category;
import models.OrderItem;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;

public class CafeteriaServer {

    private static final int PORT = 8080;


    // ==========================================================
    // MENU DATA STRUCTURE + DATABASE
    // ==========================================================

    private static final MenuLinkedList menuList =
            new MenuLinkedList();

    private static final MenuItemDAO menuItemDAO =
            new MenuItemDAO();


    // ==========================================================
    // CUSTOMER DATA STRUCTURE + DATABASE
    // ==========================================================

    private static final CustomerLinkedList customerList =
            new CustomerLinkedList();

    private static final CustomerDAO customerDAO =
            new CustomerDAO();


    // ==========================================================
    // ORDER DATABASE
    // ==========================================================

    private static final OrderDAO orderDAO =
            new OrderDAO();


    // ==========================================================
    // MODULE 2 - QUEUE
    // ==========================================================

    private static final OrderQueue orderQueue =
            new OrderQueue();


    // ==========================================================
    // MODULE 2 - STACK
    // ==========================================================

    private static final ExpressionStack expressionStack =
            new ExpressionStack();


    // ==========================================================
    // MODULE 3 - BINARY TREE AND BINARY SEARCH TREE
    // ==========================================================

    private static final BinaryTree binaryTree = new BinaryTree();
    private static final BinarySearchTree binarySearchTree =
            new BinarySearchTree();


    // ==========================================================
    // MODULE 4 - GRAPH AND BFS
    // ==========================================================

    // Six cafeteria section vertices, numbered 0 through 5.
    private static final CafeteriaGraph cafeteriaGraph =
            new CafeteriaGraph(6);


    // ==========================================================
    // SECTION DATABASE
    // ==========================================================

    private static final CafeteriaSectionDAO sectionDAO =
            new CafeteriaSectionDAO();


    // ==========================================================
    // CATEGORY DATABASE
    // ==========================================================

    private static final CategoryDAO categoryDAO =
            new CategoryDAO();


    // ==========================================================
    // ORDER ITEM DATABASE
    // ==========================================================

    private static final OrderItemDAO orderItemDAO =
            new OrderItemDAO();


    // ==========================================================
    // MAIN
    // ==========================================================

    public static void main(String[] args)
            throws Exception {


        // Load MySQL data into Linked Lists

        loadMenuListFromDatabase();

        loadCustomerListFromDatabase();


        // Create server

        HttpServer server =
                HttpServer.create(
                        new InetSocketAddress(PORT),
                        0
                );


        // ======================================================
        // MENU API
        // ======================================================

        server.createContext(
                "/api/menu-items",
                CafeteriaServer::handleMenuItems
        );


        // ======================================================
        // CUSTOMER API
        // ======================================================

        server.createContext(
                "/api/customers",
                CafeteriaServer::handleCustomers
        );


        // ======================================================
        // ORDER API
        // ======================================================

        server.createContext(
                "/api/orders",
                CafeteriaServer::handleOrders
        );


        // ======================================================
        // MODULE 2 - ORDER QUEUE API
        // ======================================================

        server.createContext(
                "/api/order-queue",
                CafeteriaServer::handleOrderQueue
        );


        // ======================================================
        // MODULE 2 - EXPRESSION STACK API
        // ======================================================

        server.createContext(
                "/api/expression-stack",
                CafeteriaServer::handleExpressionStack
        );


        // ======================================================
        // MODULE 3 - BINARY TREE API
        // ======================================================

        server.createContext(
                "/api/binary-tree",
                CafeteriaServer::handleBinaryTree
        );


        // ======================================================
        // MODULE 3 - BINARY SEARCH TREE API
        // ======================================================

        server.createContext(
                "/api/bst",
                CafeteriaServer::handleBinarySearchTree
        );


        // ======================================================
        // MODULE 4 - GRAPH AND BFS API
        // ======================================================

        server.createContext(
                "/api/graph",
                CafeteriaServer::handleGraph
        );


        // ======================================================
        // MODULE 6 - GREEDY BUDGET SELECTION API
        // ======================================================

        server.createContext(
                "/api/budget-selection",
                CafeteriaServer::handleBudgetSelection
        );


        // ======================================================
        // SECTION API
        // ======================================================

        server.createContext(
                "/api/sections",
                CafeteriaServer::handleSections
        );


        // ======================================================
        // CATEGORY API
        // ======================================================

        server.createContext(
                "/api/categories",
                CafeteriaServer::handleCategories
        );


        // ======================================================
        // ORDER ITEM API
        // ======================================================

        server.createContext(
                "/api/order-items",
                CafeteriaServer::handleOrderItems
        );


        // Start server

        server.start();


        System.out.println();
        System.out.println(
                "=========================================="
        );

        System.out.println(
                "Cafeteria Server started successfully!"
        );

        System.out.println(
                "=========================================="
        );

        System.out.println(
                "Menu API: http://localhost:"
                        + PORT
                        + "/api/menu-items"
        );

        System.out.println(
                "Customer API: http://localhost:"
                        + PORT
                        + "/api/customers"
        );

        System.out.println(
                "Order API: http://localhost:"
                        + PORT
                        + "/api/orders"
        );

        System.out.println(
                "=========================================="
        );
    }


    // ==========================================================
    // LOAD MENU DATA
    // ==========================================================

    private static void loadMenuListFromDatabase() {

        List<MenuItem> menuItems =
                menuItemDAO.getAllMenuItems();


        for (MenuItem item : menuItems) {

            menuList.add(item);
        }


        System.out.println(
                menuItems.size()
                        + " menu item(s) loaded into Linked List."
        );
    }


    // ==========================================================
    // LOAD CUSTOMER DATA
    // ==========================================================

    private static void loadCustomerListFromDatabase() {

        List<Customer> customers =
                customerDAO.getAllCustomers();


        for (Customer customer : customers) {

            customerList.add(customer);
        }


        System.out.println(
                customers.size()
                        + " customer(s) loaded into Linked List."
        );
    }


    // ==========================================================
    // MENU API
    // GET + POST
    // ==========================================================

    private static void handleMenuItems(
            HttpExchange exchange
    ) throws IOException {


        addCorsHeaders(exchange);


        String method =
                exchange.getRequestMethod();


        // ------------------------------------------------------
        // OPTIONS
        // ------------------------------------------------------

        if (method.equalsIgnoreCase("OPTIONS")) {

            sendResponse(
                    exchange,
                    204,
                    ""
            );

            return;
        }


        // ------------------------------------------------------
        // GET
        // ------------------------------------------------------

        if (method.equalsIgnoreCase("GET")) {

            List<MenuItem> menuItems =
                    menuList.getAll();


            sendResponse(
                    exchange,
                    200,
                    menuItemsToJson(menuItems)
            );

            return;
        }


        // ------------------------------------------------------
        // POST
        // ------------------------------------------------------

        if (method.equalsIgnoreCase("POST")) {

            String requestBody =
                    new String(
                            exchange
                                    .getRequestBody()
                                    .readAllBytes(),
                            StandardCharsets.UTF_8
                    );


            String action =
                    getParameter(
                            requestBody,
                            "action"
                    );


            if (action == null ||
                action.isBlank()) {

                sendResponse(
                        exchange,
                        400,
                        "{\"error\":\"Action is required.\"}"
                );

                return;
            }


            // ADD

            if (action.equalsIgnoreCase("add")) {

                handleMenuAdd(
                        requestBody,
                        exchange
                );

                return;
            }


            // UPDATE

            if (action.equalsIgnoreCase("update")) {

                handleMenuUpdate(
                        requestBody,
                        exchange
                );

                return;
            }


            // DELETE

            if (action.equalsIgnoreCase("delete")) {

                handleMenuDelete(
                        requestBody,
                        exchange
                );

                return;
            }


            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Invalid action.\"}"
            );

            return;
        }


        sendResponse(
                exchange,
                405,
                "{\"error\":\"Method not allowed.\"}"
        );
    }


    // ==========================================================
    // ADD MENU ITEM
    // ==========================================================

    private static void handleMenuAdd(
            String requestBody,
            HttpExchange exchange
    ) throws IOException {

        try {

            int itemId =
                    Integer.parseInt(
                            getParameter(
                                    requestBody,
                                    "itemId"
                            )
                    );


            String itemName =
                    getParameter(
                            requestBody,
                            "itemName"
                    );


            int categoryId =
                    Integer.parseInt(
                            getParameter(
                                    requestBody,
                                    "categoryId"
                            )
                    );


            double price =
                    Double.parseDouble(
                            getParameter(
                                    requestBody,
                                    "price"
                            )
                    );


            String availableText =
                    getParameter(
                            requestBody,
                            "available"
                    );


            boolean available =
                    Boolean.parseBoolean(
                            availableText
                    );


            if (menuList.search(itemId) != null) {

                sendResponse(
                        exchange,
                        409,
                        "{\"error\":\"Item ID already exists.\"}"
                );

                return;
            }


            MenuItem menuItem =
                    new MenuItem(
                            itemId,
                            itemName,
                            categoryId,
                            price,
                            available
                    );


            menuItemDAO.addMenuItem(menuItem);


            MenuItem savedItem =
                    menuItemDAO.getMenuItemById(
                            itemId
                    );


            if (savedItem == null) {

                sendResponse(
                        exchange,
                        500,
                        "{\"error\":\"Menu item could not be saved to MySQL.\"}"
                );

                return;
            }


            menuList.add(savedItem);


            sendResponse(
                    exchange,
                    200,
                    "{\"message\":\"Menu item added successfully.\"}"
            );


        } catch (Exception e) {

            e.printStackTrace();

            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Invalid menu item data.\"}"
            );
        }
    }


    // ==========================================================
    // UPDATE MENU ITEM
    // ==========================================================

    private static void handleMenuUpdate(
            String requestBody,
            HttpExchange exchange
    ) throws IOException {

        try {

            int itemId =
                    Integer.parseInt(
                            getParameter(
                                    requestBody,
                                    "itemId"
                            )
                    );


            String itemName =
                    getParameter(
                            requestBody,
                            "itemName"
                    );


            int categoryId =
                    Integer.parseInt(
                            getParameter(
                                    requestBody,
                                    "categoryId"
                            )
                    );


            double price =
                    Double.parseDouble(
                            getParameter(
                                    requestBody,
                                    "price"
                            )
                    );


            boolean available =
                    Boolean.parseBoolean(
                            getParameter(
                                    requestBody,
                                    "available"
                            )
                    );


            if (menuList.search(itemId) == null) {

                sendResponse(
                        exchange,
                        404,
                        "{\"error\":\"Menu item not found.\"}"
                );

                return;
            }


            MenuItem updatedItem =
                    new MenuItem(
                            itemId,
                            itemName,
                            categoryId,
                            price,
                            available
                    );


            menuItemDAO.updateMenuItem(
                    updatedItem
            );


            MenuItem savedItem =
                    menuItemDAO.getMenuItemById(
                            itemId
                    );


            if (savedItem == null) {

                sendResponse(
                        exchange,
                        500,
                        "{\"error\":\"Updated menu item could not be verified.\"}"
                );

                return;
            }


            menuList.update(
                    itemId,
                    savedItem
            );


            sendResponse(
                    exchange,
                    200,
                    "{\"message\":\"Menu item updated successfully.\"}"
            );


        } catch (Exception e) {

            e.printStackTrace();

            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Invalid menu item data.\"}"
            );
        }
    }


    // ==========================================================
    // DELETE MENU ITEM
    // ==========================================================

    private static void handleMenuDelete(
            String requestBody,
            HttpExchange exchange
    ) throws IOException {

        try {

            int itemId =
                    Integer.parseInt(
                            getParameter(
                                    requestBody,
                                    "itemId"
                            )
                    );


            if (menuList.search(itemId) == null) {

                sendResponse(
                        exchange,
                        404,
                        "{\"error\":\"Menu item not found.\"}"
                );

                return;
            }


            menuItemDAO.deleteMenuItem(
                    itemId
            );


            MenuItem deletedCheck =
                    menuItemDAO.getMenuItemById(
                            itemId
                    );


            if (deletedCheck != null) {

                sendResponse(
                        exchange,
                        500,
                        "{\"error\":\"Menu item could not be deleted from MySQL.\"}"
                );

                return;
            }


            menuList.delete(itemId);


            sendResponse(
                    exchange,
                    200,
                    "{\"message\":\"Menu item deleted successfully.\"}"
            );


        } catch (Exception e) {

            e.printStackTrace();

            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Invalid item ID.\"}"
            );
        }
    }


    // ==========================================================
    // CUSTOMER API
    // GET + POST
    // ==========================================================

    private static void handleCustomers(
            HttpExchange exchange
    ) throws IOException {


        addCorsHeaders(exchange);


        String method =
                exchange.getRequestMethod();


        // ------------------------------------------------------
        // OPTIONS
        // ------------------------------------------------------

        if (method.equalsIgnoreCase("OPTIONS")) {

            sendResponse(
                    exchange,
                    204,
                    ""
            );

            return;
        }


        // ------------------------------------------------------
        // GET
        // ------------------------------------------------------

        if (method.equalsIgnoreCase("GET")) {

            List<Customer> customers =
                    customerList.getAll();


            sendResponse(
                    exchange,
                    200,
                    customersToJson(customers)
            );

            return;
        }


        // ------------------------------------------------------
        // POST
        // ------------------------------------------------------

        if (method.equalsIgnoreCase("POST")) {

            String requestBody =
                    new String(
                            exchange
                                    .getRequestBody()
                                    .readAllBytes(),
                            StandardCharsets.UTF_8
                    );


            String action =
                    getParameter(
                            requestBody,
                            "action"
                    );


            if (action == null ||
                action.isBlank()) {

                sendResponse(
                        exchange,
                        400,
                        "{\"error\":\"Action is required.\"}"
                );

                return;
            }


            // ADD

            if (action.equalsIgnoreCase("add")) {

                handleCustomerAdd(
                        requestBody,
                        exchange
                );

                return;
            }


            // UPDATE

            if (action.equalsIgnoreCase("update")) {

                handleCustomerUpdate(
                        requestBody,
                        exchange
                );

                return;
            }


            // DELETE

            if (action.equalsIgnoreCase("delete")) {

                handleCustomerDelete(
                        requestBody,
                        exchange
                );

                return;
            }


            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Invalid action.\"}"
            );

            return;
        }


        sendResponse(
                exchange,
                405,
                "{\"error\":\"Method not allowed.\"}"
        );
    }


    // ==========================================================
    // ADD CUSTOMER
    // ==========================================================

    private static void handleCustomerAdd(
            String requestBody,
            HttpExchange exchange
    ) throws IOException {

        try {

            String customerIdText =
                    getParameter(
                            requestBody,
                            "customerId"
                    );


            String customerName =
                    getParameter(
                            requestBody,
                            "customerName"
                    );


            String contact =
                    getParameter(
                            requestBody,
                            "contact"
                    );


            if (customerIdText == null ||
                customerName == null ||
                contact == null ||
                customerName.trim().isEmpty() ||
                contact.trim().isEmpty()) {

                sendResponse(
                        exchange,
                        400,
                        "{\"error\":\"Customer ID, Customer Name and Contact Number are required.\"}"
                );

                return;
            }


            int customerId =
                    Integer.parseInt(
                            customerIdText
                    );


            if (customerList.search(customerId)
                    != null) {

                sendResponse(
                        exchange,
                        409,
                        "{\"error\":\"Customer ID already exists.\"}"
                );

                return;
            }


            Customer customer =
                    new Customer(
                            customerId,
                            customerName.trim(),
                            contact.trim()
                    );


            customerDAO.addCustomer(
                    customer
            );


            Customer savedCustomer =
                    customerDAO.getCustomerById(
                            customerId
                    );


            if (savedCustomer == null) {

                sendResponse(
                        exchange,
                        500,
                        "{\"error\":\"Customer could not be saved to MySQL.\"}"
                );

                return;
            }


            customerList.add(
                    savedCustomer
            );


            sendResponse(
                    exchange,
                    200,
                    "{\"message\":\"Customer added successfully.\"}"
            );


        } catch (NumberFormatException e) {

            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Invalid Customer ID.\"}"
            );


        } catch (Exception e) {

            e.printStackTrace();

            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Invalid customer data.\"}"
            );
        }
    }


    // ==========================================================
    // UPDATE CUSTOMER
    // ==========================================================

    private static void handleCustomerUpdate(
            String requestBody,
            HttpExchange exchange
    ) throws IOException {

        try {

            String customerIdText =
                    getParameter(
                            requestBody,
                            "customerId"
                    );


            String customerName =
                    getParameter(
                            requestBody,
                            "customerName"
                    );


            String contact =
                    getParameter(
                            requestBody,
                            "contact"
                    );


            if (customerIdText == null ||
                customerName == null ||
                contact == null ||
                customerName.trim().isEmpty() ||
                contact.trim().isEmpty()) {

                sendResponse(
                        exchange,
                        400,
                        "{\"error\":\"Customer ID, Customer Name and Contact Number are required.\"}"
                );

                return;
            }


            int customerId =
                    Integer.parseInt(
                            customerIdText
                    );


            if (customerList.search(customerId)
                    == null) {

                sendResponse(
                        exchange,
                        404,
                        "{\"error\":\"Customer not found.\"}"
                );

                return;
            }


            Customer updatedCustomer =
                    new Customer(
                            customerId,
                            customerName.trim(),
                            contact.trim()
                    );


            customerDAO.updateCustomer(
                    updatedCustomer
            );


            Customer savedCustomer =
                    customerDAO.getCustomerById(
                            customerId
                    );


            if (savedCustomer == null) {

                sendResponse(
                        exchange,
                        500,
                        "{\"error\":\"Updated customer could not be verified.\"}"
                );

                return;
            }


            customerList.update(
                    customerId,
                    savedCustomer
            );


            sendResponse(
                    exchange,
                    200,
                    "{\"message\":\"Customer updated successfully.\"}"
            );


        } catch (NumberFormatException e) {

            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Invalid Customer ID.\"}"
            );


        } catch (Exception e) {

            e.printStackTrace();

            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Invalid customer data.\"}"
            );
        }
    }


    // ==========================================================
    // DELETE CUSTOMER
    // ==========================================================

    private static void handleCustomerDelete(
            String requestBody,
            HttpExchange exchange
    ) throws IOException {

        try {

            String customerIdText =
                    getParameter(
                            requestBody,
                            "customerId"
                    );


            if (customerIdText == null ||
                customerIdText.trim().isEmpty()) {

                sendResponse(
                        exchange,
                        400,
                        "{\"error\":\"Customer ID is required.\"}"
                );

                return;
            }


            int customerId =
                    Integer.parseInt(
                            customerIdText
                    );


            if (customerList.search(customerId)
                    == null) {

                sendResponse(
                        exchange,
                        404,
                        "{\"error\":\"Customer not found.\"}"
                );

                return;
            }


            customerDAO.deleteCustomer(
                    customerId
            );


            Customer deletedCheck =
                    customerDAO.getCustomerById(
                            customerId
                    );


            if (deletedCheck != null) {

                sendResponse(
                        exchange,
                        500,
                        "{\"error\":\"Customer could not be deleted. The customer may have related orders.\"}"
                );

                return;
            }


            customerList.delete(
                    customerId
            );


            sendResponse(
                    exchange,
                    200,
                    "{\"message\":\"Customer deleted successfully.\"}"
            );


        } catch (NumberFormatException e) {

            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Invalid Customer ID.\"}"
            );


        } catch (Exception e) {

            e.printStackTrace();

            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Invalid customer ID.\"}"
            );
        }
    }


    // ==========================================================
    // ORDERS API
    // GET + POST
    // ==========================================================

    private static void handleOrders(
            HttpExchange exchange
    ) throws IOException {


        addCorsHeaders(exchange);


        String method =
                exchange.getRequestMethod();


        // ------------------------------------------------------
        // OPTIONS
        // ------------------------------------------------------

        if (method.equalsIgnoreCase("OPTIONS")) {

            sendResponse(
                    exchange,
                    204,
                    ""
            );

            return;
        }


        // ------------------------------------------------------
        // GET ORDERS
        // ------------------------------------------------------

        if (method.equalsIgnoreCase("GET")) {

            handleOrderGet(
                    exchange
            );

            return;
        }


        // ------------------------------------------------------
        // POST ORDERS
        // ------------------------------------------------------

        if (method.equalsIgnoreCase("POST")) {

            String requestBody =
                    new String(
                            exchange
                                    .getRequestBody()
                                    .readAllBytes(),
                            StandardCharsets.UTF_8
                    );


            String action =
                    getParameter(
                            requestBody,
                            "action"
                    );


            if (action == null ||
                action.isBlank()) {

                sendResponse(
                        exchange,
                        400,
                        "{\"error\":\"Action is required.\"}"
                );

                return;
            }


            if (action.equalsIgnoreCase("add")) {

                handleOrderAdd(
                        requestBody,
                        exchange
                );

                return;
            }


            if (action.equalsIgnoreCase("update")) {

                handleOrderUpdate(
                        requestBody,
                        exchange
                );

                return;
            }


            if (action.equalsIgnoreCase("delete")) {

                handleOrderDelete(
                        requestBody,
                        exchange
                );

                return;
            }


            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Invalid order action.\"}"
            );

            return;
        }


        sendResponse(
                exchange,
                405,
                "{\"error\":\"Method not allowed.\"}"
        );
    }


    // ==========================================================
    // GET ORDERS
    // ==========================================================

    private static void handleOrderGet(
            HttpExchange exchange
    ) throws IOException {


        String query =
                exchange.getRequestURI()
                        .getQuery();


        String orderIdText =
                getQueryParameter(
                        query,
                        "id"
                );


        // ------------------------------------------------------
        // GET ONE ORDER
        // ------------------------------------------------------

        if (orderIdText != null &&
            !orderIdText.isBlank()) {

            try {

                int orderId =
                        Integer.parseInt(
                                orderIdText
                        );


                Order order =
                        orderDAO.getOrderById(
                                orderId
                        );


                if (order == null) {

                    sendResponse(
                            exchange,
                            404,
                            "{\"error\":\"Order not found.\"}"
                    );

                    return;
                }


                sendResponse(
                        exchange,
                        200,
                        orderToJson(order)
                );

                return;


            } catch (NumberFormatException e) {

                sendResponse(
                        exchange,
                        400,
                        "{\"error\":\"Invalid Order ID.\"}"
                );

                return;
            }
        }


        // ------------------------------------------------------
        // GET ALL ORDERS
        // ------------------------------------------------------

        String sql =
                "SELECT order_id, customer_id, " +
                "order_date, total_amount, status " +
                "FROM orders";


        try (
                Connection connection =
                        database.DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet resultSet =
                        statement.executeQuery()
        ) {


            StringBuilder json =
                    new StringBuilder();


            json.append("[");


            boolean first =
                    true;


            while (resultSet.next()) {


                if (!first) {

                    json.append(",");
                }


                first = false;


                json.append("{");


                json.append("\"order_id\":")
                        .append(
                                resultSet.getInt(
                                        "order_id"
                                )
                        )
                        .append(",");


                json.append("\"customer_id\":")
                        .append(
                                resultSet.getInt(
                                        "customer_id"
                                )
                        )
                        .append(",");


                json.append("\"order_date\":\"")
                        .append(
                                resultSet.getDate(
                                        "order_date"
                                )
                        )
                        .append("\",");


                json.append("\"total_amount\":")
                        .append(
                                resultSet.getDouble(
                                        "total_amount"
                                )
                        )
                        .append(",");


                json.append("\"status\":\"")
                        .append(
                                escapeJson(
                                        resultSet.getString(
                                                "status"
                                        )
                                )
                        )
                        .append("\"");


                json.append("}");
            }


            json.append("]");


            sendResponse(
                    exchange,
                    200,
                    json.toString()
            );


        } catch (Exception e) {

            e.printStackTrace();


            sendResponse(
                    exchange,
                    500,
                    "{\"error\":\"Unable to load orders from MySQL.\"}"
            );
        }
    }


    // ==========================================================
    // ADD ORDER
    // ==========================================================

    private static void handleOrderAdd(
            String requestBody,
            HttpExchange exchange
    ) throws IOException {

        try {

            int orderId =
                    Integer.parseInt(
                            getParameter(
                                    requestBody,
                                    "order_id"
                            )
                    );


            int customerId =
                    Integer.parseInt(
                            getParameter(
                                    requestBody,
                                    "customer_id"
                            )
                    );


            String orderDate =
                    getParameter(
                            requestBody,
                            "order_date"
                    );


            double totalAmount =
                    Double.parseDouble(
                            getParameter(
                                    requestBody,
                                    "total_amount"
                            )
                    );


            String status =
                    getParameter(
                            requestBody,
                            "status"
                    );


            if (orderDate == null ||
                orderDate.trim().isEmpty() ||
                status == null ||
                status.trim().isEmpty()) {

                sendResponse(
                        exchange,
                        400,
                        "{\"error\":\"All order fields are required.\"}"
                );

                return;
            }


            // Check customer

            if (customerList.search(customerId)
                    == null) {

                sendResponse(
                        exchange,
                        400,
                        "{\"error\":\"Customer ID does not exist.\"}"
                );

                return;
            }


            // Check duplicate order ID

            if (orderDAO.getOrderById(orderId)
                    != null) {

                sendResponse(
                        exchange,
                        409,
                        "{\"error\":\"Order ID already exists.\"}"
                );

                return;
            }


            Order order =
                    new Order(
                            orderId,
                            customerId,
                            orderDate,
                            totalAmount,
                            status.trim()
                    );


            orderDAO.addOrder(
                    order
            );


            // Verify insertion

            Order savedOrder =
                    orderDAO.getOrderById(
                            orderId
                    );


            if (savedOrder == null) {

                sendResponse(
                        exchange,
                        500,
                        "{\"error\":\"Order could not be saved to MySQL.\"}"
                );

                return;
            }


            // Add the successfully saved order to the linked-list queue.
            // This demonstrates FIFO order processing in Module 2.
            orderQueue.enqueue(savedOrder);


            sendResponse(
                    exchange,
                    201,
                    "{\"message\":\"Order added successfully and added to queue.\"}"
            );


        } catch (NumberFormatException e) {

            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Invalid order ID, customer ID or total amount.\"}"
            );


        } catch (Exception e) {

            e.printStackTrace();

            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Invalid order data.\"}"
            );
        }
    }


    // ==========================================================
    // UPDATE ORDER
    // ==========================================================

    private static void handleOrderUpdate(
            String requestBody,
            HttpExchange exchange
    ) throws IOException {

        try {

            int orderId =
                    Integer.parseInt(
                            getParameter(
                                    requestBody,
                                    "order_id"
                            )
                    );


            int customerId =
                    Integer.parseInt(
                            getParameter(
                                    requestBody,
                                    "customer_id"
                            )
                    );


            String orderDate =
                    getParameter(
                            requestBody,
                            "order_date"
                    );


            double totalAmount =
                    Double.parseDouble(
                            getParameter(
                                    requestBody,
                                    "total_amount"
                            )
                    );


            String status =
                    getParameter(
                            requestBody,
                            "status"
                    );


            if (orderDate == null ||
                orderDate.trim().isEmpty() ||
                status == null ||
                status.trim().isEmpty()) {

                sendResponse(
                        exchange,
                        400,
                        "{\"error\":\"All order fields are required.\"}"
                );

                return;
            }


            // Check order

            Order existingOrder =
                    orderDAO.getOrderById(
                            orderId
                    );


            if (existingOrder == null) {

                sendResponse(
                        exchange,
                        404,
                        "{\"error\":\"Order not found.\"}"
                );

                return;
            }


            // Check customer

            if (customerList.search(customerId)
                    == null) {

                sendResponse(
                        exchange,
                        400,
                        "{\"error\":\"Customer ID does not exist.\"}"
                );

                return;
            }


            Order updatedOrder =
                    new Order(
                            orderId,
                            customerId,
                            orderDate,
                            totalAmount,
                            status.trim()
                    );


            orderDAO.updateOrder(
                    updatedOrder
            );


            Order savedOrder =
                    orderDAO.getOrderById(
                            orderId
                    );


            if (savedOrder == null) {

                sendResponse(
                        exchange,
                        500,
                        "{\"error\":\"Order update could not be verified.\"}"
                );

                return;
            }


            sendResponse(
                    exchange,
                    200,
                    "{\"message\":\"Order updated successfully.\"}"
            );


        } catch (NumberFormatException e) {

            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Invalid order ID, customer ID or total amount.\"}"
            );


        } catch (Exception e) {

            e.printStackTrace();

            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Invalid order data.\"}"
            );
        }
    }


    // ==========================================================
    // DELETE ORDER
    // ==========================================================

    private static void handleOrderDelete(
            String requestBody,
            HttpExchange exchange
    ) throws IOException {

        try {

            int orderId =
                    Integer.parseInt(
                            getParameter(
                                    requestBody,
                                    "order_id"
                            )
                    );


            Order existingOrder =
                    orderDAO.getOrderById(
                            orderId
                    );


            if (existingOrder == null) {

                sendResponse(
                        exchange,
                        404,
                        "{\"error\":\"Order not found.\"}"
                );

                return;
            }


            orderDAO.deleteOrder(
                    orderId
            );


            // Verify deletion

            Order deletedCheck =
                    orderDAO.getOrderById(
                            orderId
                    );


            if (deletedCheck != null) {

                sendResponse(
                        exchange,
                        500,
                        "{\"error\":\"Order could not be deleted. It may have related order items.\"}"
                );

                return;
            }


            sendResponse(
                    exchange,
                    200,
                    "{\"message\":\"Order deleted successfully.\"}"
            );


        } catch (NumberFormatException e) {

            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Invalid Order ID.\"}"
            );


        } catch (Exception e) {

            e.printStackTrace();

            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Unable to delete order.\"}"
            );
        }
    }


    // ==========================================================
    // MODULE 6 - GREEDY BUDGET SELECTION
    // ==========================================================

    private static void handleBudgetSelection(HttpExchange exchange)
            throws IOException {

        addCorsHeaders(exchange);
        String method = exchange.getRequestMethod();

        if (method.equalsIgnoreCase("OPTIONS")) {
            sendResponse(exchange, 204, "");
            return;
        }

        if (!method.equalsIgnoreCase("POST")) {
            sendResponse(exchange, 405,
                    "{\"error\":\"Method not allowed. Use POST.\"}");
            return;
        }

        try {
            String requestBody = new String(
                    exchange.getRequestBody().readAllBytes(),
                    StandardCharsets.UTF_8
            );

            String budgetText = getParameter(requestBody, "budget");
            if (budgetText == null || budgetText.isBlank()) {
                sendResponse(exchange, 400,
                        "{\"error\":\"Please enter your budget.\"}");
                return;
            }

            double budget = Double.parseDouble(budgetText);
            if (!Double.isFinite(budget) || budget < 0) {
                sendResponse(exchange, 400,
                        "{\"error\":\"Budget must be a valid non-negative number.\"}");
                return;
            }

            List<MenuItem> allItems = menuItemDAO.getAllMenuItems();
            List<MenuItem> availableItems = new ArrayList<>();

            if (allItems != null) {
                for (MenuItem item : allItems) {
                    if (item != null && item.isAvailability()) {
                        availableItems.add(item);
                    }
                }
            }

            List<MenuItem> selectedItems =
                    GreedySelection.selectAffordableItems(availableItems, budget);
            double total = GreedySelection.calculateTotal(selectedItems);
            double remainingBudget = budget - total;

            StringBuilder json = new StringBuilder();
            json.append("{");
            json.append("\"budget\":").append(budget).append(",");
            json.append("\"total\":").append(total).append(",");
            json.append("\"remainingBudget\":").append(remainingBudget).append(",");
            json.append("\"selectedItems\":[");

            for (int i = 0; i < selectedItems.size(); i++) {
                MenuItem item = selectedItems.get(i);
                if (i > 0) json.append(",");
                json.append("{");
                json.append("\"itemId\":").append(item.getItemId()).append(",");
                json.append("\"itemName\":\"")
                        .append(escapeJson(item.getItemName())).append("\",");
                json.append("\"price\":").append(item.getPrice());
                json.append("}");
            }

            json.append("]}");
            sendResponse(exchange, 200, json.toString());

        } catch (NumberFormatException e) {
            sendResponse(exchange, 400,
                    "{\"error\":\"Please enter a valid budget.\"}");
        } catch (Exception e) {
            e.printStackTrace();
            sendResponse(exchange, 500,
                    "{\"error\":\"Unable to calculate budget selection.\"}");
        }
    }


    // ==========================================================
    // MENU JSON
    // ==========================================================

    private static String menuItemsToJson(
            List<MenuItem> menuItems
    ) {

        StringBuilder json =
                new StringBuilder();


        json.append("[");


        for (int i = 0;
             i < menuItems.size();
             i++) {

            MenuItem item =
                    menuItems.get(i);


            json.append("{");


            json.append("\"itemId\":")
                    .append(
                            item.getItemId()
                    )
                    .append(",");


            json.append("\"itemName\":\"")
                    .append(
                            escapeJson(
                                    item.getItemName()
                            )
                    )
                    .append("\",");


            json.append("\"categoryId\":")
                    .append(
                            item.getCategoryId()
                    )
                    .append(",");


            json.append("\"price\":")
                    .append(
                            item.getPrice()
                    )
                    .append(",");


            json.append("\"available\":")
                    .append(
                            item.isAvailability()
                    );


            json.append("}");


            if (i < menuItems.size() - 1) {

                json.append(",");
            }
        }


        json.append("]");


        return json.toString();
    }


    // ==========================================================
    // CUSTOMER JSON
    // ==========================================================

    private static String customersToJson(
            List<Customer> customers
    ) {

        StringBuilder json =
                new StringBuilder();


        json.append("[");


        for (int i = 0;
             i < customers.size();
             i++) {

            Customer customer =
                    customers.get(i);


            json.append("{");


            json.append("\"customerId\":")
                    .append(
                            customer.getCustomerId()
                    )
                    .append(",");


            json.append("\"customerName\":\"")
                    .append(
                            escapeJson(
                                    customer.getCustomerName()
                            )
                    )
                    .append("\",");


            json.append("\"contact\":\"")
                    .append(
                            escapeJson(
                                    customer.getContact()
                            )
                    )
                    .append("\"");


            json.append("}");


            if (i < customers.size() - 1) {

                json.append(",");
            }
        }


        json.append("]");


        return json.toString();
    }


    // ==========================================================
    // MODULE 2 - ORDER QUEUE API
    // ==========================================================

    private static void handleOrderQueue(
            HttpExchange exchange
    ) throws IOException {

        addCorsHeaders(exchange);

        String method =
                exchange.getRequestMethod();


        // ------------------------------------------------------
        // OPTIONS
        // ------------------------------------------------------

        if (method.equalsIgnoreCase("OPTIONS")) {

            sendResponse(
                    exchange,
                    204,
                    ""
            );

            return;
        }


        // ------------------------------------------------------
        // GET - VIEW CURRENT QUEUE
        // ------------------------------------------------------

        if (method.equalsIgnoreCase("GET")) {

            StringBuilder json =
                    new StringBuilder("[");

            boolean first = true;

            /*
             * OrderQueue intentionally exposes only enqueue/dequeue.
             * We temporarily remove the items so that they can be
             * converted to JSON, then immediately restore them in
             * the same FIFO order.
             */
            java.util.List<Order> currentOrders =
                    new java.util.ArrayList<>();

            while (!orderQueue.isEmpty()) {

                Order order =
                        orderQueue.dequeue();

                if (order != null) {
                    currentOrders.add(order);
                }
            }

            for (Order order : currentOrders) {

                if (!first) {
                    json.append(",");
                }

                json.append(orderToJson(order));
                first = false;
            }

            // Restore the queue without changing FIFO order.
            for (Order order : currentOrders) {
                orderQueue.enqueue(order);
            }

            json.append("]");

            sendResponse(
                    exchange,
                    200,
                    json.toString()
            );

            return;
        }


        // ------------------------------------------------------
        // POST - PEEK / PROCESS NEXT ORDER
        // ------------------------------------------------------

        if (method.equalsIgnoreCase("POST")) {

            String requestBody =
                    new String(
                            exchange.getRequestBody().readAllBytes(),
                            StandardCharsets.UTF_8
                    );

            String action =
                    getParameter(
                            requestBody,
                            "action"
                    );

            if (action == null || action.isBlank()) {

                sendResponse(
                        exchange,
                        400,
                        "{\"error\":\"Queue action is required.\"}"
                );

                return;
            }


            // --------------------------------------------------
            // PEEK - VIEW FIRST ORDER WITHOUT REMOVING IT
            // --------------------------------------------------

            if (action.equalsIgnoreCase("peek")) {

                java.util.List<Order> currentOrders =
                        new java.util.ArrayList<>();

                while (!orderQueue.isEmpty()) {

                    Order order =
                            orderQueue.dequeue();

                    if (order != null) {
                        currentOrders.add(order);
                    }
                }

                for (Order order : currentOrders) {
                    orderQueue.enqueue(order);
                }

                if (currentOrders.isEmpty()) {

                    sendResponse(
                            exchange,
                            404,
                            "{\"error\":\"Order queue is empty.\"}"
                    );

                    return;
                }

                sendResponse(
                        exchange,
                        200,
                        orderToJson(currentOrders.get(0))
                );

                return;
            }


            // --------------------------------------------------
            // PROCESS - REMOVE FIRST ORDER FROM FIFO QUEUE
            // --------------------------------------------------

            if (action.equalsIgnoreCase("process")) {

                Order nextOrder =
                        orderQueue.dequeue();

                if (nextOrder == null) {

                    sendResponse(
                            exchange,
                            404,
                            "{\"error\":\"Order queue is empty.\"}"
                    );

                    return;
                }

                sendResponse(
                        exchange,
                        200,
                        orderToJson(nextOrder)
                );

                return;
            }


            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Invalid queue action. Use peek or process.\"}"
            );

            return;
        }


        sendResponse(
                exchange,
                405,
                "{\"error\":\"Method not allowed.\"}"
        );
    }


    // ==========================================================
    // MODULE 2 - EXPRESSION STACK API
    // ==========================================================

    private static void handleExpressionStack(
            HttpExchange exchange
    ) throws IOException {

        addCorsHeaders(exchange);

        String method =
                exchange.getRequestMethod();


        // ------------------------------------------------------
        // OPTIONS
        // ------------------------------------------------------

        if (method.equalsIgnoreCase("OPTIONS")) {

            sendResponse(
                    exchange,
                    204,
                    ""
            );

            return;
        }


        // ------------------------------------------------------
        // POST
        // ------------------------------------------------------

        if (!method.equalsIgnoreCase("POST")) {

            sendResponse(
                    exchange,
                    405,
                    "{\"error\":\"Method not allowed.\"}"
            );

            return;
        }


        String requestBody =
                new String(
                        exchange.getRequestBody().readAllBytes(),
                        StandardCharsets.UTF_8
                );

        String expression =
                getParameter(
                        requestBody,
                        "expression"
                );


        if (expression == null || expression.trim().isEmpty()) {

            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"Expression is required.\"}"
            );

            return;
        }


        try {

            int result =
                    expressionStack.evaluatePostfix(
                            expression.trim()
                    );

            String response =
                    "{" +
                    "\"expression\":\"" +
                    escapeJson(expression) +
                    "\"," +
                    "\"result\":" +
                    result +
                    "}";

            sendResponse(
                    exchange,
                    200,
                    response
            );

        } catch (ArithmeticException e) {

            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"" +
                    escapeJson(e.getMessage()) +
                    "\"}"
            );

        } catch (IllegalArgumentException e) {

            sendResponse(
                    exchange,
                    400,
                    "{\"error\":\"" +
                    escapeJson(e.getMessage()) +
                    "\"}"
            );
        }
    }


    // ==========================================================
    // MODULE 3 - BINARY TREE API
    // ==========================================================

    private static void handleBinaryTree(HttpExchange exchange)
            throws IOException {

        addCorsHeaders(exchange);
        String method = exchange.getRequestMethod();

        if (method.equalsIgnoreCase("OPTIONS")) {
            sendResponse(exchange, 204, "");
            return;
        }

        if (!method.equalsIgnoreCase("POST")) {
            sendResponse(exchange, 405,
                    "{\"error\":\"Method not allowed. Use POST.\"}");
            return;
        }

        String body = new String(
                exchange.getRequestBody().readAllBytes(),
                StandardCharsets.UTF_8
        );
        String action = getParameter(body, "action");

        try {
            if (action == null || action.isBlank()) {
                sendResponse(exchange, 400,
                        "{\"error\":\"Tree action is required.\"}");
                return;
            }

            switch (action.toLowerCase()) {
                case "createroot": {
                    String value = getParameter(body, "rootData");
                    if (value == null || value.isBlank()) {
                        sendResponse(exchange, 400,
                                "{\"error\":\"Root value is required.\"}");
                        return;
                    }
                    binaryTree.createRoot(Integer.parseInt(value));
                    sendResponse(exchange, 200,
                            "{\"message\":\"Binary Tree root created successfully.\"}");
                    return;
                }

                case "addleft":
                case "addright": {
                    String parentText = getParameter(body, "parentData");
                    String childText = getParameter(body, "childData");
                    if (parentText == null || parentText.isBlank()
                            || childText == null || childText.isBlank()) {
                        sendResponse(exchange, 400,
                                "{\"error\":\"Parent and child values are required.\"}");
                        return;
                    }
                    int parent = Integer.parseInt(parentText);
                    int child = Integer.parseInt(childText);
                    if (!binaryTree.contains(parent)) {
                        sendResponse(exchange, 404,
                                "{\"error\":\"Parent node was not found. Create the root and parent first.\"}");
                        return;
                    }
                    if (action.equalsIgnoreCase("addleft")) {
                        binaryTree.addLeft(parent, child);
                    } else {
                        binaryTree.addRight(parent, child);
                    }
                    sendResponse(exchange, 200,
                            "{\"message\":\"Child node added successfully.\"}");
                    return;
                }

                case "preorder":
                    sendResponse(exchange, 200,
                            "{\"traversal\":\"preorder\",\"result\":\""
                                    + escapeJson(binaryTree.preorderString()) + "\"}");
                    return;

                case "inorder":
                    sendResponse(exchange, 200,
                            "{\"traversal\":\"inorder\",\"result\":\""
                                    + escapeJson(binaryTree.inorderString()) + "\"}");
                    return;

                case "postorder":
                    sendResponse(exchange, 200,
                            "{\"traversal\":\"postorder\",\"result\":\""
                                    + escapeJson(binaryTree.postorderString()) + "\"}");
                    return;

                default:
                    sendResponse(exchange, 400,
                            "{\"error\":\"Invalid Binary Tree action.\"}");
            }
        } catch (NumberFormatException e) {
            sendResponse(exchange, 400,
                    "{\"error\":\"Tree values must be valid integers.\"}");
        } catch (Exception e) {
            e.printStackTrace();
            sendResponse(exchange, 500,
                    "{\"error\":\"Unable to perform Binary Tree operation.\"}");
        }
    }


    // ==========================================================
    // MODULE 3 - BINARY SEARCH TREE API
    // ==========================================================

    private static void handleBinarySearchTree(HttpExchange exchange)
            throws IOException {

        addCorsHeaders(exchange);
        String method = exchange.getRequestMethod();

        if (method.equalsIgnoreCase("OPTIONS")) {
            sendResponse(exchange, 204, "");
            return;
        }

        if (!method.equalsIgnoreCase("POST")) {
            sendResponse(exchange, 405,
                    "{\"error\":\"Method not allowed. Use POST.\"}");
            return;
        }

        String body = new String(
                exchange.getRequestBody().readAllBytes(),
                StandardCharsets.UTF_8
        );
        String action = getParameter(body, "action");

        try {
            if (action == null || action.isBlank()) {
                sendResponse(exchange, 400,
                        "{\"error\":\"BST action is required.\"}");
                return;
            }

            switch (action.toLowerCase()) {
                case "insert": {
                    String idText = getParameter(body, "itemId");
                    String name = getParameter(body, "itemName");
                    if (idText == null || idText.isBlank()
                            || name == null || name.isBlank()) {
                        sendResponse(exchange, 400,
                                "{\"error\":\"Item ID and item name are required.\"}");
                        return;
                    }
                    int itemId = Integer.parseInt(idText);
                    if (binarySearchTree.search(itemId) != null) {
                        sendResponse(exchange, 409,
                                "{\"error\":\"This Item ID already exists in the BST.\"}");
                        return;
                    }
                    binarySearchTree.insert(itemId, name.trim());
                    sendResponse(exchange, 200,
                            "{\"message\":\"Menu item inserted into BST successfully.\"}");
                    return;
                }

                case "search": {
                    String idText = getParameter(body, "itemId");
                    if (idText == null || idText.isBlank()) {
                        sendResponse(exchange, 400,
                                "{\"error\":\"Item ID is required for searching.\"}");
                        return;
                    }
                    int itemId = Integer.parseInt(idText);
                    String name = binarySearchTree.search(itemId);
                    if (name == null) {
                        sendResponse(exchange, 404,
                                "{\"error\":\"Item ID not found in BST.\"}");
                    } else {
                        sendResponse(exchange, 200,
                                "{\"itemId\":" + itemId
                                        + ",\"itemName\":\"" + escapeJson(name) + "\"}");
                    }
                    return;
                }

                case "display":
                    sendResponse(exchange, 200,
                            "{\"traversal\":\"inorder\",\"result\":\""
                                    + escapeJson(binarySearchTree.displayInorderString()) + "\"}");
                    return;

                default:
                    sendResponse(exchange, 400,
                            "{\"error\":\"Invalid BST action. Use insert, search or display.\"}");
            }
        } catch (NumberFormatException e) {
            sendResponse(exchange, 400,
                    "{\"error\":\"Item ID must be a valid integer.\"}");
        } catch (Exception e) {
            e.printStackTrace();
            sendResponse(exchange, 500,
                    "{\"error\":\"Unable to perform BST operation.\"}");
        }
    }


    // ==========================================================
    // MODULE 4 - GRAPH AND BFS API
    // ==========================================================

    private static void handleGraph(HttpExchange exchange)
            throws IOException {

        addCorsHeaders(exchange);

        String method = exchange.getRequestMethod();

        if (method.equalsIgnoreCase("OPTIONS")) {
            sendResponse(exchange, 204, "");
            return;
        }

        if (!method.equalsIgnoreCase("POST")) {
            sendResponse(exchange, 405,
                    "{\"error\":\"Method not allowed. Use POST.\"}");
            return;
        }

        String body = new String(
                exchange.getRequestBody().readAllBytes(),
                StandardCharsets.UTF_8
        );

        String action = getParameter(body, "action");

        if (action == null || action.isBlank()) {
            sendResponse(exchange, 400,
                    "{\"error\":\"Graph action is required.\"}");
            return;
        }

        try {
            switch (action.trim().toLowerCase()) {
                case "addedge": {
                    String sourceText = getParameter(body, "source");
                    String destinationText = getParameter(body, "destination");

                    if (sourceText == null || sourceText.isBlank()
                            || destinationText == null || destinationText.isBlank()) {
                        sendResponse(exchange, 400,
                                "{\"error\":\"Source and destination vertices are required.\"}");
                        return;
                    }

                    int source = Integer.parseInt(sourceText);
                    int destination = Integer.parseInt(destinationText);
                    cafeteriaGraph.addEdge(source, destination);

                    sendResponse(exchange, 200,
                            "{\"message\":\"Graph connection added successfully.\","
                                    + "\"graph\":\""
                                    + escapeJson(cafeteriaGraph.displayGraph())
                                    + "\"}");
                    return;
                }

                case "display":
                    sendResponse(exchange, 200,
                            "{\"graph\":\""
                                    + escapeJson(cafeteriaGraph.displayGraph())
                                    + "\"}");
                    return;

                case "bfs": {
                    String startText = getParameter(body, "startVertex");
                    if (startText == null || startText.isBlank()) {
                        sendResponse(exchange, 400,
                                "{\"error\":\"Start vertex is required.\"}");
                        return;
                    }

                    int startVertex = Integer.parseInt(startText);
                    String traversal = cafeteriaGraph.bfs(startVertex);

                    sendResponse(exchange, 200,
                            "{\"startVertex\":" + startVertex
                                    + ",\"traversal\":\""
                                    + escapeJson(traversal) + "\"}");
                    return;
                }

                default:
                    sendResponse(exchange, 400,
                            "{\"error\":\"Invalid Graph action. Use addEdge, display or bfs.\"}");
            }
        } catch (NumberFormatException e) {
            sendResponse(exchange, 400,
                    "{\"error\":\"Vertex values must be valid integers.\"}");
        } catch (IllegalArgumentException e) {
            sendResponse(exchange, 400,
                    "{\"error\":\"" + escapeJson(e.getMessage()) + "\"}");
        } catch (Exception e) {
            e.printStackTrace();
            sendResponse(exchange, 500,
                    "{\"error\":\"Unable to perform Graph operation.\"}");
        }
    }


    // ==========================================================
    // ORDER JSON
    // ==========================================================

    private static String orderToJson(
            Order order
    ) {

        StringBuilder json =
                new StringBuilder();


        json.append("{");


        json.append("\"order_id\":")
                .append(
                        order.getOrderId()
                )
                .append(",");


        json.append("\"customer_id\":")
                .append(
                        order.getCustomerId()
                )
                .append(",");


        json.append("\"order_date\":\"")
                .append(
                        escapeJson(
                                order.getOrderDate()
                        )
                )
                .append("\",");


        json.append("\"total_amount\":")
                .append(
                        order.getTotalAmount()
                )
                .append(",");


        json.append("\"status\":\"")
                .append(
                        escapeJson(
                                order.getStatus()
                        )
                )
                .append("\"");


        json.append("}");


        return json.toString();
    }


    // ==========================================================
    // GET FORM PARAMETER
    // ==========================================================

    private static String getParameter(
            String body,
            String parameterName
    ) {

        if (body == null) {
            return null;
        }


        String[] parameters =
                body.split("&");


        for (String parameter :
                parameters) {

            String[] pair =
                    parameter.split(
                            "=",
                            2
                    );


            if (pair.length == 2) {

                String name =
                        URLDecoder.decode(
                                pair[0],
                                StandardCharsets.UTF_8
                        );


                if (name.equals(
                        parameterName
                )) {

                    return URLDecoder.decode(
                            pair[1],
                            StandardCharsets.UTF_8
                    );
                }
            }
        }


        return null;
    }


    // ==========================================================
    // GET QUERY PARAMETER
    // ==========================================================

    private static String getQueryParameter(
            String query,
            String parameterName
    ) {

        if (query == null ||
            query.isEmpty()) {

            return null;
        }


        String[] parameters =
                query.split("&");


        for (String parameter :
                parameters) {

            String[] pair =
                    parameter.split(
                            "=",
                            2
                    );


            if (pair.length == 2) {

                String name =
                        URLDecoder.decode(
                                pair[0],
                                StandardCharsets.UTF_8
                        );


                if (name.equals(
                        parameterName
                )) {

                    return URLDecoder.decode(
                            pair[1],
                            StandardCharsets.UTF_8
                    );
                }
            }
        }


        return null;
    }


    // ==========================================================
    // ESCAPE JSON
    // ==========================================================

    private static String escapeJson(
            String text
    ) {

        if (text == null) {

            return "";
        }


        return text
                .replace(
                        "\\",
                        "\\\\"
                )
                .replace(
                        "\"",
                        "\\\""
                )
                .replace(
                        "\n",
                        "\\n"
                )
                .replace(
                        "\r",
                        "\\r"
                );
    }


    // ==========================================================
    // CORS
    // ==========================================================

    private static void addCorsHeaders(
            HttpExchange exchange
    ) {

        exchange.getResponseHeaders().set(
                "Access-Control-Allow-Origin",
                "*"
        );


        exchange.getResponseHeaders().set(
                "Access-Control-Allow-Methods",
                "GET, POST, OPTIONS"
        );


        exchange.getResponseHeaders().set(
                "Access-Control-Allow-Headers",
                "Content-Type"
        );
    }


    // ==========================================================
    // SEND RESPONSE
    // ==========================================================

    private static void sendResponse(
            HttpExchange exchange,
            int statusCode,
            String response
    ) throws IOException {


        byte[] responseBytes =
                response.getBytes(
                        StandardCharsets.UTF_8
                );


        exchange.getResponseHeaders().set(
                "Content-Type",
                "application/json; charset=UTF-8"
        );


        exchange.sendResponseHeaders(
                statusCode,
                responseBytes.length
        );


        try (
                OutputStream outputStream =
                        exchange.getResponseBody()
        ) {

            outputStream.write(
                    responseBytes
            );
        }
    }

    // ==========================================================
    // ORDER ITEMS API
    // GET + POST
    // ==========================================================

    private static void handleOrderItems(
            HttpExchange exchange
    ) throws IOException {

        addCorsHeaders(exchange);

        String method =
                exchange.getRequestMethod();

        if (method.equalsIgnoreCase("OPTIONS")) {
            sendResponse(exchange, 204, "");
            return;
        }

        if (method.equalsIgnoreCase("GET")) {

            String query =
                    exchange.getRequestURI().getQuery();

            String orderItemIdText =
                    getQueryParameter(query, "id");

            if (orderItemIdText != null &&
                !orderItemIdText.isBlank()) {

                try {

                    int orderItemId =
                            Integer.parseInt(orderItemIdText);

                    OrderItem orderItem =
                            orderItemDAO.getOrderItemById(
                                    orderItemId
                            );

                    if (orderItem == null) {

                        sendResponse(
                                exchange,
                                404,
                                "{\"message\":\"Order item not found.\"}"
                        );

                        return;
                    }

                    sendResponse(
                            exchange,
                            200,
                            orderItemToJson(orderItem)
                    );

                    return;

                } catch (NumberFormatException e) {

                    sendResponse(
                            exchange,
                            400,
                            "{\"message\":\"Invalid Order Item ID.\"}"
                    );

                    return;
                }
            }

            List<OrderItem> orderItems =
                    orderItemDAO.getAllOrderItems();

            sendResponse(
                    exchange,
                    200,
                    orderItemsToJson(orderItems)
            );

            return;
        }

        if (method.equalsIgnoreCase("POST")) {

            String requestBody =
                    new String(
                            exchange
                                    .getRequestBody()
                                    .readAllBytes(),
                            StandardCharsets.UTF_8
                    );

            String action =
                    getParameter(
                            requestBody,
                            "action"
                    );

            // ------------------------------------------------------
            // DELETE
            // ------------------------------------------------------

            if (action != null &&
                action.equalsIgnoreCase("delete")) {

                try {

                    String orderItemIdText =
                            getParameter(
                                    requestBody,
                                    "orderItemId"
                            );

                    if (orderItemIdText == null ||
                        orderItemIdText.trim().isEmpty()) {

                        sendResponse(
                                exchange,
                                400,
                                "{\"message\":\"Order Item ID is required.\"}"
                        );

                        return;
                    }

                    int orderItemId =
                            Integer.parseInt(
                                    orderItemIdText
                            );

                    OrderItem existing =
                            orderItemDAO.getOrderItemById(
                                    orderItemId
                            );

                    if (existing == null) {

                        sendResponse(
                                exchange,
                                404,
                                "{\"message\":\"Order item not found.\"}"
                        );

                        return;
                    }

                    orderItemDAO.deleteOrderItem(
                            orderItemId
                    );

                    OrderItem deletedCheck =
                            orderItemDAO.getOrderItemById(
                                    orderItemId
                            );

                    if (deletedCheck != null) {

                        sendResponse(
                                exchange,
                                500,
                                "{\"message\":\"Order item could not be deleted from MySQL.\"}"
                        );

                        return;
                    }

                    sendResponse(
                            exchange,
                            200,
                            "{\"message\":\"Order item deleted successfully.\"}"
                    );

                    return;

                } catch (NumberFormatException e) {

                    sendResponse(
                            exchange,
                            400,
                            "{\"message\":\"Invalid Order Item ID.\"}"
                    );

                    return;

                } catch (Exception e) {

                    e.printStackTrace();

                    sendResponse(
                            exchange,
                            500,
                            "{\"message\":\"Unable to delete order item.\"}"
                    );

                    return;
                }
            }

            // ------------------------------------------------------
            // ADD / UPDATE
            // ------------------------------------------------------

            try {

                String orderItemIdText =
                        getParameter(
                                requestBody,
                                "orderItemId"
                        );

                String orderIdText =
                        getParameter(
                                requestBody,
                                "orderId"
                        );

                String itemIdText =
                        getParameter(
                                requestBody,
                                "itemId"
                        );

                String quantityText =
                        getParameter(
                                requestBody,
                                "quantity"
                        );

                String subtotalText =
                        getParameter(
                                requestBody,
                                "subtotal"
                        );

                if (orderItemIdText == null ||
                    orderItemIdText.trim().isEmpty() ||
                    orderIdText == null ||
                    orderIdText.trim().isEmpty() ||
                    itemIdText == null ||
                    itemIdText.trim().isEmpty() ||
                    quantityText == null ||
                    quantityText.trim().isEmpty() ||
                    subtotalText == null ||
                    subtotalText.trim().isEmpty()) {

                    sendResponse(
                            exchange,
                            400,
                            "{\"message\":\"All order item fields are required.\"}"
                    );

                    return;
                }

                int orderItemId =
                        Integer.parseInt(
                                orderItemIdText
                        );

                int orderId =
                        Integer.parseInt(
                                orderIdText
                        );

                int itemId =
                        Integer.parseInt(
                                itemIdText
                        );

                int quantity =
                        Integer.parseInt(
                                quantityText
                        );

                double subtotal =
                        Double.parseDouble(
                                subtotalText
                        );

                if (quantity <= 0) {

                    sendResponse(
                            exchange,
                            400,
                            "{\"message\":\"Quantity must be greater than zero.\"}"
                    );

                    return;
                }

                if (subtotal < 0) {

                    sendResponse(
                            exchange,
                            400,
                            "{\"message\":\"Subtotal cannot be negative.\"}"
                    );

                    return;
                }

                // Check that the referenced order exists.
                if (orderDAO.getOrderById(orderId) == null) {

                    sendResponse(
                            exchange,
                            400,
                            "{\"message\":\"Order ID does not exist.\"}"
                    );

                    return;
                }

                // Check that the referenced menu item exists.
                if (menuItemDAO.getMenuItemById(itemId) == null) {

                    sendResponse(
                            exchange,
                            400,
                            "{\"message\":\"Item ID does not exist.\"}"
                    );

                    return;
                }

                OrderItem existing =
                        orderItemDAO.getOrderItemById(
                                orderItemId
                        );

                OrderItem orderItem =
                        new OrderItem(
                                orderItemId,
                                orderId,
                                itemId,
                                quantity,
                                subtotal
                        );

                if (existing == null) {

                    orderItemDAO.addOrderItem(
                            orderItem
                    );

                    OrderItem saved =
                            orderItemDAO.getOrderItemById(
                                    orderItemId
                            );

                    if (saved == null) {

                        sendResponse(
                                exchange,
                                500,
                                "{\"message\":\"Order item could not be saved to MySQL.\"}"
                        );

                        return;
                    }

                    sendResponse(
                            exchange,
                            201,
                            "{\"message\":\"Order item added successfully.\"}"
                    );

                    return;
                }

                orderItemDAO.updateOrderItem(
                        orderItem
                );

                OrderItem updated =
                        orderItemDAO.getOrderItemById(
                                orderItemId
                        );

                if (updated == null) {

                    sendResponse(
                            exchange,
                            500,
                            "{\"message\":\"Order item update could not be verified.\"}"
                    );

                    return;
                }

                sendResponse(
                        exchange,
                        200,
                        "{\"message\":\"Order item updated successfully.\"}"
                );

                return;

            } catch (NumberFormatException e) {

                sendResponse(
                        exchange,
                        400,
                        "{\"message\":\"Invalid order item data.\"}"
                );

                return;

            } catch (Exception e) {

                e.printStackTrace();

                sendResponse(
                        exchange,
                        500,
                        "{\"message\":\"Unable to save order item.\"}"
                );

                return;
            }
        }

        sendResponse(
                exchange,
                405,
                "{\"message\":\"Method not allowed.\"}"
        );
    }


    // ==========================================================
    // ORDER ITEM JSON
    // ==========================================================

    private static String orderItemToJson(
            OrderItem orderItem
    ) {

        return "{"
                + "\"orderItemId\":"
                + orderItem.getOrderItemId()
                + ","
                + "\"orderId\":"
                + orderItem.getOrderId()
                + ","
                + "\"itemId\":"
                + orderItem.getItemId()
                + ","
                + "\"quantity\":"
                + orderItem.getQuantity()
                + ","
                + "\"subtotal\":"
                + orderItem.getSubtotal()
                + "}";
    }


    // ==========================================================
    // ALL ORDER ITEMS JSON
    // ==========================================================

    private static String orderItemsToJson(
            List<OrderItem> orderItems
    ) {

        StringBuilder json =
                new StringBuilder("[");

        for (int i = 0;
             i < orderItems.size();
             i++) {

            json.append(
                    orderItemToJson(
                            orderItems.get(i)
                    )
            );

            if (i < orderItems.size() - 1) {
                json.append(",");
            }
        }

        json.append("]");

        return json.toString();
    }


    // ==========================================================
    // SECTIONS API
    // ==========================================================

    private static void handleSections(
            HttpExchange exchange
    ) throws IOException {

        addCorsHeaders(exchange);

        String method =
                exchange.getRequestMethod();

        if (method.equalsIgnoreCase("OPTIONS")) {
            sendResponse(exchange, 204, "");
            return;
        }

        if (method.equalsIgnoreCase("GET")) {

            String query =
                    exchange.getRequestURI().getQuery();

            String sectionIdText =
                    getQueryParameter(query, "id");

            if (sectionIdText != null &&
                !sectionIdText.isBlank()) {

                try {

                    int sectionId =
                            Integer.parseInt(sectionIdText);

                    CafeteriaSection section =
                            sectionDAO.getSectionById(sectionId);

                    if (section == null) {
                        sendResponse(
                                exchange,
                                404,
                                "{\"message\":\"Section not found.\"}"
                        );
                        return;
                    }

                    sendResponse(
                            exchange,
                            200,
                            sectionToJson(section)
                    );
                    return;

                } catch (NumberFormatException e) {
                    sendResponse(
                            exchange,
                            400,
                            "{\"message\":\"Invalid Section ID.\"}"
                    );
                    return;
                }
            }

            List<CafeteriaSection> sections =
                    sectionDAO.getAllSections();

            sendResponse(
                    exchange,
                    200,
                    sectionsToJson(sections)
            );
            return;
        }

        if (method.equalsIgnoreCase("POST")) {

            String requestBody =
                    new String(
                            exchange.getRequestBody().readAllBytes(),
                            StandardCharsets.UTF_8
                    );

            String action =
                    getParameter(requestBody, "action");

            if (action != null &&
                action.equalsIgnoreCase("delete")) {

                try {

                    String sectionIdText =
                            getParameter(requestBody, "sectionId");

                    if (sectionIdText == null ||
                        sectionIdText.trim().isEmpty()) {

                        sendResponse(
                                exchange,
                                400,
                                "{\"message\":\"Section ID is required.\"}"
                        );
                        return;
                    }

                    int sectionId =
                            Integer.parseInt(sectionIdText);

                    if (sectionDAO.getSectionById(sectionId) == null) {
                        sendResponse(
                                exchange,
                                404,
                                "{\"message\":\"Section not found.\"}"
                        );
                        return;
                    }

                    sectionDAO.deleteSection(sectionId);

                    if (sectionDAO.getSectionById(sectionId) != null) {
                        sendResponse(
                                exchange,
                                500,
                                "{\"message\":\"Section could not be deleted from MySQL.\"}"
                        );
                        return;
                    }

                    sendResponse(
                            exchange,
                            200,
                            "{\"message\":\"Section deleted successfully.\"}"
                    );
                    return;

                } catch (NumberFormatException e) {
                    sendResponse(
                            exchange,
                            400,
                            "{\"message\":\"Invalid Section ID.\"}"
                    );
                    return;

                } catch (Exception e) {
                    e.printStackTrace();
                    sendResponse(
                            exchange,
                            500,
                            "{\"message\":\"Unable to delete section.\"}"
                    );
                    return;
                }
            }

            try {

                String sectionIdText =
                        getParameter(requestBody, "sectionId");

                String sectionName =
                        getParameter(requestBody, "sectionName");

                String description =
                        getParameter(requestBody, "description");

                if (sectionIdText == null ||
                    sectionIdText.trim().isEmpty() ||
                    sectionName == null ||
                    sectionName.trim().isEmpty()) {

                    sendResponse(
                            exchange,
                            400,
                            "{\"message\":\"Section ID and Section Name are required.\"}"
                    );
                    return;
                }

                int sectionId =
                        Integer.parseInt(sectionIdText);

                if (description == null) {
                    description = "";
                }

                CafeteriaSection section =
                        new CafeteriaSection(
                                sectionId,
                                sectionName.trim(),
                                description.trim()
                        );

                CafeteriaSection existing =
                        sectionDAO.getSectionById(sectionId);

                if (existing == null) {

                    sectionDAO.addSection(section);

                    if (sectionDAO.getSectionById(sectionId) == null) {
                        sendResponse(
                                exchange,
                                500,
                                "{\"message\":\"Section could not be saved to MySQL.\"}"
                        );
                        return;
                    }

                    sendResponse(
                            exchange,
                            201,
                            "{\"message\":\"Section added successfully.\"}"
                    );
                    return;
                }

                sectionDAO.updateSection(section);

                if (sectionDAO.getSectionById(sectionId) == null) {
                    sendResponse(
                            exchange,
                            500,
                            "{\"message\":\"Section update could not be verified.\"}"
                    );
                    return;
                }

                sendResponse(
                        exchange,
                        200,
                        "{\"message\":\"Section updated successfully.\"}"
                );
                return;

            } catch (NumberFormatException e) {
                sendResponse(
                        exchange,
                        400,
                        "{\"message\":\"Invalid Section ID.\"}"
                );
                return;

            } catch (Exception e) {
                e.printStackTrace();
                sendResponse(
                        exchange,
                        500,
                        "{\"message\":\"Unable to save section.\"}"
                );
                return;
            }
        }

        sendResponse(
                exchange,
                405,
                "{\"message\":\"Method not allowed.\"}"
        );
    }


    // ==========================================================
    // CATEGORIES API
    // ==========================================================

    private static void handleCategories(
            HttpExchange exchange
    ) throws IOException {

        addCorsHeaders(exchange);

        String method =
                exchange.getRequestMethod();

        if (method.equalsIgnoreCase("OPTIONS")) {
            sendResponse(exchange, 204, "");
            return;
        }

        if (method.equalsIgnoreCase("GET")) {

            String query =
                    exchange.getRequestURI().getQuery();

            String categoryIdText =
                    getQueryParameter(query, "id");

            if (categoryIdText != null &&
                !categoryIdText.isBlank()) {

                try {

                    int categoryId =
                            Integer.parseInt(categoryIdText);

                    Category category =
                            categoryDAO.getCategoryById(categoryId);

                    if (category == null) {
                        sendResponse(
                                exchange,
                                404,
                                "{\"message\":\"Category not found.\"}"
                        );
                        return;
                    }

                    sendResponse(
                            exchange,
                            200,
                            categoryToJson(category)
                    );
                    return;

                } catch (NumberFormatException e) {
                    sendResponse(
                            exchange,
                            400,
                            "{\"message\":\"Invalid Category ID.\"}"
                    );
                    return;
                }
            }

            List<Category> categories =
                    categoryDAO.getAllCategories();

            sendResponse(
                    exchange,
                    200,
                    categoriesToJson(categories)
            );
            return;
        }

        if (method.equalsIgnoreCase("POST")) {

            String requestBody =
                    new String(
                            exchange.getRequestBody().readAllBytes(),
                            StandardCharsets.UTF_8
                    );

            String action =
                    getParameter(requestBody, "action");

            if (action != null &&
                action.equalsIgnoreCase("delete")) {

                try {

                    String categoryIdText =
                            getParameter(requestBody, "categoryId");

                    if (categoryIdText == null ||
                        categoryIdText.trim().isEmpty()) {

                        sendResponse(
                                exchange,
                                400,
                                "{\"message\":\"Category ID is required.\"}"
                        );
                        return;
                    }

                    int categoryId =
                            Integer.parseInt(categoryIdText);

                    if (categoryDAO.getCategoryById(categoryId) == null) {
                        sendResponse(
                                exchange,
                                404,
                                "{\"message\":\"Category not found.\"}"
                        );
                        return;
                    }

                    categoryDAO.deleteCategory(categoryId);

                    if (categoryDAO.getCategoryById(categoryId) != null) {
                        sendResponse(
                                exchange,
                                500,
                                "{\"message\":\"Category could not be deleted from MySQL. It may be used by menu items.\"}"
                        );
                        return;
                    }

                    sendResponse(
                            exchange,
                            200,
                            "{\"message\":\"Category deleted successfully.\"}"
                    );
                    return;

                } catch (NumberFormatException e) {
                    sendResponse(
                            exchange,
                            400,
                            "{\"message\":\"Invalid Category ID.\"}"
                    );
                    return;

                } catch (Exception e) {
                    e.printStackTrace();
                    sendResponse(
                            exchange,
                            500,
                            "{\"message\":\"Unable to delete category.\"}"
                    );
                    return;
                }
            }

            try {

                String categoryIdText =
                        getParameter(requestBody, "categoryId");

                String categoryName =
                        getParameter(requestBody, "categoryName");

                if (categoryIdText == null ||
                    categoryIdText.trim().isEmpty() ||
                    categoryName == null ||
                    categoryName.trim().isEmpty()) {

                    sendResponse(
                            exchange,
                            400,
                            "{\"message\":\"Category ID and Category Name are required.\"}"
                    );
                    return;
                }

                int categoryId =
                        Integer.parseInt(categoryIdText);

                Category category =
                        new Category(
                                categoryId,
                                categoryName.trim()
                        );

                Category existing =
                        categoryDAO.getCategoryById(categoryId);

                if (existing == null) {

                    categoryDAO.addCategory(category);

                    if (categoryDAO.getCategoryById(categoryId) == null) {
                        sendResponse(
                                exchange,
                                500,
                                "{\"message\":\"Category could not be saved to MySQL.\"}"
                        );
                        return;
                    }

                    sendResponse(
                            exchange,
                            201,
                            "{\"message\":\"Category added successfully.\"}"
                    );
                    return;
                }

                categoryDAO.updateCategory(category);

                Category updated =
                        categoryDAO.getCategoryById(categoryId);

                if (updated == null ||
                    !updated.getCategoryName().equals(category.getCategoryName())) {

                    sendResponse(
                            exchange,
                            500,
                            "{\"message\":\"Category update could not be verified.\"}"
                    );
                    return;
                }

                sendResponse(
                        exchange,
                        200,
                        "{\"message\":\"Category updated successfully.\"}"
                );
                return;

            } catch (NumberFormatException e) {
                sendResponse(
                        exchange,
                        400,
                        "{\"message\":\"Invalid Category ID.\"}"
                );
                return;

            } catch (Exception e) {
                e.printStackTrace();
                sendResponse(
                        exchange,
                        500,
                        "{\"message\":\"Unable to save category.\"}"
                );
                return;
            }
        }

        sendResponse(
                exchange,
                405,
                "{\"message\":\"Method not allowed.\"}"
        );
    }


    // ==========================================================
    // SECTION JSON
    // ==========================================================

    private static String sectionToJson(
            CafeteriaSection section
    ) {

        return "{"
                + "\"sectionId\":"
                + section.getSectionId()
                + ","
                + "\"sectionName\":\""
                + escapeJson(section.getSectionName())
                + "\","
                + "\"description\":\""
                + escapeJson(section.getDescription())
                + "\""
                + "}";
    }


    private static String sectionsToJson(
            List<CafeteriaSection> sections
    ) {

        StringBuilder json =
                new StringBuilder("[");

        for (int i = 0; i < sections.size(); i++) {

            json.append(
                    sectionToJson(sections.get(i))
            );

            if (i < sections.size() - 1) {
                json.append(",");
            }
        }

        json.append("]");

        return json.toString();
    }


    // ==========================================================
    // CATEGORY JSON
    // ==========================================================

    private static String categoryToJson(
            Category category
    ) {

        return "{"
                + "\"categoryId\":"
                + category.getCategoryId()
                + ","
                + "\"categoryName\":\""
                + escapeJson(category.getCategoryName())
                + "\""
                + "}";
    }


    private static String categoriesToJson(
            List<Category> categories
    ) {

        StringBuilder json =
                new StringBuilder("[");

        for (int i = 0; i < categories.size(); i++) {

            json.append(
                    categoryToJson(categories.get(i))
            );

            if (i < categories.size() - 1) {
                json.append(",");
            }
        }

        json.append("]");

        return json.toString();
    }

}