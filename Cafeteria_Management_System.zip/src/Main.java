import models.MenuItem;
import models.Customer;
import models.Order;

import datastructures.MenuLinkedList;
import datastructures.CustomerLinkedList;
import datastructures.OrderLinkedList;
import datastructures.ExpressionStack;
import datastructures.OrderQueue;
import datastructures.BinaryTree;
import datastructures.BinarySearchTree;
import datastructures.CafeteriaGraph;

import algorithms.LinearSearch;
import algorithms.BinarySearch;
import algorithms.BubbleSort;
import algorithms.SelectionSort;


public class Main {

    public static void main(String[] args) {

        System.out.println("=== CAFETERIA MANAGEMENT SYSTEM ===");


        // ==============================
        // CREATE MENU ITEMS
        // ==============================

        MenuItem item1 = new MenuItem(
                101,
                "Coffee",
                201,
                40.0,
                true
        );

        MenuItem item2 = new MenuItem(
                102,
                "Sandwich",
                202,
                80.0,
                true
        );


        // ==============================
        // CREATE CUSTOMERS
        // ==============================

        Customer customer1 = new Customer(
                1,
                "Nithyashree",
                "9876543210"
        );

        Customer customer2 = new Customer(
                2,
                "Harshith",
                "9876543211"
        );


        // ==============================
        // CREATE ORDERS
        // ==============================

        Order order1 = new Order(
                1001,
                1,
                "07-09-2026",
                40.0,
                "Pending"
        );

        Order order2 = new Order(
                1002,
                1,
                "07-09-2026",
                80.0,
                "Pending"
        );


        // ==============================
        // CUSTOMER DETAILS
        // ==============================

        System.out.println("\n=== CUSTOMER DETAILS ===");

        customer1.displayCustomer();

        customer2.displayCustomer();


        // ==============================
        // MENU LINKED LIST - CRUD
        // ==============================

        System.out.println(
                "\n=== MENU ITEMS USING LINKED LIST ==="
        );

        MenuLinkedList menuList =
                new MenuLinkedList();


        // CREATE

        System.out.println("\n--- CREATE ---");

        menuList.add(item1);
        menuList.add(item2);


        // READ

        System.out.println("\n--- READ ---");

        menuList.display();


        // UPDATE

        System.out.println("\n--- UPDATE ---");

        MenuItem updatedItem = new MenuItem(
                102,
                "Veg Sandwich",
                202,
                90.0,
                true
        );

        menuList.update(
                102,
                updatedItem
        );

        System.out.println(
                "\nMenu after update:"
        );

        menuList.display();


        // DELETE

        System.out.println("\n--- DELETE ---");

        menuList.delete(101);

        System.out.println(
                "\nMenu after deletion:"
        );

        menuList.display();


        // ==============================
        // CUSTOMER LINKED LIST - CRUD
        // ==============================

        System.out.println(
                "\n=== CUSTOMERS USING LINKED LIST ==="
        );

        CustomerLinkedList customerList =
                new CustomerLinkedList();


        // CREATE

        System.out.println(
                "\n--- CUSTOMER CREATE ---"
        );

        customerList.add(customer1);
        customerList.add(customer2);


        // READ

        System.out.println(
                "\n--- CUSTOMER READ ---"
        );

        customerList.display();


        // SEARCH

        System.out.println(
                "\n--- CUSTOMER SEARCH ---"
        );

        Customer foundCustomer =
                customerList.search(2);

        if (foundCustomer != null) {

            System.out.println(
                    "Customer found:"
            );

            foundCustomer.displayCustomer();

        } else {

            System.out.println(
                    "Customer not found."
            );
        }


        // UPDATE

        System.out.println(
                "\n--- CUSTOMER UPDATE ---"
        );

        Customer updatedCustomer =
                new Customer(
                        2,
                        "Harshith Updated",
                        "9999999999"
                );

        customerList.update(
                2,
                updatedCustomer
        );

        System.out.println(
                "\nCustomers after update:"
        );

        customerList.display();


        // DELETE

        System.out.println(
                "\n--- CUSTOMER DELETE ---"
        );

        customerList.delete(1);

        System.out.println(
                "\nCustomers after deletion:"
        );

        customerList.display();


        // ==============================
        // ORDER LINKED LIST - CRUD
        // ==============================

        System.out.println(
                "\n=== ORDERS USING LINKED LIST ==="
        );

        OrderLinkedList orderList =
                new OrderLinkedList();


        // CREATE

        System.out.println(
                "\n--- ORDER CREATE ---"
        );

        orderList.add(order1);
        orderList.add(order2);


        // READ

        System.out.println(
                "\n--- ORDER READ ---"
        );

        orderList.display();


        // SEARCH

        System.out.println(
                "\n--- ORDER SEARCH ---"
        );

        Order foundOrder =
                orderList.search(1002);

        if (foundOrder != null) {

            System.out.println(
                    "Order found:"
            );

            foundOrder.displayOrder();

        } else {

            System.out.println(
                    "Order not found."
            );
        }


        // UPDATE

        System.out.println(
                "\n--- ORDER UPDATE ---"
        );

        Order updatedOrder =
                new Order(
                        1002,
                        1,
                        "07-09-2026",
                        100.0,
                        "Completed"
                );

        orderList.update(
                1002,
                updatedOrder
        );

        System.out.println(
                "\nOrders after update:"
        );

        orderList.display();


        // DELETE

        System.out.println(
                "\n--- ORDER DELETE ---"
        );

        orderList.delete(1001);

        System.out.println(
                "\nOrders after deletion:"
        );

        orderList.display();


        // ==============================
        // STACK DEMONSTRATION
        // ==============================

        System.out.println(
                "\n=== STACK DEMONSTRATION ==="
        );

        /*
         * ExpressionStack is now implemented
         * using linked-list nodes.
         *
         * Therefore no fixed capacity is required.
         */

        ExpressionStack stack =
                new ExpressionStack();

        stack.push(20);
        stack.push(5);
        stack.push(10);

        System.out.println(
                "\nStack contents:"
        );

        stack.display();

        System.out.println(
                "\nPopped Element: " +
                stack.pop()
        );


        // ==============================
        // STACK EXPRESSION EVALUATION
        // ==============================

        System.out.println(
                "\n=== STACK EXPRESSION EVALUATION ==="
        );

        ExpressionStack expressionStack =
                new ExpressionStack();

        String expression =
                "10 5 + 2 *";

        System.out.println(
                "Postfix Expression: " +
                expression
        );

        int result =
                expressionStack.evaluatePostfix(
                        expression
                );

        System.out.println(
                "Expression Result: " +
                result
        );


        // ==============================
        // ORDER QUEUE DEMONSTRATION
        // ==============================

        System.out.println(
                "\n=== ORDER QUEUE DEMONSTRATION ==="
        );

        /*
         * Queue follows FIFO:
         * First In - First Out
         */

        OrderQueue orderQueue =
                new OrderQueue();


        // ENQUEUE ORDERS

        orderQueue.enqueue(order1);
        orderQueue.enqueue(order2);


        // DISPLAY QUEUE

        System.out.println(
                "\nOrders in Queue:"
        );

        orderQueue.display();


        // QUEUE SIZE

        System.out.println(
                "\nQueue Size: " +
                orderQueue.size()
        );


        // PEEK

        System.out.println(
                "\nNext Order in Queue:"
        );

        Order nextOrder =
                orderQueue.peek();

        if (nextOrder != null) {

            nextOrder.displayOrder();

        } else {

            System.out.println(
                    "Queue is empty."
            );
        }


        // DEQUEUE

        System.out.println(
                "\nProcessing First Order:"
        );

        Order processedOrder =
                orderQueue.dequeue();

        if (processedOrder != null) {

            processedOrder.displayOrder();

        } else {

            System.out.println(
                    "Queue is empty."
            );
        }


        System.out.println(
                "\nQueue after processing:"
        );

        orderQueue.display();


        // ==============================
        // BINARY TREE DEMONSTRATION
        // ==============================

        System.out.println(
                "\n=== BINARY TREE DEMONSTRATION ==="
        );

        BinaryTree tree =
                new BinaryTree();

        tree.createRoot(50);

        tree.addLeft(50, 30);
        tree.addRight(50, 70);

        tree.addLeft(30, 20);
        tree.addRight(30, 40);

        tree.addLeft(70, 60);
        tree.addRight(70, 80);


        // PREORDER

        System.out.print(
                "Preorder Traversal: "
        );

        tree.preorder();


        // INORDER

        System.out.print(
                "\nInorder Traversal: "
        );

        tree.inorder();


        // POSTORDER

        System.out.print(
                "\nPostorder Traversal: "
        );

        tree.postorder();

        System.out.println();


        // ==============================
        // BINARY SEARCH TREE
        // ==============================

        System.out.println(
                "\n=== BINARY SEARCH TREE DEMONSTRATION ==="
        );

        BinarySearchTree bst =
                new BinarySearchTree();


        bst.insert(101, "Coffee");
        bst.insert(102, "Sandwich");
        bst.insert(103, "Burger");
        bst.insert(104, "Tea");


        System.out.println(
                "Menu Items in BST:"
        );

        bst.displayInorder();


        int searchId = 103;

        String foundItem =
                bst.search(searchId);


        if (foundItem != null) {

            System.out.println(
                    "\nItem Found: ID = " +
                    searchId +
                    ", Name = " +
                    foundItem
            );

        } else {

            System.out.println(
                    "\nItem Not Found."
            );
        }


        // ==============================
        // GRAPH AND BFS
        // ==============================

        System.out.println(
                "\n=== CAFETERIA GRAPH AND BFS ==="
        );


        System.out.println(
                "0 = Order Counter\n" +
                "1 = Kitchen\n" +
                "2 = Billing Counter\n" +
                "3 = Pickup Area\n" +
                "4 = Dining Area"
        );


        CafeteriaGraph graph =
                new CafeteriaGraph(5);


        graph.addEdge(0, 1);
        graph.addEdge(0, 2);
        graph.addEdge(1, 3);
        graph.addEdge(2, 4);
        graph.addEdge(3, 4);


        System.out.print(
                "\nBFS Traversal Starting from Order Counter: "
        );


        graph.bfs(0);

        System.out.println();


        // ==============================
        // SEARCHING AND SORTING
        // ==============================

        System.out.println(
                "\n=== SEARCHING AND SORTING ALGORITHMS ==="
        );


        int[] menuItemIds =
                {104, 101, 103, 102, 105};


        System.out.print(
                "\nOriginal Menu Item IDs: "
        );


        for (int id : menuItemIds) {

            System.out.print(id + " ");
        }

        System.out.println();


        // ==============================
        // LINEAR SEARCH
        // ==============================

        int key = 103;

        int linearResult =
                LinearSearch.search(
                        menuItemIds,
                        key
                );


        if (linearResult != -1) {

            System.out.println(
                    "\nLinear Search: Item ID " +
                    key +
                    " found at index: " +
                    linearResult
            );

        } else {

            System.out.println(
                    "\nLinear Search: Item not found."
            );
        }


        // ==============================
        // BUBBLE SORT
        // ==============================

        int[] bubbleArray =
                {104, 101, 103, 102, 105};


        BubbleSort.sort(
                bubbleArray
        );


        System.out.print(
                "\nBubble Sorted IDs: "
        );


        for (int id : bubbleArray) {

            System.out.print(id + " ");
        }

        System.out.println();


        // ==============================
        // BINARY SEARCH
        // ==============================

        int binaryResult =
                BinarySearch.search(
                        bubbleArray,
                        key
                );


        if (binaryResult != -1) {

            System.out.println(
                    "\nBinary Search: Item ID " +
                    key +
                    " found at index: " +
                    binaryResult
            );

        } else {

            System.out.println(
                    "\nBinary Search: Item not found."
            );
        }


        // ==============================
        // SELECTION SORT
        // ==============================

        int[] selectionArray =
                {104, 101, 103, 102, 105};


        SelectionSort.sort(
                selectionArray
        );


        System.out.print(
                "\nSelection Sorted IDs: "
        );


        for (int id : selectionArray) {

            System.out.print(id + " ");
        }

        System.out.println();


        // ==============================
        // PERFORMANCE COMPARISON
        // ==============================

        System.out.println(
                "\n=== PERFORMANCE COMPARISON ==="
        );


        int[] performanceArray =
                {104, 101, 103, 102, 105};


        int performanceKey = 105;


        // ==============================
        // LINEAR SEARCH TIME
        // ==============================

        long startLinear =
                System.nanoTime();

        LinearSearch.search(
                performanceArray,
                performanceKey
        );

        long endLinear =
                System.nanoTime();


        long linearTime =
                endLinear - startLinear;


        // ==============================
        // BUBBLE SORT TIME
        // ==============================

        int[] performanceBubble =
                {104, 101, 103, 102, 105};


        long startBubble =
                System.nanoTime();

        BubbleSort.sort(
                performanceBubble
        );

        long endBubble =
                System.nanoTime();


        long bubbleTime =
                endBubble - startBubble;


        // ==============================
        // BINARY SEARCH TIME
        // ==============================

        long startBinary =
                System.nanoTime();

        BinarySearch.search(
                performanceBubble,
                performanceKey
        );

        long endBinary =
                System.nanoTime();


        long binaryTime =
                endBinary - startBinary;


        // DISPLAY TIMES

        System.out.println(
                "Linear Search Time: " +
                linearTime +
                " ns"
        );

        System.out.println(
                "Bubble Sort Time: " +
                bubbleTime +
                " ns"
        );

        System.out.println(
                "Binary Search Time: " +
                binaryTime +
                " ns"
        );


        // ==============================
        // PERFORMANCE SUMMARY
        // ==============================

        System.out.println(
                "\nPerformance Summary:"
        );

        System.out.println(
                "Linear Search: O(n)"
        );

        System.out.println(
                "Binary Search: O(log n)"
        );

        System.out.println(
                "Bubble Sort: O(n²)"
        );


        // ==============================
        // CAFETERIA WORKFLOW APPLICATION
        // ==============================

        System.out.println(
                "\n=== CAFETERIA WORKFLOW APPLICATION ==="
        );


        System.out.println(
                "Searching for Menu Item ID: " +
                performanceKey
        );


        int workflowResult =
                LinearSearch.search(
                        performanceArray,
                        performanceKey
                );


        if (workflowResult != -1) {

            System.out.println(
                    "Menu item found using Linear Search."
            );

        } else {

            System.out.println(
                    "Menu item not found."
            );
        }


        System.out.println(
                "Menu IDs are sorted using Bubble Sort."
        );

        System.out.println(
                "Sorted menu can then be searched using Binary Search."
        );


        // ==============================
        // PROGRAM END
        // ==============================

        System.out.println(
                "\n=== PROGRAM COMPLETED SUCCESSFULLY ==="
        );
    }
}