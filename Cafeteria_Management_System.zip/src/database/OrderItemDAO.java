package database;

import models.OrderItem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderItemDAO {


    // ==========================================================
    // ADD ORDER ITEM
    // ==========================================================

    public void addOrderItem(OrderItem orderItem) {

        String sql =
                "INSERT INTO order_items " +
                "(order_item_id, order_id, item_id, quantity, subtotal) " +
                "VALUES (?, ?, ?, ?, ?)";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    orderItem.getOrderItemId()
            );

            statement.setInt(
                    2,
                    orderItem.getOrderId()
            );

            statement.setInt(
                    3,
                    orderItem.getItemId()
            );

            statement.setInt(
                    4,
                    orderItem.getQuantity()
            );

            statement.setDouble(
                    5,
                    orderItem.getSubtotal()
            );

            int rowsInserted =
                    statement.executeUpdate();

            if (rowsInserted > 0) {

                System.out.println(
                        "Order item added successfully!"
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error adding order item!"
            );

            e.printStackTrace();
        }
    }


    // ==========================================================
    // GET ORDER ITEM BY ID
    // ==========================================================

    public OrderItem getOrderItemById(
            int orderItemId
    ) {

        String sql =
                "SELECT " +
                "order_item_id, " +
                "order_id, " +
                "item_id, " +
                "quantity, " +
                "subtotal " +
                "FROM order_items " +
                "WHERE order_item_id = ?";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    orderItemId
            );

            ResultSet resultSet =
                    statement.executeQuery();

            if (resultSet.next()) {

                return new OrderItem(

                        resultSet.getInt(
                                "order_item_id"
                        ),

                        resultSet.getInt(
                                "order_id"
                        ),

                        resultSet.getInt(
                                "item_id"
                        ),

                        resultSet.getInt(
                                "quantity"
                        ),

                        resultSet.getDouble(
                                "subtotal"
                        )
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error retrieving order item!"
            );

            e.printStackTrace();
        }

        return null;
    }


    // ==========================================================
    // GET ALL ORDER ITEMS
    // ==========================================================

    public List<OrderItem> getAllOrderItems() {

        List<OrderItem> orderItems =
                new ArrayList<>();

        String sql =
                "SELECT " +
                "order_item_id, " +
                "order_id, " +
                "item_id, " +
                "quantity, " +
                "subtotal " +
                "FROM order_items " +
                "ORDER BY order_item_id";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet resultSet =
                        statement.executeQuery()
        ) {

            while (resultSet.next()) {

                OrderItem orderItem =
                        new OrderItem(

                                resultSet.getInt(
                                        "order_item_id"
                                ),

                                resultSet.getInt(
                                        "order_id"
                                ),

                                resultSet.getInt(
                                        "item_id"
                                ),

                                resultSet.getInt(
                                        "quantity"
                                ),

                                resultSet.getDouble(
                                        "subtotal"
                                )
                        );

                orderItems.add(orderItem);
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error retrieving order items!"
            );

            e.printStackTrace();
        }

        return orderItems;
    }


    // ==========================================================
    // DISPLAY ALL ORDER ITEMS
    // ==========================================================

    public void displayAllOrderItems() {

        List<OrderItem> orderItems =
                getAllOrderItems();

        System.out.println(
                "\n===== ORDER ITEMS ====="
        );

        if (orderItems.isEmpty()) {

            System.out.println(
                    "No order items found."
            );

            return;
        }

        for (OrderItem orderItem :
                orderItems) {

            orderItem.displayOrderItem();
        }
    }


    // ==========================================================
    // UPDATE ORDER ITEM
    // ==========================================================

    public void updateOrderItem(
            OrderItem orderItem
    ) {

        String sql =
                "UPDATE order_items SET " +
                "order_id = ?, " +
                "item_id = ?, " +
                "quantity = ?, " +
                "subtotal = ? " +
                "WHERE order_item_id = ?";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    orderItem.getOrderId()
            );

            statement.setInt(
                    2,
                    orderItem.getItemId()
            );

            statement.setInt(
                    3,
                    orderItem.getQuantity()
            );

            statement.setDouble(
                    4,
                    orderItem.getSubtotal()
            );

            statement.setInt(
                    5,
                    orderItem.getOrderItemId()
            );

            int rowsUpdated =
                    statement.executeUpdate();

            if (rowsUpdated > 0) {

                System.out.println(
                        "Order item updated successfully!"
                );

            } else {

                System.out.println(
                        "Order item not found!"
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error updating order item!"
            );

            e.printStackTrace();
        }
    }


    // ==========================================================
    // DELETE ORDER ITEM
    // ==========================================================

    public void deleteOrderItem(
            int orderItemId
    ) {

        String sql =
                "DELETE FROM order_items " +
                "WHERE order_item_id = ?";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    orderItemId
            );

            int rowsDeleted =
                    statement.executeUpdate();

            if (rowsDeleted > 0) {

                System.out.println(
                        "Order item deleted successfully!"
                );

            } else {

                System.out.println(
                        "Order item not found!"
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error deleting order item!"
            );

            e.printStackTrace();
        }
    }
}