package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import models.Order;

public class OrderDAO {

    // ==========================================================
    // ADD ORDER
    // ==========================================================

    public void addOrder(Order order) {

        String sql =
                "INSERT INTO orders " +
                "(order_id, customer_id, order_date, total_amount, status) " +
                "VALUES (?, ?, ?, ?, ?)";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    order.getOrderId()
            );

            statement.setInt(
                    2,
                    order.getCustomerId()
            );

            statement.setDate(
                    3,
                    java.sql.Date.valueOf(
                            convertDate(
                                    order.getOrderDate()
                            )
                    )
            );

            statement.setDouble(
                    4,
                    order.getTotalAmount()
            );

            statement.setString(
                    5,
                    order.getStatus()
            );


            int rowsInserted =
                    statement.executeUpdate();


            if (rowsInserted > 0) {

                System.out.println(
                        "Order added successfully!"
                );
            }


        } catch (
                SQLException |
                IllegalArgumentException e
        ) {

            System.out.println(
                    "Error adding order!"
            );

            e.printStackTrace();
        }
    }


    // ==========================================================
    // GET ORDER BY ID
    // ==========================================================

    public Order getOrderById(
            int orderId
    ) {

        String sql =
                "SELECT order_id, customer_id, " +
                "order_date, total_amount, status " +
                "FROM orders " +
                "WHERE order_id = ?";


        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    orderId
            );


            ResultSet resultSet =
                    statement.executeQuery();


            if (resultSet.next()) {

                return new Order(

                        resultSet.getInt(
                                "order_id"
                        ),

                        resultSet.getInt(
                                "customer_id"
                        ),

                        resultSet.getDate(
                                "order_date"
                        ).toString(),

                        resultSet.getDouble(
                                "total_amount"
                        ),

                        resultSet.getString(
                                "status"
                        )
                );
            }


        } catch (SQLException e) {

            System.out.println(
                    "Error retrieving order!"
            );

            e.printStackTrace();
        }


        return null;
    }


    // ==========================================================
    // DISPLAY ALL ORDERS
    // ==========================================================

    public void displayAllOrders() {

        String sql =
                "SELECT order_id, customer_id, " +
                "order_date, total_amount, status " +
                "FROM orders";


        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet resultSet =
                        statement.executeQuery()
        ) {

            while (resultSet.next()) {

                Order order =
                        new Order(

                                resultSet.getInt(
                                        "order_id"
                                ),

                                resultSet.getInt(
                                        "customer_id"
                                ),

                                resultSet.getDate(
                                        "order_date"
                                ).toString(),

                                resultSet.getDouble(
                                        "total_amount"
                                ),

                                resultSet.getString(
                                        "status"
                                )
                        );


                order.displayOrder();
            }


        } catch (SQLException e) {

            System.out.println(
                    "Error displaying orders!"
            );

            e.printStackTrace();
        }
    }


    // ==========================================================
    // UPDATE ORDER
    // ==========================================================

    public void updateOrder(
            Order order
    ) {

        String sql =
                "UPDATE orders SET " +
                "customer_id = ?, " +
                "order_date = ?, " +
                "total_amount = ?, " +
                "status = ? " +
                "WHERE order_id = ?";


        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    order.getCustomerId()
            );


            statement.setDate(
                    2,
                    java.sql.Date.valueOf(
                            convertDate(
                                    order.getOrderDate()
                            )
                    )
            );


            statement.setDouble(
                    3,
                    order.getTotalAmount()
            );


            statement.setString(
                    4,
                    order.getStatus()
            );


            statement.setInt(
                    5,
                    order.getOrderId()
            );


            int rowsUpdated =
                    statement.executeUpdate();


            if (rowsUpdated > 0) {

                System.out.println(
                        "Order updated successfully!"
                );

            } else {

                System.out.println(
                        "Order not found!"
                );
            }


        } catch (
                SQLException |
                IllegalArgumentException e
        ) {

            System.out.println(
                    "Error updating order!"
            );

            e.printStackTrace();
        }
    }


    // ==========================================================
    // DELETE ORDER
    //
    // Only Completed and Cancelled orders can be deleted.
    // Related order_items are deleted first.
    // ==========================================================

    public void deleteOrder(
            int orderId
    ) {

        String checkSql =
                "SELECT status " +
                "FROM orders " +
                "WHERE order_id = ?";


        String deleteOrderItemsSql =
                "DELETE FROM order_items " +
                "WHERE order_id = ?";


        String deleteOrderSql =
                "DELETE FROM orders " +
                "WHERE order_id = ?";


        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement checkStatement =
                        connection.prepareStatement(
                                checkSql
                        )
        ) {

            checkStatement.setInt(
                    1,
                    orderId
            );


            ResultSet resultSet =
                    checkStatement.executeQuery();


            if (!resultSet.next()) {

                System.out.println(
                        "Order not found!"
                );

                return;
            }


            String status =
                    resultSet.getString(
                            "status"
                    );


            // ==================================================
            // CHECK STATUS
            // ==================================================

            if (
                    status == null
                    ||
                    (
                        !status.equalsIgnoreCase(
                                "Completed"
                        )
                        &&
                        !status.equalsIgnoreCase(
                                "Cancelled"
                        )
                    )
            ) {

                System.out.println(
                        "Only Completed or Cancelled orders " +
                        "can be deleted."
                );

                return;
            }


            // ==================================================
            // START TRANSACTION
            // ==================================================

            connection.setAutoCommit(false);


            try {

                // ------------------------------------------------
                // DELETE ORDER ITEMS
                // ------------------------------------------------

                try (
                        PreparedStatement
                                orderItemStatement =
                                connection.prepareStatement(
                                        deleteOrderItemsSql
                                )
                ) {

                    orderItemStatement.setInt(
                            1,
                            orderId
                    );

                    orderItemStatement.executeUpdate();
                }


                // ------------------------------------------------
                // DELETE ORDER
                // ------------------------------------------------

                try (
                        PreparedStatement
                                orderStatement =
                                connection.prepareStatement(
                                        deleteOrderSql
                                )
                ) {

                    orderStatement.setInt(
                            1,
                            orderId
                    );


                    int rowsDeleted =
                            orderStatement.executeUpdate();


                    if (rowsDeleted > 0) {

                        connection.commit();

                        System.out.println(
                                "Order deleted successfully!"
                        );

                    } else {

                        connection.rollback();

                        System.out.println(
                                "Order could not be deleted."
                        );
                    }
                }


            } catch (SQLException e) {

                connection.rollback();

                throw e;
            }


        } catch (SQLException e) {

            System.out.println(
                    "Error deleting order!"
            );

            e.printStackTrace();
        }
    }


    // ==========================================================
    // DATE CONVERSION
    // ==========================================================

    private String convertDate(
            String date
    ) {

        if (
                date == null
                ||
                date.trim().isEmpty()
        ) {

            return date;
        }


        date = date.trim();


        String[] parts =
                date.split("-");


        if (parts.length != 3) {

            return date;
        }


        // HTML DATE FORMAT:
        // YYYY-MM-DD

        if (parts[0].length() == 4) {

            return date;
        }


        // DD-MM-YYYY

        if (parts[2].length() == 4) {

            return parts[2]
                    + "-"
                    + parts[1]
                    + "-"
                    + parts[0];
        }


        return date;
    }
}