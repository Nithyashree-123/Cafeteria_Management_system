package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import models.Customer;

public class CustomerDAO {

    // ==========================================================
    // ADD CUSTOMER
    // ==========================================================

    public void addCustomer(Customer customer) {

        String sql =
                "INSERT INTO customers " +
                "(customer_id, customer_name, contact_number) " +
                "VALUES (?, ?, ?)";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    customer.getCustomerId()
            );

            statement.setString(
                    2,
                    customer.getCustomerName()
            );

            statement.setString(
                    3,
                    customer.getContact()
            );

            int rowsInserted =
                    statement.executeUpdate();

            if (rowsInserted > 0) {

                System.out.println(
                        "Customer added successfully!"
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error adding customer!"
            );

            e.printStackTrace();
        }
    }


    // ==========================================================
    // GET CUSTOMER BY ID
    // ==========================================================

    public Customer getCustomerById(
            int customerId
    ) {

        String sql =
                "SELECT customer_id, customer_name, " +
                "contact_number " +
                "FROM customers " +
                "WHERE customer_id = ?";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    customerId
            );

            ResultSet resultSet =
                    statement.executeQuery();

            if (resultSet.next()) {

                return new Customer(

                        resultSet.getInt(
                                "customer_id"
                        ),

                        resultSet.getString(
                                "customer_name"
                        ),

                        resultSet.getString(
                                "contact_number"
                        )
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error retrieving customer!"
            );

            e.printStackTrace();
        }

        return null;
    }


    // ==========================================================
    // GET ALL CUSTOMERS
    // ==========================================================

    public List<Customer> getAllCustomers() {

        List<Customer> customers =
                new ArrayList<>();

        String sql =
                "SELECT customer_id, customer_name, " +
                "contact_number " +
                "FROM customers";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet resultSet =
                        statement.executeQuery()
        ) {

            while (resultSet.next()) {

                Customer customer =
                        new Customer(

                                resultSet.getInt(
                                        "customer_id"
                                ),

                                resultSet.getString(
                                        "customer_name"
                                ),

                                resultSet.getString(
                                        "contact_number"
                                )
                        );

                customers.add(customer);
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error retrieving customers!"
            );

            e.printStackTrace();
        }

        return customers;
    }


    // ==========================================================
    // DISPLAY ALL CUSTOMERS
    // ==========================================================

    public void displayAllCustomers() {

        List<Customer> customers =
                getAllCustomers();

        for (Customer customer :
                customers) {

            customer.displayCustomer();
        }
    }


    // ==========================================================
    // UPDATE CUSTOMER
    // ==========================================================

    public void updateCustomer(
            Customer customer
    ) {

        String sql =
                "UPDATE customers SET " +
                "customer_name = ?, " +
                "contact_number = ? " +
                "WHERE customer_id = ?";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(
                    1,
                    customer.getCustomerName()
            );

            statement.setString(
                    2,
                    customer.getContact()
            );

            statement.setInt(
                    3,
                    customer.getCustomerId()
            );

            int rowsUpdated =
                    statement.executeUpdate();

            if (rowsUpdated > 0) {

                System.out.println(
                        "Customer updated successfully!"
                );

            } else {

                System.out.println(
                        "Customer not found!"
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error updating customer!"
            );

            e.printStackTrace();
        }
    }


    // ==========================================================
    // DELETE CUSTOMER
    //
    // A customer can be deleted when all their existing
    // orders are COMPLETED or CANCELLED.
    //
    // Before deleting the customer:
    //
    // 1. Delete related order_items
    // 2. Delete completed/cancelled orders
    // 3. Delete customer
    //
    // Everything is done inside one transaction.
    // ==========================================================

    public void deleteCustomer(
            int customerId
    ) {

        String findOrdersSql =
                "SELECT order_id, status " +
                "FROM orders " +
                "WHERE customer_id = ?";


        String deleteOrderItemsSql =
                "DELETE FROM order_items " +
                "WHERE order_id = ?";


        String deleteOrderSql =
                "DELETE FROM orders " +
                "WHERE order_id = ?";


        String deleteCustomerSql =
                "DELETE FROM customers " +
                "WHERE customer_id = ?";


        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement findOrdersStatement =
                        connection.prepareStatement(
                                findOrdersSql
                        )
        ) {

            // ==================================================
            // FIND CUSTOMER ORDERS
            // ==================================================

            findOrdersStatement.setInt(
                    1,
                    customerId
            );


            ResultSet resultSet =
                    findOrdersStatement.executeQuery();


            List<Integer> orderIds =
                    new ArrayList<>();


            while (resultSet.next()) {

                int orderId =
                        resultSet.getInt(
                                "order_id"
                        );

                String status =
                        resultSet.getString(
                                "status"
                        );


                // ----------------------------------------------
                // ACTIVE ORDERS BLOCK CUSTOMER DELETION
                // ----------------------------------------------

                if (
                        status == null
                        ||
                        (
                            !status.equalsIgnoreCase(
                                    "Completed"
                            )
                            &&
                            !status.equalsIgnoreCase(
                                    "Cancelled"
                            )
                        )
                ) {

                    System.out.println(
                            "Customer cannot be deleted because " +
                            "Customer ID " +
                            customerId +
                            " has an active order."
                    );

                    return;
                }


                orderIds.add(orderId);
            }


            // ==================================================
            // START TRANSACTION
            // ==================================================

            connection.setAutoCommit(false);


            try {

                // ==================================================
                // DELETE ORDER ITEMS
                // ==================================================

                try (
                        PreparedStatement
                                deleteOrderItemsStatement =
                                connection.prepareStatement(
                                        deleteOrderItemsSql
                                )
                ) {

                    for (Integer orderId :
                            orderIds) {

                        deleteOrderItemsStatement.setInt(
                                1,
                                orderId
                        );

                        deleteOrderItemsStatement
                                .executeUpdate();
                    }
                }


                // ==================================================
                // DELETE ORDERS
                // ==================================================

                try (
                        PreparedStatement
                                deleteOrderStatement =
                                connection.prepareStatement(
                                        deleteOrderSql
                                )
                ) {

                    for (Integer orderId :
                            orderIds) {

                        deleteOrderStatement.setInt(
                                1,
                                orderId
                        );

                        deleteOrderStatement
                                .executeUpdate();
                    }
                }


                // ==================================================
                // DELETE CUSTOMER
                // ==================================================

                try (
                        PreparedStatement
                                deleteCustomerStatement =
                                connection.prepareStatement(
                                        deleteCustomerSql
                                )
                ) {

                    deleteCustomerStatement.setInt(
                            1,
                            customerId
                    );


                    int rowsDeleted =
                            deleteCustomerStatement
                                    .executeUpdate();


                    if (rowsDeleted > 0) {

                        connection.commit();


                        System.out.println(
                                "Customer and related completed/" +
                                "cancelled orders deleted successfully!"
                        );

                    } else {

                        connection.rollback();


                        System.out.println(
                                "Customer not found!"
                        );
                    }
                }


            } catch (SQLException e) {

                connection.rollback();

                throw e;
            }


        } catch (SQLException e) {

            System.out.println(
                    "Error deleting customer!"
            );

            e.printStackTrace();
        }
    }
}