package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.List;

import models.MenuItem;

public class MenuItemDAO {


    // ==========================================
    // ADD MENU ITEM
    // ==========================================

    public void addMenuItem(
            MenuItem menuItem
    ) {

        String sql =
                "INSERT INTO menu_items " +
                "(item_id, item_name, category_id, price, available) " +
                "VALUES (?, ?, ?, ?, ?)";


        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    menuItem.getItemId()
            );


            statement.setString(
                    2,
                    menuItem.getItemName()
            );


            statement.setInt(
                    3,
                    menuItem.getCategoryId()
            );


            statement.setDouble(
                    4,
                    menuItem.getPrice()
            );


            statement.setBoolean(
                    5,
                    menuItem.isAvailability()
            );


            int rowsInserted =
                    statement.executeUpdate();


            if (rowsInserted > 0) {

                System.out.println(
                        "Menu item added successfully!"
                );
            }


        } catch (SQLException e) {

            System.out.println(
                    "Error adding menu item!"
            );

            e.printStackTrace();
        }
    }


    // ==========================================
    // GET MENU ITEM BY ID
    // ==========================================

    public MenuItem getMenuItemById(
            int itemId
    ) {

        String sql =
                "SELECT * FROM menu_items " +
                "WHERE item_id = ?";


        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    itemId
            );


            ResultSet resultSet =
                    statement.executeQuery();


            if (resultSet.next()) {

                return new MenuItem(

                        resultSet.getInt(
                                "item_id"
                        ),

                        resultSet.getString(
                                "item_name"
                        ),

                        resultSet.getInt(
                                "category_id"
                        ),

                        resultSet.getDouble(
                                "price"
                        ),

                        resultSet.getBoolean(
                                "available"
                        )
                );
            }


        } catch (SQLException e) {

            System.out.println(
                    "Error retrieving menu item!"
            );

            e.printStackTrace();
        }


        return null;
    }


    // ==========================================
    // GET ALL MENU ITEMS
    // Used by CafeteriaServer
    // ==========================================

    public List<MenuItem> getAllMenuItems() {

        List<MenuItem> menuItems =
                new ArrayList<>();


        String sql =
                "SELECT * FROM menu_items";


        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet resultSet =
                        statement.executeQuery()
        ) {


            while (
                    resultSet.next()
            ) {

                MenuItem menuItem =
                        new MenuItem(

                                resultSet.getInt(
                                        "item_id"
                                ),

                                resultSet.getString(
                                        "item_name"
                                ),

                                resultSet.getInt(
                                        "category_id"
                                ),

                                resultSet.getDouble(
                                        "price"
                                ),

                                resultSet.getBoolean(
                                        "available"
                                )
                        );


                menuItems.add(
                        menuItem
                );
            }


        } catch (SQLException e) {

            System.out.println(
                    "Error retrieving all menu items!"
            );

            e.printStackTrace();
        }


        return menuItems;
    }


    // ==========================================
    // DISPLAY ALL MENU ITEMS
    // ==========================================

    public void displayAllMenuItems() {

        String sql =
                "SELECT * FROM menu_items";


        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet resultSet =
                        statement.executeQuery()
        ) {


            while (
                    resultSet.next()
            ) {

                MenuItem menuItem =
                        new MenuItem(

                                resultSet.getInt(
                                        "item_id"
                                ),

                                resultSet.getString(
                                        "item_name"
                                ),

                                resultSet.getInt(
                                        "category_id"
                                ),

                                resultSet.getDouble(
                                        "price"
                                ),

                                resultSet.getBoolean(
                                        "available"
                                )
                        );


                menuItem.displayItem();

                System.out.println();
            }


        } catch (SQLException e) {

            System.out.println(
                    "Error displaying menu items!"
            );

            e.printStackTrace();
        }
    }


    // ==========================================
    // UPDATE MENU ITEM
    // ==========================================

    public void updateMenuItem(
            MenuItem menuItem
    ) {

        String sql =
                "UPDATE menu_items SET " +
                "item_name = ?, " +
                "category_id = ?, " +
                "price = ?, " +
                "available = ? " +
                "WHERE item_id = ?";


        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {


            statement.setString(
                    1,
                    menuItem.getItemName()
            );


            statement.setInt(
                    2,
                    menuItem.getCategoryId()
            );


            statement.setDouble(
                    3,
                    menuItem.getPrice()
            );


            statement.setBoolean(
                    4,
                    menuItem.isAvailability()
            );


            statement.setInt(
                    5,
                    menuItem.getItemId()
            );


            int rowsUpdated =
                    statement.executeUpdate();


            if (rowsUpdated > 0) {

                System.out.println(
                        "Menu item updated successfully!"
                );

            } else {

                System.out.println(
                        "Menu item not found!"
                );
            }


        } catch (SQLException e) {

            System.out.println(
                    "Error updating menu item!"
            );

            e.printStackTrace();
        }
    }


    // ==========================================
    // DELETE MENU ITEM
    // ==========================================

    public void deleteMenuItem(
            int itemId
    ) {

        String sql =
                "DELETE FROM menu_items " +
                "WHERE item_id = ?";


        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {


            statement.setInt(
                    1,
                    itemId
            );


            int rowsDeleted =
                    statement.executeUpdate();


            if (rowsDeleted > 0) {

                System.out.println(
                        "Menu item deleted successfully!"
                );

            } else {

                System.out.println(
                        "Menu item not found!"
                );
            }


        } catch (SQLException e) {

            System.out.println(
                    "Error deleting menu item!"
            );

            e.printStackTrace();
        }
    }
}