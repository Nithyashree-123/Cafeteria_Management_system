package database;

import models.Category;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CategoryDAO {


    // ==========================================================
    // ADD CATEGORY
    // ==========================================================

    public void addCategory(Category category) {

        String sql =
                "INSERT INTO categories " +
                "(category_id, category_name) " +
                "VALUES (?, ?)";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    category.getCategoryId()
            );

            statement.setString(
                    2,
                    category.getCategoryName()
            );

            int rowsInserted =
                    statement.executeUpdate();

            if (rowsInserted > 0) {

                System.out.println(
                        "Category added successfully!"
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error adding category!"
            );

            e.printStackTrace();
        }
    }


    // ==========================================================
    // GET CATEGORY BY ID
    // ==========================================================

    public Category getCategoryById(
            int categoryId
    ) {

        String sql =
                "SELECT category_id, category_name " +
                "FROM categories " +
                "WHERE category_id = ?";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    categoryId
            );

            ResultSet resultSet =
                    statement.executeQuery();

            if (resultSet.next()) {

                return new Category(

                        resultSet.getInt(
                                "category_id"
                        ),

                        resultSet.getString(
                                "category_name"
                        )
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error retrieving category!"
            );

            e.printStackTrace();
        }

        return null;
    }


    // ==========================================================
    // GET ALL CATEGORIES
    // ==========================================================

    public List<Category> getAllCategories() {

        List<Category> categories =
                new ArrayList<>();

        String sql =
                "SELECT category_id, category_name " +
                "FROM categories " +
                "ORDER BY category_id";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet resultSet =
                        statement.executeQuery()
        ) {

            while (resultSet.next()) {

                Category category =
                        new Category(

                                resultSet.getInt(
                                        "category_id"
                                ),

                                resultSet.getString(
                                        "category_name"
                                )
                        );

                categories.add(category);
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error retrieving categories!"
            );

            e.printStackTrace();
        }

        return categories;
    }


    // ==========================================================
    // DISPLAY ALL CATEGORIES
    // ==========================================================

    public void displayAllCategories() {

        List<Category> categories =
                getAllCategories();

        System.out.println(
                "\n===== CATEGORIES ====="
        );

        if (categories.isEmpty()) {

            System.out.println(
                    "No categories found."
            );

            return;
        }

        for (Category category : categories) {

            category.displayCategory();
        }
    }


    // ==========================================================
    // UPDATE CATEGORY
    // ==========================================================

    public void updateCategory(
            Category category
    ) {

        String sql =
                "UPDATE categories " +
                "SET category_name = ? " +
                "WHERE category_id = ?";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(
                    1,
                    category.getCategoryName()
            );

            statement.setInt(
                    2,
                    category.getCategoryId()
            );

            int rowsUpdated =
                    statement.executeUpdate();

            if (rowsUpdated > 0) {

                System.out.println(
                        "Category updated successfully!"
                );

            } else {

                System.out.println(
                        "Category not found!"
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error updating category!"
            );

            e.printStackTrace();
        }
    }


    // ==========================================================
    // DELETE CATEGORY
    // ==========================================================

    public void deleteCategory(
            int categoryId
    ) {

        String sql =
                "DELETE FROM categories " +
                "WHERE category_id = ?";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    categoryId
            );

            int rowsDeleted =
                    statement.executeUpdate();

            if (rowsDeleted > 0) {

                System.out.println(
                        "Category deleted successfully!"
                );

            } else {

                System.out.println(
                        "Category not found!"
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error deleting category!"
            );

            e.printStackTrace();
        }
    }
}