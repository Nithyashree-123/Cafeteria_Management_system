package database;

import models.CafeteriaSection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CafeteriaSectionDAO {


    // ==========================================================
    // ADD SECTION
    // ==========================================================

    public void addSection(CafeteriaSection section) {

        String sql =
                "INSERT INTO cafeteria_sections " +
                "(section_id, section_name, description) " +
                "VALUES (?, ?, ?)";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    section.getSectionId()
            );

            statement.setString(
                    2,
                    section.getSectionName()
            );

            statement.setString(
                    3,
                    section.getDescription()
            );

            int rowsInserted =
                    statement.executeUpdate();

            if (rowsInserted > 0) {

                System.out.println(
                        "Cafeteria section added successfully!"
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error adding cafeteria section!"
            );

            e.printStackTrace();
        }
    }


    // ==========================================================
    // GET SECTION BY ID
    // ==========================================================

    public CafeteriaSection getSectionById(
            int sectionId
    ) {

        String sql =
                "SELECT section_id, section_name, description " +
                "FROM cafeteria_sections " +
                "WHERE section_id = ?";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    sectionId
            );

            ResultSet resultSet =
                    statement.executeQuery();

            if (resultSet.next()) {

                return new CafeteriaSection(
                        resultSet.getInt(
                                "section_id"
                        ),

                        resultSet.getString(
                                "section_name"
                        ),

                        resultSet.getString(
                                "description"
                        )
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error retrieving cafeteria section!"
            );

            e.printStackTrace();
        }

        return null;
    }


    // ==========================================================
    // GET ALL SECTIONS
    // ==========================================================

    public List<CafeteriaSection> getAllSections() {

        List<CafeteriaSection> sections =
                new ArrayList<>();

        String sql =
                "SELECT section_id, section_name, description " +
                "FROM cafeteria_sections " +
                "ORDER BY section_id";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet resultSet =
                        statement.executeQuery()
        ) {

            while (resultSet.next()) {

                CafeteriaSection section =
                        new CafeteriaSection(

                                resultSet.getInt(
                                        "section_id"
                                ),

                                resultSet.getString(
                                        "section_name"
                                ),

                                resultSet.getString(
                                        "description"
                                )
                        );

                sections.add(section);
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error retrieving cafeteria sections!"
            );

            e.printStackTrace();
        }

        return sections;
    }


    // ==========================================================
    // DISPLAY ALL SECTIONS
    // ==========================================================

    public void displayAllSections() {

        List<CafeteriaSection> sections =
                getAllSections();

        System.out.println(
                "\n===== CAFETERIA SECTIONS ====="
        );

        if (sections.isEmpty()) {

            System.out.println(
                    "No cafeteria sections found."
            );

            return;
        }

        for (CafeteriaSection section : sections) {

            section.displaySection();
        }
    }


    // ==========================================================
    // UPDATE SECTION
    // ==========================================================

    public void updateSection(
            CafeteriaSection section
    ) {

        String sql =
                "UPDATE cafeteria_sections " +
                "SET section_name = ?, description = ? " +
                "WHERE section_id = ?";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(
                    1,
                    section.getSectionName()
            );

            statement.setString(
                    2,
                    section.getDescription()
            );

            statement.setInt(
                    3,
                    section.getSectionId()
            );

            int rowsUpdated =
                    statement.executeUpdate();

            if (rowsUpdated > 0) {

                System.out.println(
                        "Cafeteria section updated successfully!"
                );

            } else {

                System.out.println(
                        "Section not found!"
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error updating cafeteria section!"
            );

            e.printStackTrace();
        }
    }


    // ==========================================================
    // DELETE SECTION
    // ==========================================================

    public void deleteSection(
            int sectionId
    ) {

        String sql =
                "DELETE FROM cafeteria_sections " +
                "WHERE section_id = ?";

        try (
                Connection connection =
                        DBConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    sectionId
            );

            int rowsDeleted =
                    statement.executeUpdate();

            if (rowsDeleted > 0) {

                System.out.println(
                        "Cafeteria section deleted successfully!"
                );

            } else {

                System.out.println(
                        "Section not found!"
                );
            }

        } catch (SQLException e) {

            System.out.println(
                    "Error deleting cafeteria section!"
            );

            e.printStackTrace();
        }
    }
}