package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    private static final String URL =
            "jdbc:mysql://localhost:3306/cafeteria_management";

    private static final String USERNAME = "root";

    private static final String PASSWORD = "tiger";

    public static Connection getConnection() {

        Connection connection = null;

        try {

            Class.forName("com.mysql.cj.jdbc.Driver");

            connection = DriverManager.getConnection(
                    URL,
                    USERNAME,
                    PASSWORD
            );

            System.out.println("Database connected successfully!");

        } catch (ClassNotFoundException e) {

            System.out.println("MySQL JDBC Driver not found!");
            e.printStackTrace();

        } catch (SQLException e) {

            System.out.println("Database connection failed!");
            e.printStackTrace();
        }

        return connection;
    }

    public static void main(String[] args) {

        Connection connection = getConnection();

        if (connection != null) {

            System.out.println(
                    "Connection test successful!"
            );

        } else {

            System.out.println(
                    "Connection test failed!"
            );
        }
    }
}