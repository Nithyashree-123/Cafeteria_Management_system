package datastructures;

import models.Order;

/*
 * Queue implemented using Linked List.
 *
 * FIFO:
 * First In - First Out
 *
 * This queue is used for cafeteria order processing.
 */

public class OrderQueue {

    // ==========================================================
    // NODE
    // ==========================================================

    private class Node {

        Order data;
        Node next;

        Node(Order data) {

            this.data = data;
            this.next = null;
        }
    }


    // ==========================================================
    // FRONT AND REAR
    // ==========================================================

    private Node front;
    private Node rear;


    // ==========================================================
    // CONSTRUCTOR
    // ==========================================================

    public OrderQueue() {

        front = null;
        rear = null;
    }


    // ==========================================================
    // ENQUEUE
    // ==========================================================

    public void enqueue(
            Order order
    ) {

        if (order == null) {

            return;
        }


        Node newNode =
                new Node(order);


        if (rear == null) {

            front =
                    newNode;

            rear =
                    newNode;

        } else {

            rear.next =
                    newNode;

            rear =
                    newNode;
        }


        System.out.println(
                "Order " +
                order.getOrderId() +
                " added to queue."
        );
    }


    // ==========================================================
    // DEQUEUE
    // ==========================================================

    public Order dequeue() {

        if (front == null) {

            return null;
        }


        Order order =
                front.data;


        front =
                front.next;


        if (front == null) {

            rear = null;
        }


        return order;
    }


    // ==========================================================
    // PEEK
    // ==========================================================

    public Order peek() {

        if (front == null) {

            return null;
        }


        return front.data;
    }


    // ==========================================================
    // IS EMPTY
    // ==========================================================

    public boolean isEmpty() {

        return front == null;
    }


    // ==========================================================
    // SIZE
    // ==========================================================

    public int size() {

        int count = 0;

        Node current =
                front;


        while (current != null) {

            count++;

            current =
                    current.next;
        }


        return count;
    }


    // ==========================================================
    // DISPLAY
    // ==========================================================

    public void display() {

        if (front == null) {

            System.out.println(
                    "No orders in the queue."
            );

            return;
        }


        Node current =
                front;


        while (current != null) {

            current.data.displayOrder();

            current =
                    current.next;
        }
    }
}