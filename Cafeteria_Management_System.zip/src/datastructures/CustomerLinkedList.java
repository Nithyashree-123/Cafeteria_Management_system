package datastructures;

import models.Customer;

import java.util.ArrayList;
import java.util.List;

public class CustomerLinkedList {

    // ==========================================
    // NODE
    // ==========================================

    private class Node {

        Customer customer;
        Node next;

        Node(Customer customer) {

            this.customer = customer;
            this.next = null;
        }
    }


    // ==========================================
    // HEAD
    // ==========================================

    private Node head;


    // ==========================================
    // ADD CUSTOMER
    // ==========================================

    public void add(Customer customer) {

        Node newNode =
                new Node(customer);


        if (head == null) {

            head = newNode;

        } else {

            Node current = head;


            while (current.next != null) {

                current = current.next;
            }


            current.next = newNode;
        }


        System.out.println(
                "Customer added to Linked List successfully!"
        );
    }


    // ==========================================
    // DISPLAY CUSTOMERS
    // ==========================================

    public void display() {

        if (head == null) {

            System.out.println(
                    "Customer Linked List is empty."
            );

            return;
        }


        Node current = head;


        System.out.println(
                "\n=== CUSTOMER LINKED LIST ==="
        );


        while (current != null) {

            current.customer.displayCustomer();

            current = current.next;
        }
    }


    // ==========================================
    // GET ALL CUSTOMERS
    // Used by CafeteriaServer
    // ==========================================

    public List<Customer> getAll() {

        List<Customer> customers =
                new ArrayList<>();


        Node current = head;


        while (current != null) {

            customers.add(
                    current.customer
            );

            current = current.next;
        }


        return customers;
    }


    // ==========================================
    // SEARCH CUSTOMER
    // ==========================================

    public Customer search(int customerId) {

        Node current = head;


        while (current != null) {

            if (
                    current.customer.getCustomerId()
                    == customerId
            ) {

                return current.customer;
            }


            current = current.next;
        }


        return null;
    }


    // ==========================================
    // UPDATE CUSTOMER
    // ==========================================

    public void update(
            int customerId,
            Customer updatedCustomer
    ) {

        Node current = head;


        while (current != null) {

            if (
                    current.customer.getCustomerId()
                    == customerId
            ) {

                current.customer =
                        updatedCustomer;


                System.out.println(
                        "Customer updated successfully!"
                );

                return;
            }


            current = current.next;
        }


        System.out.println(
                "Customer not found!"
        );
    }


    // ==========================================
    // DELETE CUSTOMER
    // ==========================================

    public void delete(int customerId) {

        if (head == null) {

            System.out.println(
                    "Customer Linked List is empty."
            );

            return;
        }


        // --------------------------------------
        // DELETE FIRST NODE
        // --------------------------------------

        if (
                head.customer.getCustomerId()
                == customerId
        ) {

            head = head.next;


            System.out.println(
                    "Customer deleted successfully!"
            );

            return;
        }


        // --------------------------------------
        // DELETE OTHER NODE
        // --------------------------------------

        Node current = head;


        while (current.next != null) {

            if (
                    current.next.customer
                            .getCustomerId()
                    == customerId
            ) {

                current.next =
                        current.next.next;


                System.out.println(
                        "Customer deleted successfully!"
                );

                return;
            }


            current = current.next;
        }


        System.out.println(
                "Customer not found!"
        );
    }
}