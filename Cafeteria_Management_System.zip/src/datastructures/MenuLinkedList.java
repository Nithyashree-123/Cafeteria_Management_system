package datastructures;

import models.MenuItem;
import java.util.ArrayList;
import java.util.List;

public class MenuLinkedList {

    private class Node {

        MenuItem data;
        Node next;

        Node(MenuItem data) {
            this.data = data;
            this.next = null;
        }
    }

    private Node head;

    // ==========================================
    // CREATE - ADD MENU ITEM
    // ==========================================

    public void add(MenuItem item) {

        Node newNode = new Node(item);

        if (head == null) {
            head = newNode;
        } else {
            Node current = head;

            while (current.next != null) {
                current = current.next;
            }

            current.next = newNode;
        }

        System.out.println(
                "Menu item added to Linked List successfully!"
        );
    }

    // ==========================================
    // READ - DISPLAY MENU ITEMS
    // ==========================================

    public void display() {

        if (head == null) {
            System.out.println(
                    "No menu items available."
            );
            return;
        }

        Node current = head;

        while (current != null) {
            current.data.displayItem();
            current = current.next;
        }
    }

    // ==========================================
    // GET ALL ITEMS
    // Used by the web server
    // ==========================================

    public List<MenuItem> getAll() {

        List<MenuItem> items = new ArrayList<>();

        Node current = head;

        while (current != null) {
            items.add(current.data);
            current = current.next;
        }

        return items;
    }

    // ==========================================
    // SEARCH MENU ITEM
    // ==========================================

    public MenuItem search(int itemId) {

        Node current = head;

        while (current != null) {

            if (current.data.getItemId() == itemId) {
                return current.data;
            }

            current = current.next;
        }

        return null;
    }

    // ==========================================
    // UPDATE MENU ITEM
    // ==========================================

    public void update(
            int itemId,
            MenuItem updatedItem
    ) {

        Node current = head;

        while (current != null) {

            if (current.data.getItemId() == itemId) {

                current.data = updatedItem;

                System.out.println(
                        "Menu item updated in Linked List successfully!"
                );

                return;
            }

            current = current.next;
        }

        System.out.println(
                "Menu item not found in Linked List."
        );
    }

    // ==========================================
    // DELETE MENU ITEM
    // ==========================================

    public void delete(int itemId) {

        if (head == null) {
            System.out.println(
                    "No menu items available."
            );
            return;
        }

        // Delete first node
        if (head.data.getItemId() == itemId) {

            head = head.next;

            System.out.println(
                    "Menu item deleted from Linked List successfully!"
            );

            return;
        }

        Node current = head;

        while (current.next != null) {

            if (current.next.data.getItemId() == itemId) {

                current.next = current.next.next;

                System.out.println(
                        "Menu item deleted from Linked List successfully!"
                );

                return;
            }

            current = current.next;
        }

        System.out.println(
                "Menu item not found in Linked List."
        );
    }
}
