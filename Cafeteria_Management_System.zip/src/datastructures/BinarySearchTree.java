package datastructures;

public class BinarySearchTree {

    private class Node {
        int itemId;
        String itemName;
        Node left;
        Node right;

        Node(int itemId, String itemName) {
            this.itemId = itemId;
            this.itemName = itemName;
        }
    }

    private Node root;

    public void insert(int itemId, String itemName) {
        root = insertNode(root, itemId, itemName);
    }

    private Node insertNode(Node node, int itemId, String itemName) {
        if (node == null) return new Node(itemId, itemName);
        if (itemId < node.itemId) node.left = insertNode(node.left, itemId, itemName);
        else if (itemId > node.itemId) node.right = insertNode(node.right, itemId, itemName);
        return node;
    }

    public String search(int itemId) {
        Node result = searchNode(root, itemId);
        return result == null ? null : result.itemName;
    }

    private Node searchNode(Node node, int itemId) {
        if (node == null || node.itemId == itemId) return node;
        if (itemId < node.itemId) return searchNode(node.left, itemId);
        return searchNode(node.right, itemId);
    }

    public void displayInorder() {
        System.out.print(displayInorderString());
        if (root != null) System.out.println();
    }

    public String displayInorderString() {
        StringBuilder result = new StringBuilder();
        inorder(root, result);
        return result.toString().trim();
    }

    private void inorder(Node node, StringBuilder result) {
        if (node != null) {
            inorder(node.left, result);
            result.append("Item ID: ").append(node.itemId)
                    .append(", Item Name: ").append(node.itemName).append('\n');
            inorder(node.right, result);
        }
    }
}
