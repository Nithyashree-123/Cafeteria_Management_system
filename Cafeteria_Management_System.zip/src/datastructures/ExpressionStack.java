package datastructures;

/*
 * Stack implemented using Linked List.
 *
 * Operations:
 * 1. Push
 * 2. Pop
 * 3. Peek
 * 4. Display stack
 * 5. Postfix expression evaluation
 */

public class ExpressionStack {

    // ==========================================================
    // NODE
    // ==========================================================

    private class Node {

        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    // ==========================================================
    // TOP
    // ==========================================================

    private Node top;

    // ==========================================================
    // CONSTRUCTOR
    // ==========================================================

    public ExpressionStack() {
        top = null;
    }

    // ==========================================================
    // PUSH
    // ==========================================================

    public void push(int value) {

        Node newNode = new Node(value);

        newNode.next = top;
        top = newNode;
    }

    // ==========================================================
    // POP
    // ==========================================================

    public int pop() {

        if (top == null) {
            throw new IllegalStateException("Stack Underflow");
        }

        int value = top.data;
        top = top.next;

        return value;
    }

    // ==========================================================
    // PEEK
    // ==========================================================

    public int peek() {

        if (top == null) {
            throw new IllegalStateException("Stack is empty");
        }

        return top.data;
    }

    // ==========================================================
    // IS EMPTY
    // ==========================================================

    public boolean isEmpty() {
        return top == null;
    }

    // ==========================================================
    // CLEAR STACK
    // ==========================================================

    public void clear() {
        top = null;
    }

    // ==========================================================
    // DISPLAY
    // ==========================================================

    public void display() {

        if (top == null) {
            System.out.println("Stack is empty.");
            return;
        }

        System.out.println("Stack Elements:");

        Node current = top;

        while (current != null) {
            System.out.println(current.data);
            current = current.next;
        }
    }

    // ==========================================================
    // EVALUATE POSTFIX EXPRESSION
    // ==========================================================

    public int evaluatePostfix(String expression) {

        // Clear values from previous evaluations.
        clear();

        try {

            if (expression == null || expression.trim().isEmpty()) {
                throw new IllegalArgumentException(
                        "Expression cannot be empty."
                );
            }

            String[] tokens = expression.trim().split("\\s+");

            for (String token : tokens) {

                // NUMBER
                if (isNumber(token)) {
                    push(Integer.parseInt(token));
                    continue;
                }

                // VALIDATE OPERATOR
                if (!token.equals("+")
                        && !token.equals("-")
                        && !token.equals("*")
                        && !token.equals("/")) {

                    throw new IllegalArgumentException(
                            "Invalid operator: " + token
                    );
                }

                // An operator needs two operands.
                if (isEmpty()) {
                    throw new IllegalArgumentException(
                            "Invalid postfix expression."
                    );
                }

                int b = pop();

                if (isEmpty()) {
                    throw new IllegalArgumentException(
                            "Invalid postfix expression."
                    );
                }

                int a = pop();

                int result;

                switch (token) {

                    case "+":
                        result = a + b;
                        break;

                    case "-":
                        result = a - b;
                        break;

                    case "*":
                        result = a * b;
                        break;

                    case "/":

                        if (b == 0) {
                            throw new ArithmeticException(
                                    "Cannot divide by zero."
                            );
                        }

                        result = a / b;
                        break;

                    default:
                        throw new IllegalArgumentException(
                                "Invalid operator."
                        );
                }

                push(result);
            }

            // A valid expression must leave exactly one result.
            if (isEmpty()) {
                throw new IllegalArgumentException(
                        "Invalid postfix expression."
                );
            }

            int result = pop();

            if (!isEmpty()) {
                throw new IllegalArgumentException(
                        "Invalid postfix expression."
                );
            }

            return result;

        } finally {

            // Prevent leftover values after success or failure.
            clear();
        }
    }

    // ==========================================================
    // CHECK NUMBER
    // ==========================================================

    private boolean isNumber(String token) {

        try {
            Integer.parseInt(token);
            return true;

        } catch (NumberFormatException e) {
            return false;
        }
    }
}