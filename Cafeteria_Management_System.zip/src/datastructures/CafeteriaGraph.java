package datastructures;

import java.util.LinkedList;
import java.util.Queue;

public class CafeteriaGraph {

    private final int vertices;
    private final LinkedList<Integer>[] adjacencyList;

    @SuppressWarnings("unchecked")
    public CafeteriaGraph(int vertices) {

        if (vertices <= 0) {
            throw new IllegalArgumentException(
                    "Number of vertices must be greater than zero."
            );
        }

        this.vertices = vertices;

        adjacencyList = new LinkedList[vertices];

        for (int i = 0; i < vertices; i++) {
            adjacencyList[i] = new LinkedList<>();
        }
    }

    // Add an undirected connection between two cafeteria sections
    public void addEdge(int source, int destination) {

        validateVertex(source);
        validateVertex(destination);

        if (source == destination) {
            throw new IllegalArgumentException(
                    "A vertex cannot connect to itself."
            );
        }

        if (!adjacencyList[source].contains(destination)) {
            adjacencyList[source].add(destination);
        }

        if (!adjacencyList[destination].contains(source)) {
            adjacencyList[destination].add(source);
        }
    }

    // Display the graph using an adjacency list
    public String displayGraph() {

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < vertices; i++) {

            result.append(i).append(" -> ");

            for (int neighbour : adjacencyList[i]) {
                result.append(neighbour).append(" ");
            }

            result.append("\n");
        }

        return result.toString();
    }

    // Breadth First Search traversal
    public String bfs(int startVertex) {

        validateVertex(startVertex);

        boolean[] visited = new boolean[vertices];

        Queue<Integer> queue = new LinkedList<>();

        StringBuilder result = new StringBuilder();

        visited[startVertex] = true;
        queue.add(startVertex);

        while (!queue.isEmpty()) {

            int currentVertex = queue.poll();

            if (result.length() > 0) {
                result.append(" ");
            }

            result.append(currentVertex);

            for (int neighbour : adjacencyList[currentVertex]) {

                if (!visited[neighbour]) {

                    visited[neighbour] = true;
                    queue.add(neighbour);
                }
            }
        }

        return result.toString();
    }

    // Validate vertex numbers
    private void validateVertex(int vertex) {

        if (vertex < 0 || vertex >= vertices) {
            throw new IllegalArgumentException(
                    "Invalid vertex. Enter a number between 0 and "
                            + (vertices - 1) + "."
            );
        }
    }
}