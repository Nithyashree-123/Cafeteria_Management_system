package datastructures;

import models.Order;

public class OrderLinkedList {

    // Node class
    private class Node {

        Order order;
        Node next;

        Node(Order order) {
            this.order = order;
            this.next = null;
        }
    }

    // Head of the linked list
    private Node head;


    // ==========================================
    // ADD ORDER
    // ==========================================

    public void add(Order order) {

        Node newNode =
                new Node(order);

        if (head == null) {

            head = newNode;

        } else {

            Node current = head;

            while (current.next != null) {

                current = current.next;
            }

            current.next = newNode;
        }

        System.out.println(
                "Order added to Linked List successfully!"
        );
    }


    // ==========================================
    // DISPLAY ORDERS
    // ==========================================

    public void display() {

        if (head == null) {

            System.out.println(
                    "Order Linked List is empty."
            );

            return;
        }

        Node current = head;

        System.out.println(
                "\n=== ORDER LINKED LIST ==="
        );

        while (current != null) {

            current.order.displayOrder();

            current = current.next;
        }
    }


    // ==========================================
    // SEARCH ORDER
    // ==========================================

    public Order search(int orderId) {

        Node current = head;

        while (current != null) {

            if (current.order.getOrderId()
                    == orderId) {

                return current.order;
            }

            current = current.next;
        }

        return null;
    }


    // ==========================================
    // UPDATE ORDER
    // ==========================================

    public void update(
            int orderId,
            Order updatedOrder
    ) {

        Node current = head;

        while (current != null) {

            if (current.order.getOrderId()
                    == orderId) {

                current.order =
                        updatedOrder;

                System.out.println(
                        "Order updated successfully!"
                );

                return;
            }

            current = current.next;
        }

        System.out.println(
                "Order not found!"
        );
    }


    // ==========================================
    // DELETE ORDER
    // ==========================================

    public void delete(int orderId) {

        if (head == null) {

            System.out.println(
                    "Order Linked List is empty."
            );

            return;
        }


        // Delete first node
        if (head.order.getOrderId()
                == orderId) {

            head = head.next;

            System.out.println(
                    "Order deleted successfully!"
            );

            return;
        }


        Node current = head;

        while (current.next != null) {

            if (current.next.order
                    .getOrderId()
                    == orderId) {

                current.next =
                        current.next.next;

                System.out.println(
                        "Order deleted successfully!"
                );

                return;
            }

            current = current.next;
        }

        System.out.println(
                "Order not found!"
        );
    }
}