package datastructures;

public class BinaryTree {

    private class Node {
        int data;
        Node left;
        Node right;

        Node(int data) {
            this.data = data;
        }
    }

    private Node root;

    public void createRoot(int data) {
        root = new Node(data);
    }

    public void addLeft(int parentData, int childData) {
        Node parent = findNode(root, parentData);
        if (parent != null) parent.left = new Node(childData);
    }

    public void addRight(int parentData, int childData) {
        Node parent = findNode(root, parentData);
        if (parent != null) parent.right = new Node(childData);
    }

    public boolean contains(int data) {
        return findNode(root, data) != null;
    }

    private Node findNode(Node current, int data) {
        if (current == null) return null;
        if (current.data == data) return current;
        Node leftResult = findNode(current.left, data);
        if (leftResult != null) return leftResult;
        return findNode(current.right, data);
    }

    public void preorder() { System.out.println(preorderString()); }
    public void inorder() { System.out.println(inorderString()); }
    public void postorder() { System.out.println(postorderString()); }

    public String preorderString() {
        StringBuilder result = new StringBuilder();
        preorderTraversal(root, result);
        return result.toString().trim();
    }

    private void preorderTraversal(Node node, StringBuilder result) {
        if (node != null) {
            result.append(node.data).append(' ');
            preorderTraversal(node.left, result);
            preorderTraversal(node.right, result);
        }
    }

    public String inorderString() {
        StringBuilder result = new StringBuilder();
        inorderTraversal(root, result);
        return result.toString().trim();
    }

    private void inorderTraversal(Node node, StringBuilder result) {
        if (node != null) {
            inorderTraversal(node.left, result);
            result.append(node.data).append(' ');
            inorderTraversal(node.right, result);
        }
    }

    public String postorderString() {
        StringBuilder result = new StringBuilder();
        postorderTraversal(root, result);
        return result.toString().trim();
    }

    private void postorderTraversal(Node node, StringBuilder result) {
        if (node != null) {
            postorderTraversal(node.left, result);
            postorderTraversal(node.right, result);
            result.append(node.data).append(' ');
        }
    }
}
