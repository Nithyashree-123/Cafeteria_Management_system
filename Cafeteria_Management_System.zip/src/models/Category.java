package models;

public class Category {

    private int categoryId;
    private String categoryName;


    // ==========================================================
    // CONSTRUCTOR
    // ==========================================================

    public Category(
            int categoryId,
            String categoryName
    ) {

        this.categoryId = categoryId;
        this.categoryName = categoryName;
    }


    // ==========================================================
    // GET CATEGORY ID
    // ==========================================================

    public int getCategoryId() {

        return categoryId;
    }


    // ==========================================================
    // GET CATEGORY NAME
    // ==========================================================

    public String getCategoryName() {

        return categoryName;
    }


    // ==========================================================
    // DISPLAY CATEGORY
    // ==========================================================

    public void displayCategory() {

        System.out.println(
                "Category ID: " + categoryId +
                ", Category Name: " + categoryName
        );
    }
}