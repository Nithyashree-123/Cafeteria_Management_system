package models;

public class Customer {

    private int customerId;
    private String customerName;
    private String contact;

    public Customer(int customerId, String customerName, String contact) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.contact = contact;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getContact() {
        return contact;
    }

    public void displayCustomer() {
        System.out.println(
            "Customer ID: " + customerId +
            ", Name: " + customerName +
            ", Contact: " + contact
        );
    }
}