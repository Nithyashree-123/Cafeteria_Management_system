package models;

public class CafeteriaSection {

    private int sectionId;
    private String sectionName;
    private String description;


    // ==========================================================
    // CONSTRUCTOR
    // ==========================================================

    public CafeteriaSection(
            int sectionId,
            String sectionName,
            String description
    ) {

        this.sectionId = sectionId;
        this.sectionName = sectionName;
        this.description = description;
    }


    // ==========================================================
    // CONSTRUCTOR WITHOUT DESCRIPTION
    // ==========================================================

    public CafeteriaSection(
            int sectionId,
            String sectionName
    ) {

        this.sectionId = sectionId;
        this.sectionName = sectionName;
        this.description = "";
    }


    // ==========================================================
    // GET SECTION ID
    // ==========================================================

    public int getSectionId() {

        return sectionId;
    }


    // ==========================================================
    // GET SECTION NAME
    // ==========================================================

    public String getSectionName() {

        return sectionName;
    }


    // ==========================================================
    // GET DESCRIPTION
    // ==========================================================

    public String getDescription() {

        return description;
    }


    // ==========================================================
    // DISPLAY SECTION
    // ==========================================================

    public void displaySection() {

        System.out.println(
                "Section ID: " + sectionId +
                ", Section Name: " + sectionName +
                ", Description: " + description
        );
    }
}