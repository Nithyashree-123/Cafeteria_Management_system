package models;

public class OrderItem {

    private int orderItemId;
    private int orderId;
    private int itemId;
    private int quantity;
    private double subtotal;


    // ==========================================================
    // CONSTRUCTOR
    // ==========================================================

    public OrderItem(
            int orderItemId,
            int orderId,
            int itemId,
            int quantity,
            double subtotal
    ) {

        this.orderItemId = orderItemId;
        this.orderId = orderId;
        this.itemId = itemId;
        this.quantity = quantity;
        this.subtotal = subtotal;
    }


    // ==========================================================
    // GET ORDER ITEM ID
    // ==========================================================

    public int getOrderItemId() {

        return orderItemId;
    }


    // ==========================================================
    // GET ORDER ID
    // ==========================================================

    public int getOrderId() {

        return orderId;
    }


    // ==========================================================
    // GET ITEM ID
    // ==========================================================

    public int getItemId() {

        return itemId;
    }


    // ==========================================================
    // GET QUANTITY
    // ==========================================================

    public int getQuantity() {

        return quantity;
    }


    // ==========================================================
    // GET SUBTOTAL
    // ==========================================================

    public double getSubtotal() {

        return subtotal;
    }


    // ==========================================================
    // DISPLAY ORDER ITEM
    // ==========================================================

    public void displayOrderItem() {

        System.out.println(
                "Order Item ID: " + orderItemId +
                ", Order ID: " + orderId +
                ", Item ID: " + itemId +
                ", Quantity: " + quantity +
                ", Subtotal: " + subtotal
        );
    }
}