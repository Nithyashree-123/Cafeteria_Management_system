package models;

public class MenuItem {

    private int itemId;
    private String itemName;
    private int categoryId;
    private double price;
    private boolean availability;

    public MenuItem(
            int itemId,
            String itemName,
            int categoryId,
            double price,
            boolean availability
    ) {

        this.itemId = itemId;
        this.itemName = itemName;
        this.categoryId = categoryId;
        this.price = price;
        this.availability = availability;
    }


    public int getItemId() {
        return itemId;
    }


    public String getItemName() {
        return itemName;
    }


    public int getCategoryId() {
        return categoryId;
    }


    public double getPrice() {
        return price;
    }


    public boolean isAvailability() {
        return availability;
    }


    public void displayItem() {

        System.out.println(
                "ID: " + itemId +
                ", Name: " + itemName +
                ", Category ID: " + categoryId +
                ", Price: ₹" + price +
                ", Available: " + availability
        );
    }
}