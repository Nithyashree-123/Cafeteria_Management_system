package algorithms;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import models.MenuItem;

public class GreedySelection {

    /**
     * Selects affordable menu items using a greedy strategy.
     *
     * Strategy:
     * 1. Sort food items by price from lowest to highest.
     * 2. Select each item if its price fits the remaining budget.
     * 3. Continue until all items have been considered.
     *
     * Note:
     * This selects affordable individual items. It does not solve
     * the general knapsack problem optimally.
     */
    public static List<MenuItem> selectAffordableItems(
            List<MenuItem> menuItems,
            double budget) {

        List<MenuItem> selectedItems = new ArrayList<>();

        if (menuItems == null || budget < 0) {
            return selectedItems;
        }

        // Create a copy so the original menu list is not modified.
        List<MenuItem> sortedItems = new ArrayList<>(menuItems);

        // Greedy strategy: consider the cheapest items first.
        sortedItems.sort(
                Comparator.comparingDouble(MenuItem::getPrice)
        );

        double remainingBudget = budget;

        for (MenuItem item : sortedItems) {

            if (item == null) {
                continue;
            }

            double price = item.getPrice();

            // Ignore invalid prices.
            if (!Double.isFinite(price) || price < 0) {
                continue;
            }

            // Select the item if it fits the remaining budget.
            if (price <= remainingBudget) {
                selectedItems.add(item);
                remainingBudget -= price;
            }
        }

        return selectedItems;
    }

    /**
     * Calculates the total cost of selected items.
     */
    public static double calculateTotal(
            List<MenuItem> selectedItems) {

        double total = 0;

        if (selectedItems == null) {
            return total;
        }

        for (MenuItem item : selectedItems) {
            if (item != null) {
                total += item.getPrice();
            }
        }

        return total;
    }

    /**
     * Calculates the remaining budget.
     */
    public static double calculateRemainingBudget(
            double budget,
            List<MenuItem> selectedItems) {

        return budget - calculateTotal(selectedItems);
    }
}