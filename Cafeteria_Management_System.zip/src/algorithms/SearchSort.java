package algorithms;

public class SearchSort {

    // ==============================
    // LINEAR SEARCH
    // ==============================

    public static int linearSearch(int[] array, int key) {

        for (int i = 0; i < array.length; i++) {

            if (array[i] == key) {
                return i;
            }
        }

        return -1;
    }


    // ==============================
    // BINARY SEARCH
    // ==============================

    public static int binarySearch(int[] array, int key) {

        int left = 0;
        int right = array.length - 1;

        while (left <= right) {

            int middle = (left + right) / 2;

            if (array[middle] == key) {
                return middle;
            }

            if (array[middle] < key) {
                left = middle + 1;
            } else {
                right = middle - 1;
            }
        }

        return -1;
    }


    // ==============================
    // BUBBLE SORT
    // ==============================

    public static void bubbleSort(int[] array) {

        for (int i = 0; i < array.length - 1; i++) {

            for (int j = 0; j < array.length - i - 1; j++) {

                if (array[j] > array[j + 1]) {

                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
        }
    }


    // ==============================
    // SELECTION SORT
    // ==============================

    public static void selectionSort(int[] array) {

        for (int i = 0; i < array.length - 1; i++) {

            int minimumIndex = i;

            for (int j = i + 1; j < array.length; j++) {

                if (array[j] < array[minimumIndex]) {
                    minimumIndex = j;
                }
            }

            int temp = array[minimumIndex];
            array[minimumIndex] = array[i];
            array[i] = temp;
        }
    }


    // ==============================
    // DISPLAY ARRAY
    // ==============================

    public static void displayArray(int[] array) {

        for (int value : array) {
            System.out.print(value + " ");
        }

        System.out.println();
    }
}